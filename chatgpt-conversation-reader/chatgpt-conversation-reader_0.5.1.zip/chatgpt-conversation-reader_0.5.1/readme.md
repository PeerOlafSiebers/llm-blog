# ChatGPT Conversations Reader

A PyQt6 application for viewing and searching ChatGPT conversation exports with syntax highlighting and LaTeX rendering.

## Features

- 📁 Load ChatGPT exports (`.json` or `.zip` files)
- 🔍 Full-text search across conversations and titles
- 📝 Markdown rendering with syntax highlighting
- 🧮 LaTeX/MathJax support for mathematical expressions
- 🎨 Modern, clean interface
- 📱 Responsive layout with resizable panels

## Installation

### Prerequisites
- Python 3.8+
- PyQt6
- markdown-it-py

### Install Dependencies
```bash
pip install PyQt6 PyQt6-WebEngine markdown-it-py
```

### Run Application
```bash
python chatgpt-conversation-reader_0.5.1.py
```

## Usage

1. **Load Export**: Click "Load ChatGPT Export" and select your `.json` or `.zip` file
2. **Browse**: Select conversations from the left panel
3. **Search**: Use the search bar to filter conversations by title or content
4. **View**: Read formatted conversations with highlighted search terms

## Export Your ChatGPT Data

1. Go to [ChatGPT Settings](https://chatgpt.com/settings)
2. Navigate to "Data controls" → "Export data"
3. Download your conversations archive
4. Load the file in this application

## System Requirements

- **Windows**: 10/11
- **macOS**: 10.14+
- **Linux**: Ubuntu 18.04+ or equivalent

## License

MIT License - see [LICENSE.md](LICENSE.md) for details.

## Version

Current version: 0.5.1

## Credits

Created by Peer-Olaf Siebers with support from diverse LLMs
