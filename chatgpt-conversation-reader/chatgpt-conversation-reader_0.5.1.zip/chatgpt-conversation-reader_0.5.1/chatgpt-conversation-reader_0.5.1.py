"""
ChatGPT Conversations Reader.

A PyQt6 application for viewing ChatGPT conversation exports with search and highlighting.
Supports the latest ChatGPT conversations.json schema with mapping structure.
"""

import sys
import json
import zipfile
import re
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple, Iterator

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QFileDialog, QMessageBox, QFrame, QSplitter,
    QListWidget, QListWidgetItem, QProgressBar, QStatusBar, QLabel,
    QPushButton, QLineEdit
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QFont, QFontDatabase, QTextCharFormat, QTextCursor, QColor

from PyQt6.QtWebEngineWidgets import QWebEngineView

from markdown_it import MarkdownIt


# --- Constants & Configuration ---

class AppConfig:
    """Application configuration constants."""
    CONVERSATIONS_FILE = "conversations.json"
    DEFAULT_TITLE = "Untitled Conversation"
    FONT_FAMILY = "Inter"
    WINDOW_TITLE = "ChatGPT Conversation Reader"
    WINDOW_SIZE = (1200, 800)
    WINDOW_POSITION = (100, 100)
    SIDEBAR_MIN_WIDTH = 280
    SPLITTER_SIZES = [300, 700]
    HIGHLIGHT_COLOR = QColor(237, 232, 208)
    TITLE_MAX_LENGTH = 50


class MessageKeys:
    """Keys for extracting message content from ChatGPT data structures."""
    PRIMARY_KEYS = ('content', 'text', 'message', 'body')
    FALLBACK_KEYS = ('parts', 'segments', 'messages', 'chat_messages')
    # ChatGPT specific keys
    CHATGPT_KEYS = ('content', 'parts', 'text')


class SearchMatchType(Enum):
    """Types of search matches for conversation filtering."""
    TITLE_ONLY = "[Title]"
    CONTENT_ONLY = "[Content]"
    BOTH = "[Title + Content]"


# --- Data Processing & Business Logic ---

class MessageExtractor:
    """Handles extraction of text content from ChatGPT message formats."""
    
    @staticmethod
    def extract_text(data: Any) -> str:
        """Recursively extract text from nested ChatGPT data structures."""
        if isinstance(data, str) and data.strip():
            return data.strip()
        
        if isinstance(data, dict):
            # Try ChatGPT specific keys first
            for key in MessageKeys.CHATGPT_KEYS:
                if key in data:
                    result = MessageExtractor.extract_text(data[key])
                    if result:
                        return result
            
            # Try primary keys
            for key in MessageKeys.PRIMARY_KEYS:
                if key in data:
                    result = MessageExtractor.extract_text(data[key])
                    if result:
                        return result
            
            # Try fallback keys
            for key in MessageKeys.FALLBACK_KEYS:
                if key in data:
                    result = MessageExtractor.extract_text(data[key])
                    if result:
                        return result

        if isinstance(data, list):
            # Handle parts array in ChatGPT messages
            if len(data) == 1 and isinstance(data[0], str):
                return data[0].strip()
            
            for item in data:
                result = MessageExtractor.extract_text(item)
                if result:
                    return result
        
        return ""

    @staticmethod
    def has_meaningful_content(conversation: Dict[str, Any]) -> bool:
        """Check if conversation contains meaningful text content."""
        # Check if there are any messages with content in the mapping
        mapping = conversation.get('mapping', {})
        for node_id, node_data in mapping.items():
            if node_data.get('message'):
                message = node_data['message']
                if MessageExtractor.extract_text(message):
                    return True
        return False


class ConversationProcessor:
    """Handles ChatGPT conversation data processing and formatting."""
    
    @staticmethod
    def get_messages(conversation: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Extract messages from ChatGPT conversation data structure."""
        mapping = conversation.get('mapping', {})
        messages = []
        
        # Find root node and traverse the conversation tree
        root_node = ConversationProcessor._find_root_node(mapping)
        if root_node:
            messages = ConversationProcessor._traverse_messages(root_node, mapping)
        
        return messages

    @staticmethod
    def _find_root_node(mapping: Dict[str, Any]) -> Optional[str]:
        """Find the root node in the conversation mapping."""
        # Look for the root node that has no parent but has children
        for node_id, node_data in mapping.items():
            if node_data.get('parent') is None and node_data.get('children'):
                # Find the first child that has a message
                for child_id in node_data.get('children', []):
                    if child_id in mapping and mapping[child_id].get('message'):
                        return child_id
        return None

    @staticmethod
    def _traverse_messages(node_id: str, mapping: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Traverse the conversation tree to extract messages in order."""
        messages = []
        visited = set()
        
        def traverse(node_id: str, depth: int = 0):
            if node_id in visited or node_id not in mapping:
                return
            
            visited.add(node_id)
            node_data = mapping[node_id]
            
            # Add message if it exists
            if node_data.get('message'):
                message_data = node_data['message']
                # Add depth for proper ordering
                message_data['_depth'] = depth
                messages.append(message_data)
            
            # Traverse children
            for child_id in node_data.get('children', []):
                traverse(child_id, depth + 1)
        
        traverse(node_id)
        return messages

    @staticmethod
    def get_content_text(conversation: Dict[str, Any]) -> str:
        """Get full textual content of a conversation."""
        messages = ConversationProcessor.get_messages(conversation)
        text_parts = []
        
        for message in messages:
            try:
                text = MessageExtractor.extract_text(message)
                if text:
                    text_parts.append(text)
            except Exception:
                continue
        
        return " ".join(text_parts)

    @staticmethod
    def format_timestamp(timestamp: Any) -> str:
        """Format timestamp string for display."""
        if not timestamp:
            return ""
        
        try:
            # Handle different timestamp formats
            if isinstance(timestamp, (int, float)):
                dt = datetime.fromtimestamp(timestamp)
            elif isinstance(timestamp, str):
                # Try ISO format first
                try:
                    dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                except ValueError:
                    # Try other common formats
                    dt = datetime.fromisoformat(timestamp)
            else:
                return ""
            
            return dt.strftime("%d/%m/%Y @ %H:%M:%S")
        except Exception:
            return ""

    @staticmethod
    def generate_title(conversation: Dict[str, Any]) -> str:
        """Generate display title for conversation."""
        title = conversation.get('title', '').strip()
        
        if not title:
            # Try to get first user message as title
            messages = ConversationProcessor.get_messages(conversation)
            first_user_msg = next(
                (msg for msg in messages if msg.get('author', {}).get('role') == 'user'), 
                None
            )
            title = MessageExtractor.extract_text(first_user_msg) or AppConfig.DEFAULT_TITLE
            
            if len(title) > AppConfig.TITLE_MAX_LENGTH:
                title = title[:AppConfig.TITLE_MAX_LENGTH] + "..."
        
        # Add timestamp if available
        timestamp = ConversationProcessor.format_timestamp(
            conversation.get('create_time') or conversation.get('inserted_at')
        )
        return f"{title} @ {timestamp}" if timestamp else title

    @staticmethod
    def get_message_sender(message: Dict[str, Any]) -> str:
        """Get the sender role for a message."""
        author = message.get('author', {})
        role = author.get('role', 'unknown')
        
        if role == 'user':
            return 'user'
        elif role == 'assistant':
            return 'assistant'
        else:
            return 'unknown'

    @staticmethod
    def get_message_timestamp(message: Dict[str, Any]) -> str:
        """Get formatted timestamp for a message."""
        timestamp = message.get('create_time') or message.get('timestamp')
        return ConversationProcessor.format_timestamp(timestamp)


class SearchManager:
    """Manages search functionality and conversation filtering."""

    def __init__(self, conversation_list: QListWidget, chat_text: QWebEngineView, search_bar: QLineEdit):
        self.conversation_list = conversation_list
        self.chat_text = chat_text
        self.search_bar = search_bar
        self.current_query = ""
        self.conversations: List[Dict[str, Any]] = []
        self.current_matches = []  # Store positions of search matches
        self.current_match_index = 0

    def set_conversations(self, conversations: List[Dict[str, Any]]) -> None:
        """Set the conversations list for searching."""
        self.conversations = conversations

    def search(self, query: str) -> None:
        """Perform search and update conversation list."""
        self.current_query = query.strip() if query else ""
        self.conversation_list.clear()
        self.current_matches = []
        self.current_match_index = 0

        if not self.current_query:
            self._restore_full_list()
            return

        self._filter_conversations()

    def clear(self) -> None:
        """Clear search and restore full conversation list."""
        self.current_query = ""
        self.current_matches = []
        self.current_match_index = 0
        self.search_bar.clear()
        self.conversation_list.clear()
        self._restore_full_list()

    def navigate_to_next_match(self) -> None:
        """Navigate to the next search match in the current conversation."""
        if not self.current_matches:
            return
        
        self.current_match_index = (self.current_match_index + 1) % len(self.current_matches)
        self._scroll_to_current_match()

    def navigate_to_previous_match(self) -> None:
        """Navigate to the previous search match in the current conversation."""
        if not self.current_matches:
            return
        
        self.current_match_index = (self.current_match_index - 1) % len(self.current_matches)
        self._scroll_to_current_match()

    def _scroll_to_current_match(self) -> None:
        """Scroll to the current search match using JavaScript."""
        if not self.current_matches or self.current_match_index >= len(self.current_matches):
            return
        
        match_id = self.current_matches[self.current_match_index]
        js_code = f"""
            var element = document.getElementById('{match_id}');
            if (element) {{
                element.scrollIntoView({{behavior: 'smooth', block: 'center'}});
                element.style.backgroundColor = '#FFD700';
                setTimeout(function() {{
                    element.style.backgroundColor = '#F8D879';
                }}, 1000);
            }}
        """
        self.chat_text.page().runJavaScript(js_code)

    def _restore_full_list(self) -> None:
        """Restore full conversation list."""
        for conv in self.conversations:
            self.conversation_list.addItem(ConversationListItem(conv))
        
        if self.conversation_list.count() > 0:
            self.conversation_list.setCurrentRow(0)
            self._select_first_item()

    def _filter_conversations(self) -> None:
        """Filter conversations based on search query."""
        query_lower = self.current_query.lower()
        matches = []

        for conv in self.conversations:
            item = ConversationListItem(conv)
            title_text = (item.text() or "").lower()
            content_text = ConversationProcessor.get_content_text(conv).lower()
            
            title_match = query_lower in title_text
            content_match = query_lower in content_text

            if title_match or content_match:
                match_type = self._get_match_type(title_match, content_match)
                item.setText(f"{match_type.value} {item.text()}")
                
                item.setData(Qt.ItemDataRole.UserRole, {
                    "query": self.current_query,
                    "title_match": title_match,
                    "content_match": content_match
                })
                
                matches.append(item)

        if not matches:
            self.chat_text.setHtml("<h3>No conversations matched your search</h3>")
        else:
            for item in matches:
                self.conversation_list.addItem(item)
            self.conversation_list.setCurrentRow(0)
            self._select_first_item()

    def _get_match_type(self, title_match: bool, content_match: bool) -> SearchMatchType:
        """Determine the type of search match."""
        if title_match and content_match:
            return SearchMatchType.BOTH
        elif title_match:
            return SearchMatchType.TITLE_ONLY
        else:
            return SearchMatchType.CONTENT_ONLY

    def _select_first_item(self) -> None:
        """Select the first item in the conversation list."""
        if self.conversation_list.count() > 0:
            self.conversation_list.setCurrentRow(0)
            # Emit signal to parent to handle selection
            self.conversation_list.itemClicked.emit(self.conversation_list.item(0))

    def apply_highlighting(self, text_edit: QWebEngineView) -> None:
        """Apply highlighting to text edit if search is active."""
        if self.current_query:
            TextHighlighter.apply_highlighting(text_edit, self.current_query)

class ConversationRenderer:
    """Handles conversation display and HTML rendering with enhanced table support."""
    
    def __init__(self, markdown_processor: MarkdownIt):
        self.md = markdown_processor
        self.match_counter = 0
        self.current_matches = []

    def _apply_html_highlighting(self, html_text: str, search_query: str) -> str:
        """Wrap search terms in HTML with a highlight class and unique IDs."""
        if not search_query:
            return html_text
        
        self.match_counter = 0
        self.current_matches = []
        
        pattern = re.compile(re.escape(search_query), re.IGNORECASE)
        
        def replacer(match):
            match_id = f"search-match-{self.match_counter}"
            self.current_matches.append(match_id)
            self.match_counter += 1
            return f'<span id="{match_id}" class="highlight">{match.group(0)}</span>'
        
        return pattern.sub(replacer, html_text)

    def _preprocess_latex(self, text: str) -> str:
        """Convert ChatGPT's LaTeX delimiters to standard LaTeX format."""
        text = re.sub(r'\\\[(.*?)\\\]', r'$$\1$$', text, flags=re.DOTALL)
        text = re.sub(r'\\\((.*?)\\\)', r'$\1$', text, flags=re.DOTALL)
        return text

    def _preprocess_tables(self, text: str) -> str:
        """Enhanced table preprocessing to ensure proper Markdown table formatting."""
        lines = text.split('\n')
        processed_lines = []
        in_table = False
        added_separator = False
        
        for i, line in enumerate(lines):
            # Check if line looks like a table row (contains multiple |)
            if '|' in line and line.count('|') >= 2:
                # Ensure proper spacing around pipes
                line = re.sub(r'\s*\|\s*', ' | ', line)
                # Ensure line starts and ends with pipes if it's a table row
                line = line.strip()
                if not line.startswith('|'):
                    line = '| ' + line
                if not line.endswith('|'):
                    line = line + ' |'
                
                # Check if this line is already a separator row (contains only ---, |, : and spaces)
                is_separator = re.match(r'^[\s\|\-\:]*$', line) and any(char in line for char in ['-', '='])
                
                # Add separator only after the first row when entering a table
                if not in_table and not is_separator:
                    # Count columns in current row
                    col_count = line.count('|') - 1
                    separator = '|' + ' --- |' * col_count
                    processed_lines.append(line)
                    processed_lines.append(separator)
                    in_table = True
                    added_separator = True
                elif is_separator:
                    # Skip adding duplicate separator
                    if not added_separator:
                        processed_lines.append(line)
                        added_separator = True
                    in_table = True
                else:
                    processed_lines.append(line)
            else:
                # Not a table row, reset table state
                if in_table:
                    in_table = False
                    added_separator = False
                processed_lines.append(line)
        
        return '\n'.join(processed_lines)
        
    def _apply_html_highlighting(self, html_text: str, search_query: str) -> str:
        """Wrap search terms in HTML with a highlight class."""
        if not search_query:
            return html_text
        
        pattern = re.compile(re.escape(search_query), re.IGNORECASE)
        def replacer(match):
            return f'<span class="highlight">{match.group(0)}</span>'
        
        return pattern.sub(replacer, html_text)

    def render_conversation(self, conversation: Dict[str, Any], search_query: str = "") -> str:
        """Render conversation as HTML."""
        messages = ConversationProcessor.get_messages(conversation)
        
        if not messages:
            return "<h3>No messages found in this conversation</h3>"

        message_html_parts = []
        for message in messages:
            if not isinstance(message, dict):
                continue
            
            parsed_text = MessageExtractor.extract_text(message)
            if not parsed_text or not parsed_text.strip():
                continue

            # Enhanced preprocessing for tables
            processed_text = self._preprocess_tables(parsed_text)
            # LaTeX preprocessing
            processed_text = self._preprocess_latex(processed_text)
            # Convert to HTML with table support
            processed_html = self.md.render(processed_text)
            # Apply highlighting after Markdown conversion
            if search_query:
                processed_html = self._apply_html_highlighting(processed_html, search_query)
            
            message_html = self._render_message(message, processed_html)
            message_html_parts.append(message_html)
        
        if not message_html_parts:
            return "<h3>No readable messages found in this conversation</h3>"

        # Add MathJax configuration
        mathjax_config = """
        <script type="text/javascript" async
            src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js">
        </script>
        <script>
        MathJax = {
          tex: {
            inlineMath: [['$', '$']],
            displayMath: [['$$', '$$']]
          }
        };
        </script>
        """

        highlight_style = """
        <style>
            .highlight {
                background-color: #F8D879;
                padding: 2px 0;
                border-radius: 2px;
            }
        </style>
        """

        font_style = """
        <style>
            body {
                font-family: 'Inter', 'Segoe UI', 'Helvetica Neue', 'Arial', 'sans-serif';
                font-size: 11pt;
            }

            /* Table Styles */
            table {
                border-collapse: collapse;
                width: 100%;
                margin: 15px 0;
                background-color: #718096
                border-radius: 8px;
                overflow: hidden;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                font-size: 10pt; 
                font-weight: normal;
                border: 1px solid #718096;                
            }

            th, td {
                border: 1px solid #A0AEC0;
                padding: 6px 8px;
                text-align: left;
                vertical-align: top;
            }

            th {
                background-color: #E2E8F0;
                font-weight: 600;
                color: #2D3748;
            }

            tr:nth-child(even) {
                background-color: #F8FAFC;
            }

            tr:nth-child(uneven) {
                background-color: white;
            }


            tr:hover {
                background-color: #EDF2F7;
            }

            td {
                color: #4A5568;
            }

            /* Code styles */
            pre {
                background-color: #F0F4F8;
                color: #C6E2FF;
                padding: 2px 5px;
                border-radius: 6px;
                font-family: 'Consolas', 'Courier New', 'monospace';
                white-space: pre-wrap;
            }

            code {
                background-color: #F0F4F8;
                color: #6C5CE7;
                border-radius: 4px;
                padding: 2px 5px;
                line-height: 1.5;
                font-family: 'Consolas', 'Courier New', 'monospace';
            }
        </style>
        """
        
        return f"<body>{mathjax_config}\n{highlight_style}\n{font_style}\n" + "\n".join(message_html_parts) + "</body>"

    def _render_message(self, message: Dict[str, Any], processed_html: str) -> str:
        """Render individual message as HTML."""
        sender = ConversationProcessor.get_message_sender(message)
        sender_display = "You" if sender == 'user' else "ChatGPT"
        timestamp_str = ConversationProcessor.get_message_timestamp(message)
        sender_class = "user-message" if sender == 'user' else "assistant-message"
        
        return f"""
            <div class="{sender_class}">
                <div class="message-header" style="background-color: #FFF157; border-radius: 4px; padding: 2px 5px;">
                    <span class="sender">{sender_display}</span>
                    <span class="timestamp">{timestamp_str}</span>
                </div>
                <div class="message-content">{processed_html}</div>
            </div>
        """


# --- UI Components ---

class ConversationLoader(QThread):
    """Background thread for loading conversation data."""
    
    progress_updated = pyqtSignal(int)
    conversation_loaded = pyqtSignal(dict)
    loading_finished = pyqtSignal()
    error_occurred = pyqtSignal(str)

    def __init__(self, file_path: str):
        super().__init__()
        self.file_path = file_path

    def run(self):
        """Load conversations from file."""
        try:
            # Check if it's a zip file or direct JSON
            if self.file_path.endswith('.zip'):
                self._load_from_zip()
            else:
                self._load_from_json()
        except Exception as e:
            self.error_occurred.emit(f"Error loading conversations: {str(e)}")
        finally:
            self.loading_finished.emit()

    def _load_from_zip(self):
        """Load conversations from zip file."""
        with zipfile.ZipFile(self.file_path, 'r') as zip_file:
            if AppConfig.CONVERSATIONS_FILE not in zip_file.namelist():
                self.error_occurred.emit(f"No {AppConfig.CONVERSATIONS_FILE} found in the zip file")
                return

            with zip_file.open(AppConfig.CONVERSATIONS_FILE) as conv_file:
                conversations_data = json.loads(conv_file.read().decode('utf-8'))
                self._process_conversations(conversations_data)

    def _load_from_json(self):
        """Load conversations from JSON file."""
        with open(self.file_path, 'r', encoding='utf-8') as file:
            conversations_data = json.load(file)
            self._process_conversations(conversations_data)

    def _process_conversations(self, conversations_data: Any) -> None:
        """Process loaded conversation data."""
        if isinstance(conversations_data, list):
            meaningful_conversations = [
                conv for conv in conversations_data 
                if MessageExtractor.has_meaningful_content(conv)
            ]
            meaningful_conversations.sort(
                key=lambda x: x.get('create_time') or x.get('inserted_at', ''), 
                reverse=True
            )
            
            total_convs = len(meaningful_conversations)
            for i, conversation in enumerate(meaningful_conversations):
                self.conversation_loaded.emit(conversation)
                progress = int((i + 1) * 100 / max(total_convs, 1))
                self.progress_updated.emit(progress)
                self.msleep(10)
        else:
            if MessageExtractor.has_meaningful_content(conversations_data):
                self.conversation_loaded.emit(conversations_data)
            self.progress_updated.emit(100)


class ConversationListItem(QListWidgetItem):
    """Custom list item for conversation display."""
    
    def __init__(self, conversation: Dict[str, Any]):
        self.conversation = conversation
        title = ConversationProcessor.generate_title(conversation)
        super().__init__(title)
        self.setFont(QFont(AppConfig.FONT_FAMILY, 11))

class UIStyles:
    """Centralized UI styling and CSS management."""
    
    @staticmethod
    def get_stylesheet() -> str:
        """Get application stylesheet with modern CSS practices."""
        return """
            /* Base styles */
            QMainWindow { 
                background-color: #F7FAFC; 
            }
            
            QFrame { 
                background-color: white; 
                border: 1px solid #E2E8F0; 
            }
            
            /* Scrollbars */
            QScrollBar:vertical { 
                border: none; 
                background-color: #F7FAFC; 
                width: 8px; 
                border-radius: 4px; 
            }
            
            QScrollBar::handle:vertical { 
                background-color: #CBD5E0; 
                border-radius: 4px; 
                min-height: 20px; 
            }
            
            QLineEdit {
                border: 1px solid #E2E8F0;
                border-radius: 6px;
                padding: 6px;
                background-color: white;
                font-family: 'Inter', 'Segoe UI', 'Helvetica Neue', 'Arial', 'sans-serif';
                font-size: 10pt;
            }
            QLineEdit:focus {
                border-color: #10A37F;
            }           
            
            /* Buttons */
            QPushButton { 
                background-color: #D97706; 
                color: white; 
                border: none; 
                border-radius: 6px; 
                padding: 8px 16px; 
                font-weight: 500; 
                font-size: 10pt;
            }
            
            QPushButton:hover { 
                background-color: #B45309; 
            }
            
            /* List widget */
            QListWidget { 
                border: 1px solid #E2E8F0; 
                border-radius: 6px; 
                background-color: white; 
                outline: none; 
            }
            
            QListWidget::item { 
                padding: 6px; 
                border-bottom: 1px solid #F7FAFC; 
            }
            
            QListWidget::item:selected { 
                border-radius: 6px; 
                background-color: #FAD691; 
                color: #1A202C; 
            }
            
            /* Chat area */
            QLabel#chat_header { 
                background-color: white; 
                color: #4A5568; 
                padding: 20px; 
                border-bottom: 1px solid #E2E8F0;
            }
            
            QTextEdit { 
                border: none; 
                background-color: white; 
                color: #1A202C; 
                padding: 5px; 
                line-height: 1.5; 
            }
            
            QTextEdit body { 
                font-family: 'Inter', 'Segoe UI', 'Helvetica Neue', 'Arial', 'sans-serif';
                font-size: 11pt; 
            }
            
            /* Message styles */
            .user-message, .assistant-message { 
                margin-bottom: 20px; 
                padding: 10px 15px; 
                border-radius: 8px; 
            }
            
            .user-message { 
                background-color: #F0F4F8; 
            }
            
            .assistant-message { 
                background-color: #E6F3FF; 
            }
            
            .message-header { 
                font-weight: bold; 
                font-size: 13pt; 
                margin-bottom: 8px; 
            }
            
            .message-header .sender { 
                color: #2D3748; 
            }
            
            .message-header .timestamp { 
                font-size: 10pt; 
                font-weight: normal; 
                color: #718096; 
            }
            
            /* Typography */
            h3 { 
                color: #2D3748; 
                font-size: 16pt; 
                margin-top: 1.5em; 
                margin-bottom: 0.5em; 
            }
            
            p { 
                margin-top: 0.5em; 
                margin-bottom: 0.5em; 
            }
            
            /* Code blocks */
            pre { 
                background-color: #2D3748; 
                color: #F7FAFC; 
                padding: 10px; 
                border-radius: 6px; 
                font-family: 'Consolas', 'Courier New', 'monospace'; 
                white-space: pre-wrap; 
            }
            
            code { 
                background-color: #E2E8F0; 
                color: #2D3748; 
                border-radius: 4px; 
                padding: 2px 5px; 
                font-family: 'Consolas', 'Courier New', 'monospace'; 
            }
            
            /* Links */
            a { 
                color: #D97706; 
                text-decoration: underline; 
            }
        """


# --- Main Application ---

class ChatGPTConversationReader(QMainWindow):
    """Main application window for ChatGPT Conversation Reader."""
    
    def __init__(self):
        super().__init__()
        self.conversations: List[Dict[str, Any]] = []
        self.current_conversation: Optional[Dict[str, Any]] = None
        # Standard MarkdownIt with table support enabled via enable method
        self.md = MarkdownIt().enable(['table'])
        
        self._setup_ui()
        self._setup_search_manager()
        self.renderer = ConversationRenderer(self.md)

    def _setup_ui(self) -> None:
        """Initialize the user interface."""
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        
        splitter = QSplitter(Qt.Orientation.Horizontal)
        main_widget.setLayout(QHBoxLayout())
        main_widget.layout().addWidget(splitter)

        self.conversation_list = self._create_sidebar(splitter)
        self.chat_header, self.chat_text = self._create_chat_area(splitter)        
        
        splitter.setSizes(AppConfig.SPLITTER_SIZES)
        splitter.setCollapsible(0, False)
        splitter.setCollapsible(1, False)
        
        self._setup_status_bar()
        self._configure_window()

    def _setup_status_bar(self) -> None:
        """Setup status bar with progress indicator."""
        self.progress_bar = QProgressBar()
        self.progress_bar.hide()
        self.statusBar().addPermanentWidget(self.progress_bar)
        self.statusBar().showMessage("Ready - Load a ChatGPT export file to begin")

    def _configure_window(self) -> None:
        """Configure main window properties."""
        self.setWindowTitle(AppConfig.WINDOW_TITLE)
        self.setGeometry(*AppConfig.WINDOW_POSITION, *AppConfig.WINDOW_SIZE)
        self.setStyleSheet(UIStyles.get_stylesheet())

    def _setup_search_manager(self) -> None:
        """Initialize search manager."""
        self.search_manager = SearchManager(self.conversation_list, self.chat_text, self.search_bar)

    def _create_sidebar(self, parent_splitter: QSplitter) -> QListWidget:
        """Create and configure the sidebar with search and conversation list."""
        sidebar = QFrame()
        sidebar.setFrameStyle(QFrame.Shape.StyledPanel)
        sidebar.setMinimumWidth(AppConfig.SIDEBAR_MIN_WIDTH)
        
        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(6, 6, 6, 6)
        
        # Header
        header_label = QLabel("ChatGPT Conversations")
        header_label.setFont(QFont(AppConfig.FONT_FAMILY, 12, QFont.Weight.Medium))
        header_label.setStyleSheet("background-color: #EDE8D0; color: #000000; padding: 5px;")
        header_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(header_label)

        # Search controls
        self._create_search_controls(layout)
        
        # Load button
        load_button = QPushButton("Load ChatGPT Export")
        load_button.setFont(QFont(AppConfig.FONT_FAMILY, 11, QFont.Weight.Medium))
        load_button.clicked.connect(self.load_conversations)
        layout.addWidget(load_button)
        
        # Conversation list
        conv_list = QListWidget()
        conv_list.setFont(QFont(AppConfig.FONT_FAMILY, 11))
        conv_list.itemClicked.connect(self.on_conversation_selected)
        layout.addWidget(conv_list)
        
        parent_splitter.addWidget(sidebar)
        return conv_list

    def _create_search_controls(self, layout: QVBoxLayout) -> None:
        """Create search bar and clear button."""
        search_layout = QHBoxLayout()

        self.search_bar = QLineEdit()
        self.search_bar.setPlaceholderText("Search conversations...")
        self.search_bar.textChanged.connect(self._on_search_changed)
        self.search_bar.setEnabled(False)  # Initially disabled
        search_layout.addWidget(self.search_bar)

        self.clear_button = QPushButton("Clear")
        self.clear_button.setMaximumWidth(60)
        self.clear_button.clicked.connect(self._on_clear_search)
        self.clear_button.setEnabled(False)  # Initially disabled
        search_layout.addWidget(self.clear_button)

        layout.addLayout(search_layout)

    def _create_chat_area(self, parent_splitter: QSplitter) -> Tuple[QLabel, QWebEngineView]:
        """Create chat display area."""
        chat_frame = QFrame()
        chat_frame.setFrameStyle(QFrame.Shape.StyledPanel)
        
        layout = QVBoxLayout(chat_frame)
        layout.setContentsMargins(6, 6, 6, 6)
        
        chat_header = QLabel("Conversation Protocol")
        chat_header.setFont(QFont(AppConfig.FONT_FAMILY, 12, QFont.Weight.Medium))
        chat_header.setStyleSheet("background-color: #EDE8D0; color: #000000; padding: 5px;")
        chat_header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(chat_header)
        
        chat_text = QWebEngineView()
        layout.addWidget(chat_text)

        layout.setStretch(1, 1)
        
        parent_splitter.addWidget(chat_frame)
        return chat_header, chat_text

    def _on_search_changed(self, query: str) -> None:
        """Handle search query changes."""
        self.search_manager.search(query)

    def _on_clear_search(self) -> None:
        """Handle clear search button click."""
        self.search_manager.clear()

    def load_conversations(self):
        """Load conversations from file."""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Open ChatGPT Export", "", 
            "ChatGPT Exports (*.json *.zip);;All Files (*)"
        )
        if not file_path:
            return

        self._reset_ui()
        self._start_loading(file_path)

    def _reset_ui(self) -> None:
        """Reset UI to initial state."""
        self.conversations.clear()
        self.conversation_list.clear()
        self.progress_bar.show()
        self.progress_bar.setValue(0)
        self.statusBar().showMessage("Loading conversations...")
        
        # Disable search controls when no conversations are loaded
        self.search_bar.setEnabled(False)
        self.clear_button.setEnabled(False)

    def _start_loading(self, file_path: str) -> None:
        """Start background loading process."""
        self.loader_thread = ConversationLoader(file_path)
        self.loader_thread.conversation_loaded.connect(self.add_conversation)
        self.loader_thread.progress_updated.connect(self.progress_bar.setValue)
        self.loader_thread.loading_finished.connect(self.loading_finished)
        self.loader_thread.error_occurred.connect(self.loading_error)
        self.loader_thread.start()

    def add_conversation(self, conversation: Dict[str, Any]) -> None:
        """Add conversation to the list."""
        self.conversations.append(conversation)
        item = ConversationListItem(conversation)
        self.conversation_list.addItem(item)

    def loading_finished(self) -> None:
        """Handle loading completion."""
        self.progress_bar.hide()
        count = len(self.conversations)
        self.statusBar().showMessage(f"Loaded {count} conversation{'s' if count != 1 else ''}")
        
        # Update search manager with loaded conversations
        self.search_manager.set_conversations(self.conversations)
        
        # Enable search controls if conversations exist
        has_conversations = count > 0
        self.search_bar.setEnabled(has_conversations)
        self.clear_button.setEnabled(has_conversations)
        
        if count > 0:
            self.conversation_list.setCurrentRow(0)
            self.on_conversation_selected(self.conversation_list.item(0))

    def loading_error(self, error_message: str) -> None:
        """Handle loading errors."""
        self.progress_bar.hide()
        self.statusBar().showMessage("Error loading conversations")
        QMessageBox.critical(self, "Loading Error", error_message)

    def on_conversation_selected(self, item: ConversationListItem) -> None:
        """Handle conversation selection."""
        if not item:
            return
        
        self.current_conversation = item.conversation
        self._display_conversation(item.conversation)
        self.chat_header.setText(item.text())
        self.chat_header.setAlignment(Qt.AlignmentFlag.AlignLeft)

    def _display_conversation(self, conversation: Dict[str, Any]) -> None:
        """Display selected conversation with highlighting."""
        html_content = self.renderer.render_conversation(conversation, self.search_manager.current_query)
        self.chat_text.setHtml(html_content)

# --- Application Entry Point ---

def setup_application_font() -> QFont:
    """Setup application font with fallback options."""
    font = QFont()
    available_families = QFontDatabase.families()
    
    font_priority = [AppConfig.FONT_FAMILY, "Inter", "Segoe UI", "Helvetica Neue", "Arial", "sans-serif"]
    
    for font_family in font_priority:
        if font_family in available_families:
            font.setFamily(font_family)
            break
    else:
        font.setFamily("Arial")
    
    font.setPointSize(10)
    font.setWeight(QFont.Weight.Normal)
    return font


def main() -> None:
    """Application entry point."""
    app = QApplication(sys.argv)
    app.setApplicationName(AppConfig.WINDOW_TITLE)
    app.setApplicationVersion("0.5.1")
    app.setOrganizationName("Peer-Olaf Siebers")
    app.setFont(setup_application_font())
    
    window = ChatGPTConversationReader()
    window.setWindowTitle(f"{app.applicationName()} {app.applicationVersion()}")
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()