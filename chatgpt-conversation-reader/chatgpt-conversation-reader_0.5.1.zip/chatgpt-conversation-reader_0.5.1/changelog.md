# Chatgpt Conversation Reader - Changelog

## [0.5.1] - 2025-09-21
Added table support

## [0.5.0] - 2025-09-16
This is the initial public release