# ChatGPT Conversation Reader

A PyQt6 desktop application for viewing exported ChatGPT conversations with search and syntax highlighting.

## Features

- **File Support**: Load ChatGPT exports (JSON or ZIP formats)
- **Search & Filter**: Find conversations by title or content
- **Markdown Rendering**: Proper formatting with code highlighting
- **LaTeX Support**: Math equations display with MathJax
- **Modern UI**: Clean interface with responsive design

## Installation

1. Install Python 3.8+
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the application:
   ```bash
   python chatgpt-conversation-reader_0.5.0.py
   ```

## Usage

1. Click "Load ChatGPT Export"
2. Select your exported `conversations.json` or `.zip` file
3. Browse conversations in the sidebar
4. Use the search bar to filter by content
5. Click any conversation to view it in the main panel

## Export Instructions

To export your ChatGPT conversations:

1. Go to ChatGPT settings → Data controls → Export data
2. Request and download your data export
3. Use the provided `.zip` file or extract `conversations.json`

## Licence

MIT Licence