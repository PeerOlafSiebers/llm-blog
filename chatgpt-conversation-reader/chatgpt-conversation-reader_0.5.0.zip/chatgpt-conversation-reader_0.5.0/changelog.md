# Changelog

All notable changes to ChatGPT Conversations Reader will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.5.0] - 2025-09-16

### Added
- **ChatGPT Export Support**: Full compatibility with ChatGPT conversations.json schema
- **Advanced Search**: Full-text search across conversation titles and content
- **LaTeX Rendering**: Support for mathematical expressions with MathJax
- **Modern UI**: Clean interface with Inter font and responsive design
- **Export Formats**: Support for both .json and .zip ChatGPT exports
- **Message Threading**: Proper conversation tree traversal and message ordering
- **Syntax Highlighting**: Code blocks and inline code formatting
- **Search Highlighting**: Visual highlighting of search terms in content
- **Progress Indicators**: Loading progress bars and status updates
- **Error Handling**: Robust error handling for corrupted or invalid exports

### Technical Features
- **Background Loading**: Non-blocking conversation loading with threading
- **Memory Efficient**: Lazy loading and efficient data structures
- **Cross-Platform**: Windows, macOS, and Linux support
- **Scalable**: Handles large conversation archives efficiently

### UI/UX Improvements
- **Responsive Layout**: Resizable panels with persistent sizing
- **Keyboard Navigation**: Full keyboard support for navigation
- **Visual Feedback**: Clear indication of search results and matches
- **Message Formatting**: Distinct styling for user vs assistant messages
- **Timestamp Display**: Formatted timestamps for all messages

### Dependencies
- PyQt6 with WebEngine support
- markdown-it-py for Markdown rendering
- Built-in JSON and ZIP file handling

---

## Future Releases

### Planned Features
- **Export Options**: Save conversations to various formats
- **Dark Mode**: Toggle between light and dark themes  
- **Conversation Statistics**: Analytics and usage metrics
- **Advanced Filtering**: Date ranges and conversation type filters
- **Plugin System**: Extensible architecture for custom features

---

**Note**: This is the initial public release. Previous versions were internal development builds.