# Changelog

## v0.5.0 - 2025-09-15
### First Public Release

**Core Features:**
- Initial release of ChatGPT Conversation Reader
- Support for ChatGPT export formats (JSON and ZIP)
- Conversation list sidebar with chronological sorting
- Search functionality with title and content filtering
- Highlighting of search results in conversation view

**Rendering:**
- Markdown support with proper code formatting
- LaTeX math equation rendering via MathJax
- Message timestamp display
- User/assistant message differentiation

**UI/UX:**
- Modern PyQt6 interface with clean styling
- Responsive layout with adjustable splitter
- Progress bar for loading large exports
- Status bar with loading information

**Technical:**
- Background thread loading for large files
- Efficient conversation tree traversal
- Robust error handling and validation
- Cross-platform compatibility