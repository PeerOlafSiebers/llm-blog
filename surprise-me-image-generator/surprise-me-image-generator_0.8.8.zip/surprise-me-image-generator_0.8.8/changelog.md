# Surprise Me Image Generator - Changelog

## [0.8.8] - 2025-10-07
This is the initial public release