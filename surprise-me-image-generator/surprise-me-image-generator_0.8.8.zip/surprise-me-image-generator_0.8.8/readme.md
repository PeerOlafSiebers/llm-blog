# Surprise Me Image Generator

A Python-based GUI application for generating AI images using multiple services with intelligent prompt enhancement capabilities.

## Features

- **Multiple AI Services**: Support for Pollinations.ai (free), DALL-E 3 (paid), and Stable Diffusion XL (limited free credits)
- **Intelligent Prompt Generation**: Uses Google Gemini to create and enhance prompts
- **Domain & Style Selection**: Choose from academic domains and artistic styles to guide generation
- **Random Surprise Mode**: Automatically generate random prompts and images
- **Image Management**: Zoom, save, and manage generated images
- **Prompt History**: Track and reuse previous prompts

## Requirements

- Python 3.7+
- Required packages:
  - `tkinter` (usually included with Python)
  - `Pillow`
  - `requests`
  - `python-dotenv`
  - `openai`
  - `google-generativeai`

## Installation

1. Install dependencies:
   ```bash
   pip install pillow requests python-dotenv openai google-generativeai
   ```
2. Create a `.env` file in the same directory as the script

## Configuration

Add your API keys to the `.env` file:

```env
# Gemini API (for prompt generation - free tier available)
GEMINI_API_KEY=your_gemini_api_key_here
GEMINI_MODEL=gemini-2.0-flash-exp

# OpenAI API (for DALL-E 3 - paid service)
OPENAI_API_KEY=your_openai_api_key_here

# Hugging Face API (for Stable Diffusion - limited free credits)
HUGGINGFACE_API_TOKEN=your_huggingface_token_here
```

### Getting API Keys

- **Gemini**: [Get free API key](https://ai.google.dev/gemini-api/docs/api-key)
- **OpenAI**: [Get API key](https://platform.openai.com/api-keys) (paid service)
- **Hugging Face**: [Get token](https://huggingface.co/settings/tokens)

**Note**: Pollinations.ai works without any API key and is always available.

## Usage

1. Run the application:

   ```bash
   python surprise-me-image-generator_0.8.8-exe.py
   ```

2. **Generate Images**:

   - Enter a prompt manually or use "Random Prompt" to generate one
   - Select an academic domain and artistic style (optional)
   - Choose your preferred AI service
   - Click "Generate Image"

3. **Surprise Mode**:

   - Click "Surprise Me!" to generate a random image with random domain and style

4. **Image Controls**:
   - Zoom in/out to inspect details
   - Save images in PNG or JPG format
   - Copy prompts to clipboard

## Features Availability

| Feature                     | Requirements            |
| --------------------------- | ----------------------- |
| Manual prompt entry         | None (always available) |
| Pollinations.ai generation  | None (always available) |
| Random prompt generation    | Gemini API key          |
| Prompt enhancement          | Gemini API key          |
| DALL-E 3 generation         | OpenAI API key          |
| Stable Diffusion generation | Hugging Face token      |

## Troubleshooting

- **Service unavailable**: Check your API keys in the `.env` file
- **Quota exceeded**: Wait for quota reset or upgrade your plan
- **Token issues**: Right-click the service status indicator for refresh options

## License

MIT License - see [LICENSE.md](LICENSE.md) for details.

## Version

Current version: 0.8.8

## Credits

Created by Peer-Olaf Siebers with support from diverse LLMs
