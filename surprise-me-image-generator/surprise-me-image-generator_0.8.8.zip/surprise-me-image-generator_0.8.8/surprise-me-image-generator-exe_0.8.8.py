import io
import os
import random
import sys
import urllib.parse
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from datetime import datetime
from PIL import Image, ImageTk
import requests
from requests.exceptions import Timeout as RequestsTimeout
from dotenv import load_dotenv
import openai
from openai import APITimeoutError, APIConnectionError
import google.generativeai as genai
import threading
import webbrowser
from google.api_core import exceptions as gae
import logging
import random


# Load environment variables first
load_dotenv()

# Suppress Google API and gRPC logging - load from .env with fallbacks
os.environ['GRPC_VERBOSITY'] = os.getenv('GRPC_VERBOSITY', 'ERROR')
os.environ['GLOG_minloglevel'] = os.getenv('GLOG_minloglevel', '2')
logging.getLogger('google').setLevel(logging.CRITICAL)
logging.getLogger('google.api_core').setLevel(logging.CRITICAL)
logging.getLogger('google.generativeai').setLevel(logging.CRITICAL)
logging.getLogger('grpc').setLevel(logging.CRITICAL)

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)


class DialogManager:
    """Manages popup dialogs with proper timing and error handling."""
    
    _active_dialogs = {}  # Track active dialogs by type

    @classmethod
    def show_dialog(cls, title, message, dialog_type="info", max_width=800, max_height=600, parent=None):
        """Enhanced dialog box with support for different types and clickable links."""
        # Check if there's already an active dialog of this type
        if dialog_type in cls._active_dialogs:
            existing_dialog = cls._active_dialogs[dialog_type]
            if existing_dialog.winfo_exists():
                existing_dialog.lift()
                existing_dialog.focus_set()
                return None
            else:
                del cls._active_dialogs[dialog_type]
        
        dialog = tk.Toplevel(parent)
        dialog.withdraw()
        cls._active_dialogs[dialog_type] = dialog
        
        # Set the icon for the dialog window
        try:
            dialog.iconbitmap(resource_path('images/icon.ico'))
        except Exception as e:
            # Silently fail if icon cannot be loaded
            pass
        
        # Add prefix to title based on dialog type
        type_prefixes = {
            "info": "INFORMATION: ",
            "warning": "WARNING: ",
            "error": "ERROR: ",
            "question": "QUESTION: ",
            "success": "SUCCESS: "
        }
        prefix = type_prefixes.get(dialog_type, "INFORMATION: ")
        dialog.title(prefix + title)
        dialog.resizable(False, False)
        
        # Get parent window position for centering
        if parent:
            parent.update_idletasks()
            parent_x = parent.winfo_x()
            parent_y = parent.winfo_y()
            parent_width = parent.winfo_width()
            parent_height = parent.winfo_height()
        else:
            parent_x = parent_y = parent_width = parent_height = 0
        
        screen_width = dialog.winfo_screenwidth()
        screen_height = dialog.winfo_screenheight()
        max_width = min(max_width, int(screen_width * 0.8))
        max_height = min(max_height, int(screen_height * 0.8))
        
        container = ttk.Frame(dialog, padding=20)
        container.pack(fill=tk.BOTH, expand=True)
        
        content_frame = ttk.Frame(container)
        content_frame.pack(fill=tk.BOTH, expand=True)
        
        message_frame = ttk.Frame(content_frame)
        message_frame.pack(fill=tk.BOTH, expand=True)
        
        # Check if message contains URLs
        import re
        url_pattern = r'https?://[^\s]+'
        urls = re.findall(url_pattern, message)
        
        if urls:
            # Use Text widget for clickable links
            text_widget = tk.Text(message_frame, wrap="word", height=15, width=70,
                                 font=("Arial", 10), relief="flat", bg=dialog.cget('bg'),
                                 cursor="arrow")
            scrollbar = ttk.Scrollbar(message_frame, command=text_widget.yview)
            text_widget.config(yscrollcommand=scrollbar.set)
            
            # Insert text with clickable links
            parts = re.split(url_pattern, message)
            url_index = 0
            
            for i, part in enumerate(parts):
                text_widget.insert("end", part)
                if url_index < len(urls):
                    # Insert URL as clickable link
                    start_index = text_widget.index("end-1c")
                    text_widget.insert("end", urls[url_index])
                    end_index = text_widget.index("end-1c")
                    
                    # Create tag for this URL
                    tag_name = f"url_{url_index}"
                    text_widget.tag_add(tag_name, start_index, end_index)
                    text_widget.tag_config(tag_name, foreground="blue", underline=1)
                    
                    # Bind click event
                    url = urls[url_index]
                    text_widget.tag_bind(tag_name, "<Button-1>", 
                                        lambda e, u=url: webbrowser.open(u))
                    text_widget.tag_bind(tag_name, "<Enter>",
                                        lambda e: text_widget.config(cursor="hand2"))
                    text_widget.tag_bind(tag_name, "<Leave>",
                                        lambda e: text_widget.config(cursor="arrow"))
                    
                    url_index += 1
            
            text_widget.config(state="disabled")
            text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
            scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
            
            final_width = min(max_width, 750)
            final_height = min(max_height, 400)
        else:
            # Original label-based approach for messages without URLs
            test_label = tk.Label(message_frame, text=message, wraplength=max_width-50, 
                                 justify="left", anchor="nw", font=("Arial", 10))
            test_label.pack()
            dialog.update_idletasks()
            
            req_width = test_label.winfo_reqwidth() + 100
            req_height = test_label.winfo_reqheight() + 150
            
            if req_height > max_height or req_width > max_width:
                test_label.destroy()
                text_frame = ttk.Frame(message_frame)
                text_frame.pack(fill=tk.BOTH, expand=True)
                
                text_widget = tk.Text(text_frame, wrap="word", height=15, width=60, 
                                     font=("Arial", 10), relief="flat", bg=dialog.cget('bg'))
                scrollbar = ttk.Scrollbar(text_frame, command=text_widget.yview)
                text_widget.config(yscrollcommand=scrollbar.set)
                
                text_widget.insert("1.0", message)
                text_widget.config(state="disabled")
                
                text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
                scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
                
                final_width = min(max_width, 750)
                final_height = min(max_height, 400)
            else:
                test_label.destroy()
                label = tk.Label(message_frame, text=message, wraplength=max_width-50, 
                                justify="left", anchor="nw", font=("Arial", 10))
                label.pack(fill=tk.BOTH, expand=True)
                
                final_width = max(400, min(max_width, req_width))
                final_height = max(200, min(max_height, req_height))
        
        button_frame = ttk.Frame(container)
        button_frame.pack(fill=tk.X, pady=(20, 0))
        
        result = {"value": None}
        
        def on_ok():
            result["value"] = True
            cls._cleanup_dialog(dialog_type)
            dialog.destroy()
        
        def on_yes():
            result["value"] = True
            cls._cleanup_dialog(dialog_type)
            dialog.destroy()
        
        def on_no():
            result["value"] = False
            cls._cleanup_dialog(dialog_type)
            dialog.destroy()
        
        def on_cancel():
            result["value"] = None
            cls._cleanup_dialog(dialog_type)
            dialog.destroy()
        
        def on_terminate():
            result["value"] = "terminate"
            cls._cleanup_dialog(dialog_type)
            dialog.destroy()
            # Terminate the application
            if parent:
                parent.quit()
            else:
                import sys
                sys.exit(1)
        
        if dialog_type == "question":
            ttk.Button(button_frame, text="No", command=on_no).pack(side=tk.RIGHT, padx=5)
            ttk.Button(button_frame, text="Yes", command=on_yes).pack(side=tk.RIGHT, padx=5)
        elif dialog_type == "terminate":
            ttk.Button(button_frame, text="Terminate Application", command=on_terminate).pack(side=tk.RIGHT, padx=5)
        else:
            ttk.Button(button_frame, text="OK", command=on_ok).pack(side=tk.RIGHT, padx=5)
        
        # Center the dialog on parent window or screen
        if parent and parent_width > 0 and parent_height > 0:
            x = parent_x + (parent_width // 2) - (final_width // 2)
            y = parent_y + (parent_height // 2) - (final_height // 2)
        else:
            x = (screen_width // 2) - (final_width // 2)
            y = (screen_height // 2) - (final_height // 2)
        
        dialog.geometry(f"{final_width}x{final_height}+{x}+{y}")
        dialog.update_idletasks()
        
        # Ensure dialog appears on top and is modal
        dialog.lift()
        dialog.attributes('-topmost', True)
        if parent:
            dialog.transient(parent)
        dialog.grab_set()
        dialog.focus_set()
        dialog.attributes('-topmost', False)  # Remove topmost after focus
        
        if dialog_type == "question":
            dialog.bind('<Return>', lambda e: on_yes())
            dialog.bind('<Escape>', lambda e: on_no())
        elif dialog_type == "terminate":
            dialog.bind('<Return>', lambda e: on_terminate())
            dialog.bind('<Escape>', lambda e: on_terminate())
        else:
            dialog.bind('<Return>', lambda e: on_ok())
            dialog.bind('<Escape>', lambda e: on_cancel() if dialog_type in ["warning", "error"] else on_ok())
        
        dialog.deiconify()
        dialog.wait_window()
        return result["value"]
    
    @classmethod
    def _cleanup_dialog(cls, dialog_type):
        """Clean up dialog reference when closed."""
        if dialog_type in cls._active_dialogs:
            del cls._active_dialogs[dialog_type]


class ToolTip:
    """Create a tooltip for a given widget."""
    def __init__(self, widget, text):
        self.widget = widget
        self.text = text
        self.tooltip_window = None
        self.widget.bind("<Enter>", self.show_tooltip)
        self.widget.bind("<Leave>", self.hide_tooltip)
    
    def show_tooltip(self, event=None):
        if self.tooltip_window or not self.text:
            return
        x, y, _, _ = self.widget.bbox("insert")
        x += self.widget.winfo_rootx() + 25
        y += self.widget.winfo_rooty() + 25
        
        self.tooltip_window = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")
        
        label = tk.Label(tw, text=self.text, justify=tk.LEFT,
                        background="#ffffe0", relief=tk.SOLID, borderwidth=1,
                        font=("Arial", 9))
        label.pack()
    
    def hide_tooltip(self, event=None):
        if self.tooltip_window:
            self.tooltip_window.destroy()
            self.tooltip_window = None


class APIConfiguration:
    def __init__(self, error_manager):
        self.error_manager = error_manager
        self.gemini_model = None
        self.openai_client = None
        self.hf_token = None
        self.hf_api_url = "https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-xl-base-1.0"
        self.gemini_initialization_failed = False
        self.gemini_initialization_attempted = False
        
        # Add proper status tracking
        self.hf_available = False
        self.dalle_available = False

    def _get_available_models(self):
        """Get list of available Gemini models."""
        try:
            import contextlib
            import io as stdio
            
            # Suppress stderr during model listing
            with contextlib.redirect_stderr(stdio.StringIO()):
                models = genai.list_models()
                available = [m.name.replace('models/', '') for m in models 
                            if 'generateContent' in m.supported_generation_methods]
            return available
        except Exception as e:
            # Silently fail and return empty list
            return []

    def _is_model_available(self, model_name):
        """Check if a specific model is available"""
        available_models = self._get_available_models()
        return model_name in available_models

    def validate_api_keys_at_startup(self):
        """Validate all API keys at startup and return status information."""
        status = {
            'gemini': {'available': False, 'model': None, 'error': None},
            'openai': {'available': False, 'model': 'dall-e-3', 'error': None},
            'huggingface': {'available': False, 'model': 'stable-diffusion-xl-base-1.0', 'error': None}
        }
        
        # Check Gemini
        gemini_api_key = os.getenv('GEMINI_API_KEY')
        gemini_model_name = os.getenv('GEMINI_MODEL')
        
        if not gemini_api_key:
            status['gemini']['error'] = "GEMINI_API_KEY not found in .env file"
        elif not gemini_model_name:
            status['gemini']['error'] = "GEMINI_MODEL not found in .env file"
        else:
            try:
                genai.configure(api_key=gemini_api_key)
                
                # Suppress any remaining error output
                import contextlib
                import io as stdio
                
                with contextlib.redirect_stderr(stdio.StringIO()):
                    available_models = self._get_available_models()
                
                if gemini_model_name in available_models:
                    self.gemini_model = genai.GenerativeModel(gemini_model_name)
                    status['gemini']['available'] = True
                    status['gemini']['model'] = gemini_model_name
                else:
                    suggestions = [m for m in available_models if 'flash' in m.lower()][:3]
                    if not suggestions:
                        suggestions = available_models[:3] if available_models else ['gemini-2.0-flash-exp']
                    status['gemini']['error'] = f"Model '{gemini_model_name}' not found. Available models: {', '.join(suggestions)}"
            except gae.PermissionDenied:
                status['gemini']['error'] = "Permission denied - API key may be invalid or expired"
            except gae.InvalidArgument:
                status['gemini']['error'] = "Invalid API key format"
            except Exception as e:
                # Only show user-friendly message, suppress technical details
                status['gemini']['error'] = "API key validation failed - please check your key"
        
        # Check OpenAI with free validation
        openai_key = os.getenv('OPENAI_API_KEY')
        if not openai_key:
            status['openai']['error'] = "OPENAI_API_KEY not found in .env file"
        else:
            try:
                self.openai_client = openai.OpenAI(api_key=openai_key, timeout=20.0)
                # Free validation call - just lists available models
                self.openai_client.models.list()
                self.dalle_available = True
                status['openai']['available'] = True
            except openai.AuthenticationError:
                status['openai']['error'] = "Invalid API key"
                self.dalle_available = False
            except Exception as e:
                status['openai']['error'] = "API key validation failed"
                self.dalle_available = False
        
        # Check Hugging Face with comprehensive validation
        self.hf_token = os.getenv("HUGGINGFACE_API_TOKEN")
        if not self.hf_token:
            status['huggingface']['error'] = "HUGGINGFACE_API_TOKEN not found in .env file"
            self.hf_available = False
        elif not self.hf_token.startswith('hf_'):
            status['huggingface']['error'] = "Token format appears invalid (should start with 'hf_')"
            self.hf_available = False
        elif len(self.hf_token) < 10:
            status['huggingface']['error'] = "Token appears too short to be valid"
            self.hf_available = False
        else:
            # Use multiple validation methods for better reliability
            validation_result = self._validate_hf_token_multiple_methods(self.hf_token)
            self.hf_available = validation_result['available']
            status['huggingface']['available'] = validation_result['available']
            status['huggingface']['error'] = validation_result['error']
        
        return status
    
    def initialize_apis(self):
        """Initialize all API services with validation."""
        return self.validate_api_keys_at_startup()
    
    def revalidate_hf_token(self):
        """Revalidate Hugging Face token by reloading from .env and checking API."""
        # Reload environment variables
        load_dotenv(override=True)
        
        # Get fresh token from environment
        new_hf_token = os.getenv("HUGGINGFACE_API_TOKEN")
        
        # Update the stored token
        self.hf_token = new_hf_token
        
        # Revalidate with API
        if not new_hf_token:
            self.hf_available = False
            return {'available': False, 'error': "HUGGINGFACE_API_TOKEN not found in .env file"}
        elif not new_hf_token.startswith('hf_'):
            self.hf_available = False
            return {'available': False, 'error': "Token format appears invalid (should start with 'hf_')"}
        elif len(new_hf_token) < 10:
            self.hf_available = False
            return {'available': False, 'error': "Token appears too short to be valid"}
        else:
            # Try multiple validation methods
            return self._validate_hf_token_multiple_methods(new_hf_token)
    
    def _validate_hf_token_multiple_methods(self, token):
        """Validate HF token using multiple methods for better reliability."""
        
        # Method 1: Direct API call (most reliable)
        result1 = self._validate_hf_token_direct_api(token)
        
        if result1['available']:
            # If direct API works, that's the best validation
            self.hf_available = True
            return result1
        
        # Method 2: Try hub library as fallback
        result2 = self._validate_hf_token_hub_library(token)
        
        if result2['available']:
            self.hf_available = True
            return result2
        
        # Method 3: Try model access as last resort
        result3 = self._validate_hf_token_model_access(token)
        
        if result3['available']:
            self.hf_available = True
            return result3
        
        # All methods failed - return the most informative error
        # Prioritize authentication errors over connection errors
        for result in [result1, result2, result3]:
            if result.get('error') and ('401' in result['error'] or '403' in result['error'] or 'authentication' in result['error'].lower()):
                self.hf_available = False
                return result
        
        # Return the first error if no authentication error found
        self.hf_available = False
        return result1
    
    def _validate_hf_token_direct_api(self, token):
        """Validate token using direct API call to whoami endpoint."""
        try:
            headers = {"Authorization": f"Bearer {token}"}
            response = requests.get(
                "https://huggingface.co/api/whoami",
                headers=headers,
                timeout=15
            )
            
            if response.status_code == 200:
                try:
                    user_data = response.json()
                    user_info = user_data.get('name', 'Unknown')
                    return {'available': True, 'error': None, 'user_info': user_info}
                except:
                    return {'available': True, 'error': None, 'user_info': 'Unknown'}
            elif response.status_code == 401:
                return {'available': False, 'error': f"Authentication failed (401)"}
            elif response.status_code == 403:
                return {'available': False, 'error': f"Permission denied (403)"}
            elif response.status_code == 429:
                return {'available': True, 'error': "Rate limited but token appears valid"}
            else:
                return {'available': False, 'error': f"HTTP {response.status_code}"}
                
        except requests.exceptions.Timeout:
            return {'available': False, 'error': "Request timeout"}
        except requests.exceptions.ConnectionError:
            return {'available': False, 'error': "Connection failed"}
        except requests.exceptions.RequestException as e:
            return {'available': False, 'error': f"Request error: {str(e)}"}
        except Exception as e:
            return {'available': False, 'error': f"Unexpected error: {str(e)}"}
    
    def _validate_hf_token_hub_library(self, token):
        """Validate token using huggingface_hub library if available."""
        try:
            from huggingface_hub import HfApi
            
            api = HfApi(token=token)
            user_info = api.whoami()
            
            if user_info and 'name' in user_info:
                return {'available': True, 'error': None, 'user_info': user_info['name']}
            else:
                return {'available': True, 'error': None, 'user_info': 'Unknown'}
                
        except ImportError:
            return {'available': False, 'error': "huggingface_hub library not available"}
        except Exception as e:
            return {'available': False, 'error': f"Hub library error: {str(e)}"}
    
    def _validate_hf_token_model_access(self, token):
        """Validate token by trying to access a public model endpoint."""
        try:
            headers = {"Authorization": f"Bearer {token}"}
            # Try to access model info endpoint
            response = requests.get(
                "https://huggingface.co/api/models/stabilityai/stable-diffusion-xl-base-1.0",
                headers=headers,
                timeout=10
            )
            
            if response.status_code == 200:
                return {'available': True, 'error': None, 'user_info': 'Model access confirmed'}
            elif response.status_code == 401:
                return {'available': False, 'error': f"Model access denied (401)"}
            elif response.status_code == 403:
                return {'available': False, 'error': f"Model access forbidden (403)"}
            else:
                return {'available': False, 'error': f"Model access failed (HTTP {response.status_code})"}
                
        except requests.exceptions.Timeout:
            return {'available': False, 'error': "Model access timeout"}
        except requests.exceptions.ConnectionError:
            return {'available': False, 'error': "Model access connection failed"}
        except requests.exceptions.RequestException as e:
            return {'available': False, 'error': f"Model access error: {str(e)}"}
        except Exception as e:
            return {'available': False, 'error': f"Model access unexpected error: {str(e)}"}
    
    def ensure_gemini_available(self):
        """Check if Gemini is available."""
        return self.gemini_model is not None


class ErrorManager:
    """Manages error tracking and display with proper timing."""
    
    def __init__(self, gui_callback=None):
        self.pending_errors = []
        self.gui_callback = gui_callback
    
    def add_error(self, title, message, error_type="error"):
        """Add an error to be shown after GUI is ready."""
        self.pending_errors.append((title, message, error_type))
        print(f"Pending {error_type} added: {title}")
    
    def show_pending_errors(self):
        """Show any errors that occurred during initialization."""
        if not self.pending_errors:
            return
            
        print(f"Showing {len(self.pending_errors)} pending errors")
        for title, message, dialog_type in self.pending_errors:
            if self.gui_callback and hasattr(self.gui_callback, 'root'):
                self.gui_callback.root.after(0, lambda t=title, m=message, d=dialog_type: 
                    DialogManager.show_dialog(t, m, d, parent=self.gui_callback.root))
            else:
                DialogManager.show_dialog(title, message, dialog_type)
        self.pending_errors.clear()


class ImageGenerator:
    """Handles image generation using multiple AI services."""
    
    def __init__(self, error_manager):
        """Initialize with error manager for proper error handling."""
        self.error_manager = error_manager
        self.api_config = APIConfiguration(error_manager)
        
        # Always initialize APIs - don't let failures prevent object creation
        try:
            self.api_config.initialize_apis()
        except Exception as e:
            # Log the error but don't prevent ImageGenerator creation
            print(f"Warning: API initialization had issues: {e}")
        
        self._initialize_styles_and_domains()
            
    @property
    def gemini_model(self):
        return self.api_config.gemini_model
    
    @property
    def openai_client(self):
        return self.api_config.openai_client
    
    @property
    def hf_token(self):
        return self.api_config.hf_token
        
    def _initialize_styles_and_domains(self):
        """Initialize reusable style and domain data structures."""
        self.styles = {
            "Traditional Art Styles": [
                "watercolour painting style with delicate washes, soft brushstrokes, and organic blending",
                "vintage children's book illustration style with hand-drawn textures, muted colours, and whimsical charm",
                "stained glass mosaic style with bold black outlines and luminous colour fragments",
                "ancient cave painting style with earthy pigments, rough textures, and primitive symbols",
                "embroidery thread art style with stitched textures, layered threads, and fabric backdrops"
            ],
            "Digital & Modern Aesthetics": [
                "realistic photography style with lifelike lighting, depth of field, and sharp detail",
                "digital art with glowing neon accents, gradients, and futuristic highlights",
                "glitch art digital style with fragmented visuals, pixel distortion, and neon noise",
                "isometric diorama style with miniature 3D perspectives, cutaway environments, and geometric precision",
                "surreal dreamscape style with distorted proportions, floating objects, and ethereal lighting"
            ],
            "Cartoon & Playful Styles": [
                "vibrant cartoon animation style with exaggerated expressions, bold lines, and dynamic colours",
                "stickmen cartoon style with simple line-drawn figures, exaggerated expressions, and minimal backgrounds",
                "pixel art retro gaming style with low-resolution blocks, limited palettes, and nostalgic charm",
                "clay animation (claymation) style with sculpted textures, handcrafted imperfections, and stop-motion feel",
                "origami paper art style with folded edges, creased textures, and layered construction",
                "slapstick cartoon style with exaggerated physical comedy, dynamic action poses, and humorous mishaps",
                "chibi anime style with oversized heads, tiny bodies, and expressive cute features",
                "paper cutout collage style with layered textures, bold shapes, and playful handcrafted look"
            ],
            "Technical & Conceptual Styles": [
                "blueprint schematic style with precise lines, grid layouts, and technical annotations",
                "chalkboard sketch style with rough white chalk lines on a dark matte background",
                "steampunk illustration style with gears, brass textures, and Victorian ornamentation"
            ],
            "Logo Design Styles": [
                "minimalist geometric logo style with clean lines, balanced negative space, and symbolic simplicity",
                "vintage badge emblem style with ornate borders, classic typography, and heritage craftsmanship details", 
                "fluid organic logo style with flowing shapes, gradient blends, and natural movement patterns"
            ],
            "Marketing & Commercial Styles": [
                "lifestyle marketing photography style with authentic moments, natural lighting, and relatable human connections",
                "bold graphic marketing style with vibrant color blocks, dynamic typography, and eye-catching visual hierarchy",
                "conceptual infographic style with data visualization, iconography, and clear information architecture"
            ]
        }        
        self.domain_guidance = {
            "General": {
                "Inspiration": "Create a visually stunning and inspiring image",
                "Wellbeing": "Focus on uplifting, positive, and mood-enhancing themes"
            },
            "Arts & Humanities": {
                "Arts": "Focus on cultural, historical, or philosophical themes with artistic expression",
                "Literature & Creative Writing": "Evoke narrative, poetic imagery, or literary themes",
                "Music & Performing Arts": "Capture rhythm, performance, or auditory experiences visually",
                "History & Archaeology": "Recreate historical events, artifacts, or ancient civilizations",
                "Philosophy & Ethics": "Illustrate abstract concepts, moral dilemmas, or thought experiments",
                "Linguistics & Languages": "Visualise communication, language structures, or translation"
            },
            "Sciences": {
                "Physics & Astronomy": "Depict cosmic phenomena, physical laws, or quantum concepts",
                "Chemistry & Biochemistry": "Illustrate molecular structures, reactions, or chemical processes",
                "Biology & Genetics": "Show biological systems, DNA, evolution, or living organisms",
                "Mathematics & Statistics": "Visualise mathematical concepts, patterns, or data relationships",
                "Environmental Studies": "Focus on ecology, sustainability, or natural systems",
                "Geography & Geosciences": "Depict landscapes, geological formations, or spatial relationships",
                "Marine Sciences & Oceanography": "Illustrate marine life, ocean ecosystems, or underwater exploration",
                "Climate Science": "Represent global climate patterns, change, and environmental impact",
                "Artificial Life & Complexity Science": "Visualise emergent systems, simulations, and self-organisation"
            },
            "Engineering & Technology": {
                "Engineering": "Highlight innovation, technology, infrastructure, or mechanical systems",
                "Computer Science & IT": "Feature technology, coding, networks, or digital innovation",
                "Robotics & Automation": "Illustrate intelligent machines, automation, or future technology",
                "Nanotechnology & Materials Science": "Visualise microscopic structures, advanced materials, or tiny tech",
                "Cybersecurity & Information Assurance": "Represent digital protection, data security, or cyber threats",
                "Renewable Energy & Sustainability": "Depict clean energy, environmental solutions, or green technology",
                "Aviation & Aerospace": "Feature flight, spacecraft, or aerial perspectives",
                "Transportation & Automotive": "Depict vehicles, mobility systems, and futuristic travel concepts",
                "Telecommunications": "Visualise global connectivity, data transfer, and networked communication"
            },
            "Medicine & Health": {
                "General Medicine": "Focus on healthcare, anatomy, wellness, or medical technology",
                "Public Health & Epidemiology": "Show disease prevention, health systems, or community wellness",
                "Pharmacy & Pharmacology": "Depict medicinal compounds, drug interactions, or healthcare solutions",
                "Veterinary Medicine": "Show animal health, veterinary care, or zoonotic relationships",
                "Neuroscience": "Represent brain functions, cognition, and human perception",
                "Sports Science & Kinesiology": "Depict athletic movement, human performance, or sports dynamics"
            },
            "Social Sciences": {
                "Psychology & Behavioural Sciences": "Represent mental processes, brain functions, or human cognition",
                "Political Science & International Relations": "Depict governance, diplomacy, or political systems",
                "Anthropology & Cultural Studies": "Illustrate human cultures, traditions, or social practices",
                "Sociology": "Depict social systems, communities, and collective behaviour",
                "Economics": "Illustrate commerce, markets, and economic interactions"
            },
            "Applied Fields": {
                "Business & Management": "Illustrate commerce, finance, markets, or organisational concepts",
                "Education": "Show learning environments, knowledge acquisition, or academic growth",
                "Journalism & Media Studies": "Represent information dissemination, news, or media influence",
                "Law & Governance": "Represent justice, legal systems, or ethical dilemmas",
                "Urban Planning & Development": "Show cityscapes, infrastructure, or community design",
                "Hospitality & Tourism": "Represent travel, leisure, or service industry concepts",
                "Architecture & Design": "Highlight structural design, spatial concepts, or aesthetic forms",
                "Fashion & Textile Design": "Feature clothing design, textile patterns, or fashion innovation",
                "Agriculture & Food Sciences": "Show cultivation, food systems, or sustainable farming",
                "Military & Defence Studies": "Depict strategy, security, or advanced defence technologies",
                "Disaster Management & Resilience": "Illustrate responses to natural disasters, crises, and recovery systems"
            }
        }

    def _process_domain_and_style(self, domain="None", style="any"):
        """Process domain and style selections, returning structured data for prompt generation."""
        print(f"PROCESSING - Domain: '{domain}', Style: '{style}'")

        all_styles = [s for category in self.styles.values() for s in category]
        selected_style = None
        random_style_name = None

        # Handle style
        if style == "Any Style (Random)":
            if all_styles:
                selected_style = random.choice(all_styles)
                random_style_name = selected_style
                print(f"Random style selected: {selected_style}")
        elif style == "any":
            if all_styles:
                selected_style = random.choice(all_styles)
                print(f"Random style selected: {selected_style}")
        elif style != "none":
            selected_style = style
            print(f"Specific style selected: {selected_style}")

        # Handle domain (unchanged logic)
        domain_name = domain
        domain_context = None
        has_domain = False

        if domain == "Any Domain (Random)":
            all_domains = []
            for d_name, subdomains in self.domain_guidance.items():
                if isinstance(subdomains, dict):
                    for sub in subdomains.keys():
                        all_domains.append(f"{d_name} - {sub}")
                else:
                    all_domains.append(d_name)

            if all_domains:
                domain_name = random.choice(all_domains)
                print(f"Random domain selected: {domain_name}")

                if " - " in domain_name:
                    parent_domain, subdomain = domain_name.split(" - ", 1)
                    parent_subdomains = self.domain_guidance.get(parent_domain)
                    if isinstance(parent_subdomains, dict):
                        domain_context = parent_subdomains.get(subdomain)
                else:
                    domain_context = self.domain_guidance.get(domain_name)
                has_domain = True

        elif domain != "None":
            has_domain = True
            if " - " in domain:
                parent_domain, subdomain = domain.split(" - ", 1)
                parent_subdomains = self.domain_guidance.get(parent_domain)
                if isinstance(parent_subdomains, dict):
                    domain_context = parent_subdomains.get(subdomain)
                    print(f"Domain context from subdomain: {domain_context}")
            else:
                domain_context = self.domain_guidance.get(domain)
                print(f"Domain context from standalone: {domain_context}")

            if not domain_context:
                for d_name, subdomains in self.domain_guidance.items():
                    if isinstance(subdomains, dict):
                        for sub, desc in subdomains.items():
                            if sub == domain or f"{d_name} - {sub}" == domain:
                                domain_context = desc
                                print(f"Domain context found via search: {domain_context}")
                                break
                            if domain_context:
                                break

        print(f"PROCESSED - Has Domain: {has_domain}, Domain Context: {domain_context}, Has Style: {selected_style is not None}")

        return {
            'original_domain': domain,
            'domain_name': domain_name,
            'domain_context': domain_context,
            'has_domain': has_domain,
            'selected_style': selected_style,
            'has_style': selected_style is not None,
            'random_style_name': random_style_name  # added
        }

    def _log_generation_params(self, params, prefix=""):
        """Log generation parameters in consistent format."""
        style_info = params['selected_style'] if params['selected_style'] is not None else "no style specified"

        if params['original_domain'] == "None":
            print(f"{prefix}DOMAIN: {params['original_domain']} (no domain context).\nSELECTED STYLE: {style_info}.")
        elif params['original_domain'] == "Any Domain (Random)":
            print(f"{prefix}DOMAIN: {params['original_domain']} (randomly selected: {params['domain_name']}).\nDOMAIN CONTEXT: {params['domain_context']}.\nSELECTED STYLE: {style_info}.")
        else:
            # Handle style random display here
            if params.get('random_style_name'):
                print(f"{prefix}DOMAIN: {params['domain_name']}.\nDOMAIN CONTEXT: {params['domain_context']}.\nSELECTED STYLE: Any Style (Random) (randomly selected: {params['random_style_name']}).")
            elif params['selected_style']:
                print(f"{prefix}DOMAIN: {params['domain_name']}.\nDOMAIN CONTEXT: {params['domain_context']}.\nSELECTED STYLE: {style_info}.")
            else:
                print(f"{prefix}DOMAIN: {params['domain_name']}.\nDOMAIN CONTEXT: {params['domain_context']}.\nSELECTED STYLE: no style specified.")

    def get_random_prompt_from_gemini(self, domain="None", style="any"):
        """Generate a random prompt with domain and style context using Gemini."""
        if not self.api_config.ensure_gemini_available():
            raise RuntimeError("Gemini model not available - check your API key and model configuration")

        params = self._process_domain_and_style(domain, style)
        
        style_requirement = f"\n- Use the artistic style: \"{params['selected_style']}\"" if params['has_style'] else ""
        style_return_trailer = " with the specified style" if params['has_style'] else ""
        
        domain_requirement_lines = ""
        if params['has_domain']:
            domain_context_safe = params['domain_context'] if params['domain_context'] else "A detailed creative context."
            domain_requirement_lines = f"""
    - Focus specifically on the domain of: {params['domain_name']}
    - Domain context: {domain_context_safe}"""

        prompt_request = f"""Generate ONE image prompt that has a positive impact on people's mood. Structure the prompt so it would work well with common AI systems like Stable Diffusion, DALL-E, and Pollinations.
        
    Requirements:
    - Must evoke wonder and interest for exploration
    - Avoid any scary, dark, or complex themes{domain_requirement_lines}{style_requirement}
    - Vary the starting approach (don't always begin with "a vibrant...")
    - Make it approximately 50 words
        
    Return ONLY the complete prompt{style_return_trailer}, no explanations."""

        try:
            response = self.gemini_model.generate_content(prompt_request)
            return response.text.strip().strip('"')
            
        except gae.DeadlineExceeded:
            error_msg = ("Gemini API Timeout: The request took too long to complete. "
                          "This is often a temporary server issue—please try pressing 'Random Prompt' again.")
            print(error_msg)
            raise RuntimeError(error_msg)
        except gae.ResourceExhausted:
            error_msg = ("Gemini API Quota Exceeded: You have exceeded your rate limit or quota.\n\n"
                          "Free tier has limited requests per minute/day. Please wait a moment or check your quota at: "
                          "https://ai.google.dev/gemini-api/docs/quota")
            print(error_msg)
            raise RuntimeError(error_msg)
        except gae.PermissionDenied:
            error_msg = ("Gemini API Permission Denied: Your API key may be invalid, expired, or lacks permissions.\n\n"
                          "Please verify your key at: https://ai.google.dev/gemini-api/docs/api-key")
            print(error_msg)
            raise RuntimeError(error_msg)
        except gae.InvalidArgument:
            error_msg = ("Gemini API Invalid Request: The prompt or configuration is invalid.\n\n"
                          "This may indicate an issue with the model or prompt format.")
            print(error_msg)
            raise RuntimeError(error_msg)
        except Exception as e:
            print(f"Error generating random prompt: {e}")
            raise RuntimeError(f"Unable to generate prompt: {e}")

    def enhance_prompt_with_gemini(self, base_prompt, domain="None", style="any"):
        """Enhance an existing prompt with domain and style context using Gemini."""
        if not self.gemini_model:
            raise RuntimeError("Gemini API not available. Please check your GEMINI_API_KEY.")
            
        try:
            params = self._process_domain_and_style(domain, style)
            
            intro_parts = []
            if params['has_domain']:
                intro_parts.append("domain-specific context")
            if params['has_style']:
                intro_parts.append("artistic style")
                
            intro_context = ""
            if intro_parts:
                intro_context = f"Add {' and '.join(intro_parts)}" if len(intro_parts) > 1 else f"Add {intro_parts[0]}"
            
            intro_line = f"Enhance and improve the following image prompt to make it more detailed, vivid, and effective for AI image generation. {intro_context} while making it more engaging:" if intro_context else "Enhance and improve the following image prompt to make it more detailed, vivid, and effective for AI image generation. Make it more engaging:"

            requirements = ""
            if params['has_domain']:
                requirements += f"\n- Add domain-specific context from: {params['domain_name']}"
            if params['has_style']:
                requirements += f"\n- Use the artistic style: \"{params['selected_style']}\""
                
            context_block = ""
            if params['has_domain'] and params['domain_context']:
                context_block = f"\nDomain context: {params['domain_context']}\n"

            trailer_parts = []
            if params['has_domain']:
                trailer_parts.append("domain context")
            if params['has_style']:
                trailer_parts.append("artistic style")
                
            ending_trailer = f" that incorporates the {' and '.join(trailer_parts)} naturally." if trailer_parts else ""
            
            prompt_request = f"""{intro_line}

Base prompt: "{base_prompt}"

Requirements:
- Enhance the prompt while keeping the core concept intact{requirements}
- Make the prompt more detailed and descriptive
- Ensure it works well with AI systems like Stable Diffusion, DALL-E, and Pollinations
- Keep the enhanced prompt positive and mood-lifting
- Vary the starting approach (don't always begin with "a vibrant...")
- Make it approximately 50 words
{context_block}
Generate ONE enhanced prompt{ending_trailer}. Return ONLY the complete prompt, no explanations."""
           
            self._log_generation_params(params, prefix=f"ENHANCING PROMPT: {base_prompt[:50]}...\n")

            response = self.gemini_model.generate_content(prompt_request)
            
            if response and response.text:
                enhanced_prompt = response.text.strip()
                if enhanced_prompt.startswith('"') and enhanced_prompt.endswith('"'):
                    enhanced_prompt = enhanced_prompt[1:-1]
                print(f"ENDANCED PROMPT: {enhanced_prompt}")
                return enhanced_prompt
            else:
                raise RuntimeError("No response received from Gemini API")
                
        except google.generativeai.types.BlockedPromptException as e:
            error_msg = "Gemini API blocked the prompt request. This might be due to content filtering."
            print(f"Gemini API blocked prompt: {e}")
            raise RuntimeError(error_msg)
        except google.generativeai.types.StopCandidateException as e:
            error_msg = "Gemini API stopped generating content. This might be due to content filtering."
            print(f"Gemini API stopped generating: {e}")
            raise RuntimeError(error_msg)
        except Exception as e:
            if "quota" in str(e).lower() or "limit" in str(e).lower():
                error_msg = ("Gemini API quota exceeded or rate limited. "
                             "This is often a temporary server issue—please try pressing 'Generate Prompt' again.")
            else:
                error_msg = f"Error enhancing prompt: {e}"
            print(f"Error enhancing prompt: {e}")
            raise RuntimeError(error_msg)
        
    def _handle_image_response(self, response, content_type="image/"):
        """Handle HTTP response and check for image content type."""
        if response.headers.get('content-type', '').startswith(content_type):
            return response
        print(f"Unexpected response type: {response.headers.get('content-type')}")
        return None
    
    def generate_image_with_dalle(self, prompt):
        """Generate image using DALL-E 3."""
        if not self.openai_client:
            raise RuntimeError("DALL-E Error: OPENAI_API_KEY is missing or client failed to initialize.")
            
        try:
            response = self.openai_client.images.generate(
                model="dall-e-3", 
                prompt=prompt, 
                size="1024x1024", 
                quality="standard", 
                n=1
            )
            return response.data[0].url
        except (APITimeoutError, APIConnectionError):
            error_msg = ("DALL-E Timeout: The service took too long or connection failed. "
                         "This is often a temporary issue—please try pressing 'Generate Image' again.")
            print(error_msg)
            raise RuntimeError(error_msg)
        except openai.APIError as e:
            # Check for specific billing errors
            error_str = str(e)
            if 'billing_hard_limit_reached' in error_str or 'insufficient_quota' in error_str:
                error_msg = ("DALL-E Billing Error: Your account has reached its billing limit or has insufficient credits.\n\n"
                            "Please check your OpenAI billing settings at: https://platform.openai.com/account/billing")
                print(error_msg)
                raise RuntimeError(error_msg)
            print(f"DALL-E API Error: {e}")
            raise RuntimeError(f"DALL-E API Error: {e}")
        except Exception as e:
            print(f"Error generating image with DALL-E: {e}")
            raise RuntimeError(f"Unknown DALL-E error: {e}")
        
    def generate_image_with_pollinations(self, prompt, model="flux"):
        """Generate image using Pollinations.ai API."""
        try:
            encoded_prompt = urllib.parse.quote(prompt)
            url = f"https://image.pollinations.ai/prompt/{encoded_prompt}"
            params = {
                "model": model,
                "width": 1024,
                "height": 1024,
                "seed": random.randint(1, 10000)
            }
            response = requests.get(url, params=params, stream=True, timeout=30) 
            response.raise_for_status()
            return response.url if self._handle_image_response(response) else None
        except RequestsTimeout:
            error_msg = ("Pollinations.ai Timeout: The service took too long to respond. "
                         "This is often temporary—please try pressing 'Generate Image' again.")
            print(error_msg)
            raise RuntimeError(error_msg)
        except requests.HTTPError as e:
            if e.response.status_code == 429:
                error_msg = ("Pollinations.ai Rate Limit: Too many requests. Please wait a moment and try again.")
            elif e.response.status_code >= 500:
                error_msg = ("Pollinations.ai Server Error: The service is experiencing issues. Please try again later.")
            else:
                error_msg = f"Pollinations.ai HTTP Error: {e.response.status_code} - {e.response.reason}"
            print(error_msg)
            raise RuntimeError(error_msg)
        except Exception as e:
            print(f"Error generating image with Pollinations.ai: {e}")
            raise RuntimeError(f"Pollinations.ai error: {e}")

    def generate_image_with_huggingface(self, prompt):
        """Generate image using Hugging Face Stable Diffusion XL."""
        if not self.hf_token:
            raise RuntimeError("Stable Diffusion Error: HUGGINGFACE_API_TOKEN is missing in the .env file.")
            
        try:
            headers = {"Authorization": f"Bearer {self.hf_token}"}
            payload = {"inputs": prompt}
            response = requests.post(self.api_config.hf_api_url, headers=headers, json=payload, timeout=60)
            
            # Check response before trying to process as image
            content_type = response.headers.get('content-type', '')
            
            # If response is JSON, it's likely an error message
            if 'application/json' in content_type:
                try:
                    error_data = response.json()
                    error_msg = error_data.get('error', str(error_data))
                    
                    # Check for specific quota/billing errors
                    if 'quota' in error_msg.lower() or 'rate limit' in error_msg.lower():
                        raise RuntimeError(
                            "Stable Diffusion Quota Exceeded: You've used up your free credits.\n\n"
                            "Your API token is VALID, but you have no remaining quota.\n\n"
                            "Options:\n"
                            "  • Wait for monthly quota reset\n"
                            "  • Upgrade your plan at: https://huggingface.co/pricing\n"
                            "  • Check usage at: https://huggingface.co/settings/billing"
                        )
                    elif 'loading' in error_msg.lower():
                        raise RuntimeError(
                            "Stable Diffusion Model Loading: The model is currently loading.\n\n"
                            "Please wait 20-30 seconds and try again."
                        )
                    else:
                        raise RuntimeError(f"Stable Diffusion API Error: {error_msg}")
                except ValueError:
                    # Not valid JSON
                    pass
            
            # Now check HTTP status
            response.raise_for_status()
            
            # Check if we got image data
            if not content_type.startswith('image/'):
                raise RuntimeError(
                    f"Stable Diffusion Error: Unexpected response type '{content_type}'.\n\n"
                    "Expected image data but received something else."
                )
            
            # Try to load the image
            return Image.open(io.BytesIO(response.content))
            
        except RequestsTimeout:
            error_msg = ("Stable Diffusion Timeout: The model is busy or the network connection timed out. "
                         "This is often temporary—please try pressing 'Generate Image' again.")
            print(error_msg)
            raise RuntimeError(error_msg)
        except requests.HTTPError as e:
            response_text = ""
            try:
                response_text = e.response.text.lower()
            except:
                pass
            
            if e.response.status_code == 401:
                error_msg = ("Stable Diffusion Authentication Error: Your API token is invalid or has expired.\n\n"
                            "Please check your token at: https://huggingface.co/settings/tokens")
            elif e.response.status_code == 429:
                error_msg = ("Stable Diffusion Rate Limit: You've exceeded your quota or rate limit.\n\n"
                            "Your API token is VALID, but quota is exhausted.\n\n"
                            "Check your usage at: https://huggingface.co/settings/billing")
            elif e.response.status_code == 503:
                error_msg = ("Stable Diffusion Service Unavailable: The model is loading or service is down.\n\n"
                            "Please wait 20-30 seconds and try again.")
            else:
                error_msg = f"Stable Diffusion HTTP Error {e.response.status_code}: {e.response.reason}"
            print(error_msg)
            raise RuntimeError(error_msg)
        except RuntimeError:
            # Re-raise our custom errors
            raise
        except Exception as e:
            print(f"Error generating image with Stable Diffusion: {e}")
            raise RuntimeError(f"Stable Diffusion error: {e}")
        
    def generate_timestamp_filename(self, image_type, file_format):
        """Generate filename with timestamp."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return f"image-generator-{image_type}@{timestamp}.{file_format.lower()}"

    def download_and_save_image(self, image_url, filename, file_format="png"):
        """Download and save the generated image in specified format."""
        try:
            response = requests.get(image_url, timeout=30)
            response.raise_for_status()
            image_data = io.BytesIO(response.content)
            image = Image.open(image_data)

            if file_format.lower() == "jpg":
                image = image.convert("RGB")
                image.save(filename, "JPEG", quality=95)
            else:
                image.save(filename, "PNG")

            print(f"SAVED AS: {filename}\n")
            return image
        except RequestsTimeout:
            error_msg = ("Image Download Timeout: Failed to download the generated image. "
                         "This is often a temporary issue—please try pressing 'Generate Image' again.")
            print(error_msg)
            raise RuntimeError(error_msg)
        except Exception as e:
            print(f"Error downloading: {e}")
            raise RuntimeError(f"Error downloading image: {e}")
    
    def generate_complete_image(self, basic_prompt, image_type, service="dalle", file_format="png"):
        """Complete pipeline: Image generation → Save with timestamp."""
        print(f"FINAL PROMPT: {basic_prompt}")
        print(f"SERVICE: {service.upper()}")
        
        service_handlers = {
            "dalle": lambda: self.generate_image_with_dalle(basic_prompt),
            "pollinations": lambda: self.generate_image_with_pollinations(basic_prompt),
            "huggingface": lambda: self.generate_image_with_huggingface(basic_prompt)
        }
        
        if service.lower() not in service_handlers:
            print(f"Unknown service: {service}")
            return None
        
        result = service_handlers[service.lower()]()
        if not result:
            return None
        
        if service.lower() in ["dalle", "pollinations"]:
            filename = self.generate_timestamp_filename(image_type, file_format)
            return self.download_and_save_image(result, filename, file_format)
        else:
            filename = self.generate_timestamp_filename(image_type, file_format)
            try:
                if file_format.lower() == "jpg":
                    result = result.convert("RGB")
                    result.save(filename, "JPEG", quality=95)
                else:
                    result.save(filename, "PNG")
                print(f"SAVED AS: {filename}\n")
                return result
            except Exception as e:
                print(f"Error saving Stable Diffusion image: {e}")
                raise RuntimeError(f"Error saving Stable Diffusion image: {e}")


class ImageGeneratorGUI:
    """Main GUI application for image generation using tkinter."""
    
    def __init__(self, root, version, width, height):
        self.root = root
        self.width = width
        self.height = height
        self.version = version
        self.generator = None
        self.init_successful = False
        self.error_manager = ErrorManager(self)
        self.prompt_history = []
        self.current_image = None
        self.is_generating = False
        self.zoom_factor = 1.0
        self.original_image = None

        # Set icon with silent fail
        try:
            self.root.iconbitmap(resource_path('images/icon.ico'))
        except Exception:
            pass  # Silently fail if icon cannot be loaded
        
        # Track permanent availability states
        self.gemini_permanently_available = False
        self.dalle_permanently_available = False
        self.hf_permanently_available = False
    
        # Setup GUI first
        self.setup_gui()
        
        # Set initializing status immediately
        self.status_label.config(text="Initializing and validating API keys...")
        self.progress_var.set("Initializing...")
        self.progress_label.config(bg="lightblue")
        
        # Force UI update before starting initialization
        self.root.update_idletasks()
        
        # Then initialize generator with proper timing
        self.root.after(100, self.initialize_generator)
    
    def initialize_generator(self):
        """Initialize the generator after GUI is visible."""
        try:
            self.generator = ImageGenerator(self.error_manager)
            validation_status = self.generator.api_config.initialize_apis()
            
            # Set permanent availability flags based on initial validation
            self.gemini_permanently_available = validation_status['gemini']['available']
            self.dalle_permanently_available = validation_status['openai']['available']
            self.hf_permanently_available = validation_status['huggingface']['available']
            
            # Check if any keys are missing
            missing_keys = []
            for service, status in validation_status.items():
                if not status['available'] and status['error']:
                    missing_keys.append(f"  • {service.upper()}: {status['error']}")
            
            # Show single popup if keys are missing
            if missing_keys:
                error_details = "\n".join(missing_keys)
                message = f"""IMPORTANT

Service Availability:
  • Services marked with a ✗ in the status bar have invalid API keys/tokens
  • Services marked with a ✓ in the status bar have valid API keys/tokens
  • You may still encounter quota or billing errors when generating images/prompts

Without Gemini API:
  • Random prompt generation is disabled
  • "Surprise Me!" feature is disabled
  • You can still enter prompts manually

Without DALL-E API:
  • DALL-E image generation is disabled
  • Other services remain available

Without Stable Diffusion API:
  • Stable Diffusion image generation is disabled
  • Other services remain available


WHAT WORKS WITHOUT CONFIGURATION

Pollinations.ai is always available and requires no API keys.
You can generate images from manual prompts immediately.


HOW TO ENABLE MISSING FEATURES

Gemini (for prompt generation):
  • Get free API key: https://ai.google.dev/gemini-api/docs/api-key
  • Add to .env file: GEMINI_API_KEY=your_key_here
  • Set (text-out) model name, e.g.: GEMINI_MODEL=gemini-2.5-flash
  • Available free tier models: https://ai.google.dev/gemini-api/docs/rate-limits#free-tier
  • Free tier: Limited daily requests

DALL-E (for high-quality images):
  • Get API key: https://platform.openai.com/api-keys
  • Add to .env file: OPENAI_API_KEY=your_key_here
  • Paid service: Charges per image generated

Stable Diffusion (for balanced quality/speed):
  • Get token: https://huggingface.co/settings/tokens
  • Add to .env file: HUGGINGFACE_API_TOKEN=your_token_here
  • Free tier: Limited monthly credits

After updating your .env file, restart the application."""

                self.root.after(500, lambda: DialogManager.show_dialog(
                    "API Configuration Issues", 
                    message, 
                    "warning", 
                    parent=self.root
                ))            
            self.init_successful = True
            self.validation_status = validation_status
            
            # Clear initialization status
            self.progress_var.set("")
            self.progress_label.config(bg="SystemButtonFace")
            
            self.root.after(100, self.update_gui_with_generator)
            
        except Exception as e:
            self.error_manager.add_error(
                "Fatal Initialization Error", 
                f"Complete initialisation failure.\n\nError: {str(e)}",
                "error"
            )
            self.generator = None
            self.init_successful = False
            self.gemini_permanently_available = False
            self.dalle_permanently_available = False
            self.hf_permanently_available = False
            
            # Clear initialization status even on error
            self.progress_var.set("")
            self.progress_label.config(bg="SystemButtonFace")
            self.status_label.config(text="Initialization failed - check configuration")
            
            self.root.after(100, self.setup_fallback_controls)
        
    def update_gui_with_generator(self):
        """Update the GUI once the generator is successfully initialised."""
        if self.generator and hasattr(self.generator, 'domain_guidance'):
            self.populate_domain_tree()
            self.populate_style_tree()  # Changed from populate_style_combo()
            
            # Enable/disable controls based on PERMANENT availability status
            if self.gemini_permanently_available:
                self.random_prompt_btn.config(state="normal")
                self.generate_prompt_btn.config(state="normal")
                self.surprise_btn.config(state="normal")
                self.set_domain_frame_state(True)
                self.style_search.config(state="normal")
                # Style tree state is handled by set_domain_frame_state
                self.status_label.config(text="Generator initialised - All available services ready")
            else:
                # Permanently disable Gemini-dependent features
                self.random_prompt_btn.config(state="disabled")
                self.generate_prompt_btn.config(state="disabled")
                self.surprise_btn.config(state="disabled")
                self.set_domain_frame_state(False)
                self.style_search.config(state="disabled")
                self.status_label.config(text="Generator initialised - Pollinations.ai ready, but Gemini-dependent features are disabled")
            
            # Update service combo with availability indicators
            self.update_service_combo_availability()

    def update_service_combo_availability(self):
        """Update service combo to show which services are available."""
        services = []
        
        # Pollinations.ai is always available (no API key needed)
        services.append("Pollinations.ai: free, no api-key required")
        
        # DALL-E availability (based on token validity only)
        if self.dalle_permanently_available:
            services.append("DALL-E 3: paid service, api-key required")
        else:
            services.append("DALL-E 3 (UNAVAILABLE - missing/invalid API key)")
        
        # Stable Diffusion availability (based on token validity only)
        if self.hf_permanently_available:
            services.append("Stable Diffusion XL: limited free credits, api-key required")
        else:
            services.append("Stable Diffusion XL (UNAVAILABLE - missing/invalid API token)")
        
        current_selection = self.service_combo.get()
        self.service_combo['values'] = services
        
        # Keep current selection if still available, otherwise default to Pollinations.ai
        if current_selection in services:
            self.service_combo.set(current_selection)
        else:
            self.service_combo.current(0)  # Default to Pollinations.ai

    def setup_gui(self):
        """Initialize the user interface."""
        
        self.root.title(f"Surprise Me Image Generater {self.version} - Created by Peer-Olaf Siebers with the support of diverse LLMs")
        self.root.geometry(f"{self.width}x{self.height}")
        self.root.minsize(self.width, self.height)

        self.create_menu_bar()
        
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        paned_window = ttk.PanedWindow(main_frame, orient=tk.HORIZONTAL)
        paned_window.pack(fill=tk.BOTH, expand=True)

        left_frame = ttk.Frame(paned_window, relief="flat")
        left_frame.pack(fill=tk.Y)
        paned_window.add(left_frame, weight=0)
        
        right_frame = ttk.Frame(paned_window, relief="flat")
        right_frame.pack(fill=tk.BOTH, expand=True)
        paned_window.add(right_frame, weight=1)
        
        self.setup_left_panel(left_frame)
        self.setup_right_panel(right_frame)
        
        self.setup_status_bar()
        
        if self.generator and hasattr(self.generator, 'domain_guidance'):
            self.populate_domain_tree()
            self.populate_style_tree()
        else:
            self.setup_fallback_controls()
        
        self.update_word_count()

    def setup_fallback_controls(self):
        """Setup controls when generator is not available."""
        self.domain_data = {}
        for item in self.domain_tree.get_children():
            self.domain_tree.delete(item)
        self.domain_tree.insert("", "end", text="Generator not available")
        
        # Disable the entire domain frame
        self.set_domain_frame_state(False)
        
        # Clear and disable the style tree (replaces the old style_combo)
        for item in self.style_tree.get_children():
            self.style_tree.delete(item)
        self.style_tree.insert("", "end", text="Styles not available")
        
        # Disable all generator-dependent controls
        self.random_prompt_btn.config(state="disabled")
        self.generate_prompt_btn.config(state="disabled")
        self.surprise_btn.config(state="disabled")
        self.style_search.config(state="disabled")
        
        # Disable the style tree interactions
        self.style_tree.config(selectmode="none")
        self.style_tree.bind("<Button-1>", lambda e: "break")

    def create_menu_bar(self):
        """Create application menu bar."""
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="Save Image", command=self.save_image, accelerator="Ctrl+S")
        file_menu.add_command(label="Exit", command=self.root.quit, accelerator="Ctrl+Q")
    
        edit_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Edit", menu=edit_menu)
        edit_menu.add_command(label="Clear Prompt", command=self.clear_prompt, accelerator="Ctrl+L")
        
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="API Troubleshooting", command=self.show_api_issues)
        help_menu.add_command(label="About", command=self.show_about)
        
        self.root.bind('<Control-s>', lambda e: self.save_image())
        self.root.bind('<Control-q>', lambda e: self.root.quit())
        self.root.bind('<Control-l>', lambda e: self.clear_prompt())
        
    def setup_left_panel(self, parent):
        """Create the left control panel."""
        canvas = tk.Canvas(parent, width=700, highlightthickness=0, relief="flat")
        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        self.create_domain_section(scrollable_frame)
        self.create_style_section(scrollable_frame)
        self.create_prompt_section(scrollable_frame)
        self.create_options_section(scrollable_frame)
        self.create_generation_controls(scrollable_frame)
        
        def on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        
        canvas.bind("<MouseWheel>", on_mousewheel)
        scrollable_frame.bind("<MouseWheel>", on_mousewheel)
    
    def setup_right_panel(self, parent):
        """Create the right panel for image display."""
        self.notebook = ttk.Notebook(parent)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        
        image_frame = ttk.Frame(self.notebook)
        self.notebook.add(image_frame, text="Current Image")
        
        # Zoom controls frame
        zoom_controls_frame = ttk.Frame(image_frame)
        zoom_controls_frame.pack(fill=tk.X, padx=5, pady=(5, 0))
        
        ttk.Label(zoom_controls_frame, text="Zoom:").pack(side=tk.LEFT, padx=(0, 5))
        
        self.zoom_out_btn = ttk.Button(zoom_controls_frame, text="−", command=self.zoom_out, width=3, state="disabled")
        self.zoom_out_btn.pack(side=tk.LEFT, padx=2)
        ToolTip(self.zoom_out_btn, "Zoom out the image (Ctrl + Mouse Wheel)")
        
        self.zoom_fit_btn = ttk.Button(zoom_controls_frame, text="Fit", command=self.zoom_fit, state="disabled")
        self.zoom_fit_btn.pack(side=tk.LEFT, padx=2)
        ToolTip(self.zoom_fit_btn, "Fit image to panel size")
        
        self.zoom_in_btn = ttk.Button(zoom_controls_frame, text="+", command=self.zoom_in, width=3, state="disabled")
        self.zoom_in_btn.pack(side=tk.LEFT, padx=2)
        ToolTip(self.zoom_in_btn, "Zoom in the image (Ctrl + Mouse Wheel)")
        
        self.zoom_label = ttk.Label(zoom_controls_frame, text="100%")
        self.zoom_label.pack(side=tk.LEFT, padx=(10, 0))
        
        image_container = ttk.Frame(image_frame)
        image_container.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.image_canvas = tk.Canvas(image_container, bg="white")
        v_scrollbar = ttk.Scrollbar(image_container, orient="vertical", command=self.image_canvas.yview)
        
        self.image_canvas.configure(yscrollcommand=v_scrollbar.set)
        self.image_canvas.pack(side="left", fill="both", expand=True)
        v_scrollbar.pack(side="right", fill="y")
        
        h_scrollbar = ttk.Scrollbar(image_frame, orient="horizontal", command=self.image_canvas.xview)
        self.image_canvas.configure(xscrollcommand=h_scrollbar.set)
        h_scrollbar.pack(side="bottom", fill="x")
        
        controls_frame = ttk.Frame(image_frame)
        controls_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.save_btn = ttk.Button(controls_frame, text="Save Image", command=self.save_image, state="disabled")
        self.save_btn.pack(side=tk.LEFT, padx=5)
        ToolTip(self.save_btn, "Save the generated image to a file (Ctrl+S)")
        
        self.copy_prompt_btn = ttk.Button(controls_frame, text="Copy Prompt", command=self.copy_current_prompt, state="disabled")
        self.copy_prompt_btn.pack(side=tk.LEFT, padx=5)
        ToolTip(self.copy_prompt_btn, "Copy the current prompt to clipboard")
        
        history_frame = ttk.Frame(self.notebook)
        self.notebook.add(history_frame, text="Prompt History")
        
        history_controls = ttk.Frame(history_frame)
        history_controls.pack(fill=tk.X, padx=5, pady=5)
        
        clear_history_btn = ttk.Button(history_controls, text="Clear History", command=self.clear_history)
        clear_history_btn.pack(side=tk.LEFT)
        ToolTip(clear_history_btn, "Delete all saved prompts from history")
        
        history_list_frame = ttk.Frame(history_frame)
        history_list_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.history_listbox = tk.Listbox(history_list_frame)
        history_scrollbar = ttk.Scrollbar(history_list_frame, orient="vertical", command=self.history_listbox.yview)
        
        self.history_listbox.configure(yscrollcommand=history_scrollbar.set)
        self.history_listbox.bind('<Double-Button-1>', self.load_from_history)
        
        self.history_listbox.pack(side="left", fill="both", expand=True)
        history_scrollbar.pack(side="right", fill="y")
    
    def create_domain_section(self, parent):
        """Create domain selection section."""
        self.domain_frame = ttk.LabelFrame(parent, text="Academic Domain", padding=10)
        self.domain_frame.pack(fill=tk.X, padx=5, pady=5)
        
        search_frame = ttk.Frame(self.domain_frame)
        search_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(search_frame, text="Search:").pack(side=tk.LEFT)
        self.domain_search = ttk.Entry(search_frame)
        self.domain_search.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 5))
        self.domain_search.bind('<KeyRelease>', self.filter_domains)
        
        # Add selected domain display
        selected_frame = ttk.Frame(self.domain_frame)
        selected_frame.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Label(selected_frame, text="Selected:").pack(side=tk.LEFT)
        self.selected_domain_label = ttk.Label(selected_frame, text="None", anchor=tk.W)
        self.selected_domain_label.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 0))
        
        tree_frame = ttk.Frame(self.domain_frame)
        tree_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.domain_tree = ttk.Treeview(tree_frame, height=4, show='tree')
        tree_scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=self.domain_tree.yview)
        
        self.domain_tree.configure(yscrollcommand=tree_scrollbar.set)
        self.domain_tree['show'] = 'tree'
        
        self.domain_tree.bind('<<TreeviewSelect>>', self.on_domain_tree_select)
        
        self.domain_tree.pack(side="left", fill="both", expand=True)
        tree_scrollbar.pack(side="right", fill="y")
 
    def set_domain_frame_state(self, enabled):
        """Enable or disable the domain and style frames with visual feedback."""
        state = "normal" if enabled else "disabled"

        # Configure styles for disabled state
        style = ttk.Style()
        
        # DOMAIN FRAME STATE
        if not enabled:
            # Create and configure disabled style for Treeview
            style.configure("Disabled.Treeview", 
                           background="SystemButtonFace",
                           fieldbackground="SystemButtonFace",
                           relief="raised")
            # Apply the disabled style to the domain treeview
            self.domain_tree.config(style="Disabled.Treeview")
        else:
            # Revert to default style when enabled
            self.domain_tree.config(style="Treeview")
        
        # Disable/enable the domain search entry
        self.domain_search.config(state=state)
        
        # Disable/enable the domain tree
        if enabled:
            self.domain_tree.config(selectmode="browse")
            # Re-enable tree interactions
            self.domain_tree.unbind("<Button-1>")
        else:
            self.domain_tree.config(selectmode="none")
            # Clear any selection
            for item in self.domain_tree.selection():
                self.domain_tree.selection_remove(item)
            # Disable all tree interactions including expand/collapse
            self.domain_tree.bind("<Button-1>", lambda e: "break")
        
        # STYLE FRAME STATE
        if not enabled:
            # Apply the disabled style to the style treeview
            self.style_tree.config(style="Disabled.Treeview")
        else:
            # Revert to default style when enabled
            self.style_tree.config(style="Treeview")
        
        # Disable/enable the style search entry
        self.style_search.config(state=state)
        
        # Disable/enable the style tree
        if enabled:
            self.style_tree.config(selectmode="browse")
            # Re-enable tree interactions
            self.style_tree.unbind("<Button-1>")
        else:
            self.style_tree.config(selectmode="none")
            # Clear any selection
            for item in self.style_tree.selection():
                self.style_tree.selection_remove(item)
            # Disable all tree interactions including expand/collapse
            self.style_tree.bind("<Button-1>", lambda e: "break")
        
        # Apply visual styling to show disabled state for both frames
        if not enabled:
            # Grey out the label frames
            style.configure("Disabled.TLabelframe", foreground="grey")
            style.configure("Disabled.TLabelframe.Label", foreground="grey")
            self.domain_frame.config(style="Disabled.TLabelframe")
            self.style_frame.config(style="Disabled.TLabelframe")
            
            # Grey out domain tree items and collapse all
            for item in self.domain_tree.get_children():
                self.domain_tree.item(item, tags=('disabled',), open=False)
                for child in self.domain_tree.get_children(item):
                    self.domain_tree.item(child, tags=('disabled',))
            self.domain_tree.tag_configure('disabled', foreground='grey')
            
            # Grey out style tree items and collapse all
            for item in self.style_tree.get_children():
                self.style_tree.item(item, tags=('disabled',), open=False)
                for child in self.style_tree.get_children(item):
                    self.style_tree.item(child, tags=('disabled',))
            self.style_tree.tag_configure('disabled', foreground='grey')
        else:
            # Restore normal styling for both frames
            self.domain_frame.config(style="TLabelframe")
            self.style_frame.config(style="TLabelframe")
            
            # Restore normal domain tree colors
            for item in self.domain_tree.get_children():
                self.domain_tree.item(item, tags=())
                for child in self.domain_tree.get_children(item):
                    self.domain_tree.item(child, tags=())
            
            # Restore normal style tree colors
            for item in self.style_tree.get_children():
                self.style_tree.item(item, tags=())
                for child in self.style_tree.get_children(item):
                    self.style_tree.item(child, tags=())
                
    def create_style_section(self, parent):
        """Create style selection section as a tree (replacing combo box)."""
        self.style_frame = ttk.LabelFrame(parent, text="Artistic Style", padding=10)  # Changed to self.style_frame
        self.style_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)  # Updated reference
        
        search_frame = ttk.Frame(self.style_frame)  # Updated reference
        search_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(search_frame, text="Search:").pack(side=tk.LEFT)
        self.style_search = ttk.Entry(search_frame)
        self.style_search.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 0))
        self.style_search.bind('<KeyRelease>', self.filter_styles_tree)
        
        # Add selected style display
        selected_style_frame = ttk.Frame(self.style_frame)  # Updated reference
        selected_style_frame.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Label(selected_style_frame, text="Selected:").pack(side=tk.LEFT)
        self.selected_style_label = ttk.Label(selected_style_frame, text="None", anchor=tk.W)
        self.selected_style_label.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 0))
        
        tree_frame = ttk.Frame(self.style_frame)  # Updated reference
        tree_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.style_tree = ttk.Treeview(tree_frame, height=4, show='tree')
        style_scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=self.style_tree.yview)
        
        self.style_tree.configure(yscrollcommand=style_scrollbar.set)
        self.style_tree.bind('<<TreeviewSelect>>', self.on_style_tree_select)
        
        self.style_tree.pack(side="left", fill="both", expand=True)
        style_scrollbar.pack(side="right", fill="y")
        
        # Store style data
        self.style_data = {}
        
        # Populate the style tree
        self.populate_style_tree()

    def populate_style_tree(self):
        """Populate the style tree widget with categories and styles."""
        self.style_data = {}
        
        # Clear existing items
        for item in self.style_tree.get_children():
            self.style_tree.delete(item)
        
        if not self.generator or not hasattr(self.generator, 'styles'):
            self.style_tree.insert("", "end", text="Styles not available")
            return
        
        # Add special options
        special_id = self.style_tree.insert("", "end", text="Special Options", open=False)
        self.style_data[special_id] = {"type": "parent", "style": "Special Options"}
        
        none_id = self.style_tree.insert(special_id, "end", text="None")
        self.style_data[none_id] = {
            "type": "child", 
            "style": "none",
            "description": "No specific artistic style will be applied"
        }
        
        # Displayed as "Random" in tree, but stored as "Any Style (Random)"
        random_id = self.style_tree.insert(special_id, "end", text="Random")
        self.style_data[random_id] = {
            "type": "child", 
            "style": "Any Style (Random)",  # Keep full string internally
            "description": "Randomly select from all available artistic styles"
        }
        
        # Add style categories
        for category, style_list in self.generator.styles.items():
            category_id = self.style_tree.insert("", "end", text=category, open=False)
            self.style_data[category_id] = {"type": "parent", "style": category}
            
            for style in style_list:
                display_text = style[:90] + "." if len(style) > 90 else style
                style_id = self.style_tree.insert(category_id, "end", text=display_text)
                self.style_data[style_id] = {
                    "type": "child", 
                    "style": style,
                    "description": style,
                    "display_text": display_text
                }
        
        # Default selection to "None"
        for child_id in self.style_tree.get_children(special_id):
            if self.style_tree.item(child_id, "text") == "None":
                self.style_tree.selection_set(child_id)
                self.selected_style_label.config(text="None")
                break

    def on_style_tree_select(self, event):
        """Handle style tree selection to prevent parent node selection and update display."""
        selection = self.style_tree.selection()
        if selection:
            item_id = selection[0]
            item_data = self.style_data.get(item_id, {})
            
            # Prevent selecting parent nodes
            if item_data.get("type") == "parent":
                self.style_tree.selection_remove(item_id)
                return
            
            style_str = item_data.get("style", "none")
            
            # Handle special display logic
            if style_str == "none":
                display_text = "None"
            elif style_str == "Any Style (Random)":
                display_text = "Any Style (Random)"
            else:
                display_text = item_data.get("display_text", style_str[:90] + "." if len(style_str) > 90 else style_str)
            
            self.selected_style_label.config(text=display_text)

    def create_prompt_section(self, parent):
        """Create prompt input section."""
        prompt_frame = ttk.LabelFrame(parent, text="Prompt", padding=10)
        prompt_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.prompt_text = scrolledtext.ScrolledText(prompt_frame, height=5, wrap=tk.WORD)
        self.prompt_text.pack(fill=tk.X, pady=5)
        self.prompt_text.bind('<KeyRelease>', lambda e: self.update_word_count())
        
        self.word_count_label = tk.Label(prompt_frame, text="Words: 0", font=("Arial", 8), fg="grey")
        self.word_count_label.pack(anchor=tk.W)
        
        prompt_controls = ttk.Frame(prompt_frame)
        prompt_controls.pack(fill=tk.X, pady=5)
        
        self.random_prompt_btn = ttk.Button(prompt_controls, text="Random Prompt", command=self.generate_random_prompt_threaded)
        self.random_prompt_btn.pack(side=tk.LEFT, padx=(0, 5))
        ToolTip(self.random_prompt_btn, "Generate a completely new random prompt using selected domain and style")
        
        self.generate_prompt_btn = ttk.Button(prompt_controls, text="Enhance Prompt", command=self.generate_prompt_threaded)
        self.generate_prompt_btn.pack(side=tk.LEFT, padx=(0, 5))
        ToolTip(self.generate_prompt_btn, "Enhance the current prompt text using selected domain and style")
        
        clear_prompt_btn = ttk.Button(prompt_controls, text="Clear", command=self.clear_prompt)
        clear_prompt_btn.pack(side=tk.LEFT)
        ToolTip(clear_prompt_btn, "Clear all text from the prompt field")
    
    def create_options_section(self, parent):
        """Create generation options section."""
        options_frame = ttk.LabelFrame(parent, text="Generation Options", padding=10)
        options_frame.pack(fill=tk.X, padx=5, pady=5)
        
        service_frame = ttk.Frame(options_frame)
        service_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(service_frame, text="Service:").pack(side=tk.LEFT)
        self.service_combo = ttk.Combobox(service_frame, state="readonly")
        self.service_combo['values'] = [
            "Pollinations.ai: free, no api-key required",
            "DALL-E 3: paid service, api-key required", 
            "Stable Diffusion XL: limited free credits, api-key required"
        ]
        self.service_combo.current(0)
        self.service_combo.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 0))
        
        format_frame = ttk.Frame(options_frame)
        format_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(format_frame, text="Format:").pack(side=tk.LEFT)
        self.format_combo = ttk.Combobox(format_frame, state="readonly")
        self.format_combo['values'] = ["PNG", "JPG"]
        self.format_combo.current(0)
        self.format_combo.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 0))
        
    def create_generation_controls(self, parent):
        """Create generation control buttons."""
        controls_frame = ttk.LabelFrame(parent, text="Generation", padding=10)
        controls_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.generate_btn = ttk.Button(controls_frame, text="Generate Image", command=self.generate_image_threaded)
        self.generate_btn.pack(fill=tk.X, pady=5)
        ToolTip(self.generate_btn, "Generate an image using the current prompt and selected service")
        
        self.surprise_btn = ttk.Button(controls_frame, text="Surprise Me!", command=self.surprise_with_clear)
        self.surprise_btn.pack(fill=tk.X, pady=5)
        ToolTip(self.surprise_btn, "Clear prompt and generate a random image with random domain and style")

    def surprise_with_clear(self):
        """Clear prompt then generate surprise image."""
        self.clear_prompt()
        self.surprise_generation_threaded()

    def setup_status_bar(self):
        """Create status bar with real-time information."""
        status_container = ttk.Frame(self.root, padding=1)
        status_container.pack(side=tk.BOTTOM, fill=tk.X)
        
        status_frame = ttk.Frame(status_container)
        status_frame.pack(side=tk.BOTTOM, fill=tk.X)
        
        # Main status message
        self.status_label = tk.Label(status_frame, text="Ready", relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # Service status indicators
        self.service_status_frame = ttk.Frame(status_frame)
        self.service_status_frame.pack(side=tk.RIGHT, padx=(5, 0))
        
        # Add explanatory label
        #ttk.Label(self.service_status_frame, text="API Key Status:", 
        #          font=("Arial", 10)).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Label(self.service_status_frame, text="API Key Status: ", width=20, anchor="e"
                                      ).pack(side=tk.LEFT, padx=1)
        
        # Gemini status with model info
        self.gemini_status = tk.Label(self.service_status_frame, text="Gemini: ?", 
                                      relief=tk.SUNKEN, width=20)
        self.gemini_status.pack(side=tk.LEFT, padx=1)
        
        # DALL-E status
        self.dalle_status = tk.Label(self.service_status_frame, text="DALL-E: ?", 
                                     relief=tk.SUNKEN, width=20)
        self.dalle_status.pack(side=tk.LEFT, padx=1)
        
        # HF status
        self.hf_status = tk.Label(self.service_status_frame, text="Stable Diffusion: ?", 
                                 relief=tk.SUNKEN, width=20)
        self.hf_status.pack(side=tk.LEFT, padx=1)
        
        # Add right-click context menu for HF status
        self.hf_status.bind("<Button-3>", self.show_hf_status_menu)
        
        # Progress indicator
        self.progress_var = tk.StringVar()
        self.progress_label = tk.Label(status_frame, textvariable=self.progress_var, 
                                       relief=tk.SUNKEN, width=20)
        self.progress_label.pack(side=tk.RIGHT, padx=(5, 0))
        
        # Update service status immediately after initialization
        self.root.after(1000, self.update_service_status_display)
    
    def refresh_hf_token_status(self):
        """Refresh Hugging Face token status and update indicator."""
        try:
            # Revalidate the HF token
            result = self.generator.api_config.revalidate_hf_token()
            
            # Update the validation status
            self.validation_status['huggingface']['available'] = result['available']
            self.validation_status['huggingface']['error'] = result['error']
            
            # Update the status indicator
            self.update_service_status_display()
            
            # Show result to user
            if result['available']:
                messagebox.showinfo("Token Status", "Hugging Face token is valid and ready to use!")
            else:
                error_msg = result['error'] or "Token validation failed"
                messagebox.showerror("Token Status", f"Hugging Face token validation failed:\n\n{error_msg}")
                
        except Exception as e:
            messagebox.showerror("Error", f"Failed to refresh token status: {str(e)}")
    
    def show_hf_status_menu(self, event):
        """Show context menu for Hugging Face status indicator."""
        context_menu = tk.Menu(self.root, tearoff=0)
        context_menu.add_command(label="Refresh Token Status", command=self.refresh_hf_token_status)
        context_menu.add_command(label="Debug Token Validation", command=self.debug_hf_token_validation)
        context_menu.add_command(label="Test Token with Simple Generation", command=self.test_hf_token_with_generation)
        context_menu.add_separator()
        
        # Show current status info
        hf_info = self.validation_status.get('huggingface', {})
        if hf_info.get('available'):
            context_menu.add_command(label="Status: Valid ✓", state="disabled")
        else:
            error = hf_info.get('error', 'Unknown error')
            context_menu.add_command(label=f"Status: Invalid - {error[:30]}...", state="disabled")
        
        try:
            context_menu.tk_popup(event.x_root, event.y_root)
        finally:
            context_menu.grab_release()
    
    def debug_hf_token_validation(self):
        """Debug Hugging Face token validation with detailed output."""
        try:
            token = self.generator.api_config.hf_token
            if not token:
                messagebox.showerror("Debug Info", "No Hugging Face token found in .env file")
                return
            
            debug_info = []
            debug_info.append(f"Token: {token[:10]}...{token[-4:] if len(token) > 14 else '***'}")
            debug_info.append(f"Token length: {len(token)}")
            debug_info.append(f"Starts with 'hf_': {token.startswith('hf_')}")
            debug_info.append("")
            
            # Test each validation method individually
            debug_info.append("=== Validation Method Results ===")
            
            # Method 1: Direct API
            result1 = self.generator.api_config._validate_hf_token_direct_api(token)
            debug_info.append(f"1. Direct API: {'✓' if result1['available'] else '✗'}")
            if result1['error']:
                debug_info.append(f"   Error: {result1['error']}")
            if result1.get('user_info'):
                debug_info.append(f"   User: {result1['user_info']}")
            
            # Method 2: Hub Library
            result2 = self.generator.api_config._validate_hf_token_hub_library(token)
            debug_info.append(f"2. Hub Library: {'✓' if result2['available'] else '✗'}")
            if result2['error']:
                debug_info.append(f"   Error: {result2['error']}")
            if result2.get('user_info'):
                debug_info.append(f"   User: {result2['user_info']}")
            
            # Method 3: Model Access
            result3 = self.generator.api_config._validate_hf_token_model_access(token)
            debug_info.append(f"3. Model Access: {'✓' if result3['available'] else '✗'}")
            if result3['error']:
                debug_info.append(f"   Error: {result3['error']}")
            if result3.get('user_info'):
                debug_info.append(f"   User: {result3['user_info']}")
            
            debug_info.append("")
            debug_info.append("=== Current Status ===")
            hf_info = self.validation_status.get('huggingface', {})
            debug_info.append(f"Available: {hf_info.get('available', False)}")
            debug_info.append(f"Error: {hf_info.get('error', 'None')}")
            
            # Show debug info in a dialog
            debug_text = "\n".join(debug_info)
            messagebox.showinfo("Hugging Face Token Debug Info", debug_text)
            
        except Exception as e:
            messagebox.showerror("Debug Error", f"Failed to debug token validation: {str(e)}")
    
    def test_hf_token_with_generation(self):
        """Test Hugging Face token by attempting a simple image generation."""
        try:
            token = self.generator.api_config.hf_token
            if not token:
                messagebox.showerror("Test Failed", "No Hugging Face token found in .env file")
                return
            
            # Show confirmation dialog
            result = messagebox.askyesno(
                "Test Token with Generation", 
                "This will attempt to generate a simple test image using your Hugging Face token.\n\n"
                "This will use some of your quota but will definitively test if your token works.\n\n"
                "Continue with the test?"
            )
            
            if not result:
                return
            
            # Set loading state
            self.set_loading_state(True, "Testing token with simple generation...")
            
            try:
                # Try to generate a simple image
                test_prompt = "a simple red circle on white background"
                image = self.generator.generate_image_with_huggingface(test_prompt)
                
                if image:
                    # Token works! Update status
                    self.hf_permanently_available = True
                    self.validation_status['huggingface']['available'] = True
                    self.validation_status['huggingface']['error'] = None
                    self.update_service_status_display()
                    
                    messagebox.showinfo(
                        "Token Test Successful", 
                        "Your Hugging Face token is working correctly!\n\n"
                        "The status indicator has been updated to show it as valid.\n\n"
                        "Note: A test image was generated and saved."
                    )
                else:
                    messagebox.showerror("Token Test Failed", "Image generation failed - token may be invalid or quota exhausted")
                    
            except Exception as e:
                error_msg = str(e)
                if "401" in error_msg or "authentication" in error_msg.lower():
                    messagebox.showerror("Token Test Failed", "Authentication failed - your token is invalid or expired")
                elif "quota" in error_msg.lower() or "rate limit" in error_msg.lower():
                    messagebox.showwarning(
                        "Token Test - Quota Issue", 
                        "Your token is valid but you have no remaining quota.\n\n"
                        "This means your token works but you need to wait for quota reset or upgrade your plan."
                    )
                else:
                    messagebox.showerror("Token Test Failed", f"Generation failed: {error_msg}")
            
            finally:
                self.set_loading_state(False)
                
        except Exception as e:
            self.set_loading_state(False)
            messagebox.showerror("Test Error", f"Failed to test token: {str(e)}")

    def update_service_status_display(self):
        """Update the service status indicators in the status bar."""
        if not hasattr(self, 'validation_status'):
            return
        
        # Update Gemini status with model name
        gemini_info = self.validation_status['gemini']
        if gemini_info['available']:
            model_short = gemini_info['model'].replace('gemini-', '')
            self.gemini_status.config(text=f"Gemini: ✓ ({model_short})", bg="#90EE90", fg="black")
        else:
            self.gemini_status.config(text="Gemini: ✗", bg="#FFB6C1", fg="black")
        
        # Update DALL-E status
        dalle_info = self.validation_status['openai']
        if dalle_info['available']:
            self.dalle_status.config(text="DALL-E: ✓", bg="#90EE90", fg="black")
        else:
            self.dalle_status.config(text="DALL-E: ✗", bg="#FFB6C1", fg="black")
        
        # Update Stable Diffusion status (token validity only)
        hf_info = self.validation_status['huggingface']
        if hf_info['available']:
            # Green checkmark means token is valid (quota issues will appear during generation)
            self.hf_status.config(text="StableDiff: ✓", bg="#90EE90", fg="black")
        else:
            # Red X means token is invalid, missing, or authentication failed
            self.hf_status.config(text="StableDiff: ✗", bg="#FFB6C1", fg="black")
        
    def populate_domain_tree(self):
        """Populate the domain tree widget with CORRECT domain strings."""
        self.domain_data = {}
        
        # Clear existing items
        for item in self.domain_tree.get_children():
            self.domain_tree.delete(item)
        
        if not self.generator or not hasattr(self.generator, 'domain_guidance'):
            self.domain_tree.insert("", "end", text="Domains not available")
            return
        
        # Add special options to General category first
        general_id = None
        for domain, subdomains in self.generator.domain_guidance.items():
            if domain == "General" and isinstance(subdomains, dict):
                general_id = self.domain_tree.insert("", "end", text=domain, open=False)
                self.domain_data[general_id] = {"type": "parent", "domain": domain}
                
                # CRITICAL FIX: Add "None" option with EXACT domain string
                none_id = self.domain_tree.insert(general_id, "end", text="None")
                self.domain_data[none_id] = {
                    "type": "child", 
                    "domain": "None",  # MUST be "None" (string)
                    "description": "No academic domain context will be added to the prompt"
                }
                
                # CRITICAL FIX: Add "Random" option with EXACT domain string  
                random_id = self.domain_tree.insert(general_id, "end", text="Random")
                self.domain_data[random_id] = {
                    "type": "child", 
                    "domain": "Any Domain (Random)",  # MUST be this exact string
                    "description": "Randomly select from all available academic domains"
                }
                
                # Add regular General subdomains
                for sub, description in subdomains.items():
                    child_id = self.domain_tree.insert(general_id, "end", text=sub)
                    self.domain_data[child_id] = {
                        "type": "child", 
                        "domain": sub,  # CRITICAL: Just the subdomain name, not full path
                        "description": description
                    }
                break
        
        # Add other domains
        for domain, subdomains in self.generator.domain_guidance.items():
            if domain == "General":
                continue
                
            if isinstance(subdomains, dict):
                parent_id = self.domain_tree.insert("", "end", text=domain, open=False)
                self.domain_data[parent_id] = {"type": "parent", "domain": domain}
                
                for sub, description in subdomains.items():
                    child_id = self.domain_tree.insert(parent_id, "end", text=sub)
                    self.domain_data[child_id] = {
                        "type": "child", 
                        "domain": sub,  # CRITICAL: Just the subdomain name
                        "description": description
                    }
            else:
                # Standalone domains
                item_id = self.domain_tree.insert("", "end", text=domain)
                self.domain_data[item_id] = {
                    "type": "standalone", 
                    "domain": domain, 
                    "description": subdomains
                }
        
        # Set default selection to "None"
        if general_id:
            for child_id in self.domain_tree.get_children(general_id):
                if self.domain_tree.item(child_id, "text") == "None":
                    self.domain_tree.selection_set(child_id)
                    self.selected_domain_label.config(text="None")
                    break

    def get_current_domain_robust(self):
        """Robust method to get current domain selection, with fallbacks."""
        # Method 1: Try direct tree selection
        selection = self.domain_tree.selection()
        if selection:
            item_id = selection[0]
            item_data = self.domain_data.get(item_id, {})
            domain = item_data.get("domain", "None")
            return domain
        
        # Method 2: Try the selected domain label (fallback)
        label_text = self.selected_domain_label.cget("text")
        if label_text and label_text != "None":
            # Try to map label back to domain
            for item_id, item_data in self.domain_data.items():
                if item_data.get("domain") == label_text:
                    return label_text
                display_text = item_data.get("domain", "")
                if display_text and label_text in display_text:
                    return display_text
        
        # Method 3: Default to "None"
        return "None"

    def filter_styles_tree(self, event=None):
        """Filter style tree based on search text while preserving selection."""
        search_text = self.style_search.get().lower()
        
        # STORE CURRENT SELECTION BEFORE CLEARING
        previous_selection = None
        previous_selection_text = None
        if self.style_tree.selection():
            previous_item = self.style_tree.selection()[0]
            previous_selection_text = self.style_tree.item(previous_item, "text")
            previous_selection_data = self.style_data.get(previous_item, {})
            previous_selection = previous_selection_data.get("style", previous_selection_text)
        
        # Clear and rebuild
        for item in self.style_tree.get_children():
            self.style_tree.delete(item)
        self.style_data.clear()
        
        if not self.generator or not hasattr(self.generator, 'styles'):
            self.style_tree.insert("", "end", text="Styles not available")
            return
        
        # Add special options ONLY if they match search or no search
        special_items = {}
        should_show_special = (not search_text or 
                              search_text in "none" or 
                              search_text in "any style" or 
                              search_text in "random")
        
        if should_show_special:
            special_id = self.style_tree.insert("", "end", text="Special Options", open=True)
            self.style_data[special_id] = {"type": "parent", "style": "Special Options"}
            
            # Add "None" option if it matches search
            if not search_text or search_text in "none":
                none_id = self.style_tree.insert(special_id, "end", text="None")
                self.style_data[none_id] = {
                    "type": "child", 
                    "style": "none",
                    "description": "No specific artistic style will be applied"
                }
                special_items["none"] = none_id
            
            # Add "Any Style (Random)" option if it matches search  
            if not search_text or search_text in "any style" or search_text in "random":
                random_id = self.style_tree.insert(special_id, "end", text="Any Style (Random)")
                self.style_data[random_id] = {
                    "type": "child", 
                    "style": "any", 
                    "description": "Randomly select from all available artistic styles"
                }
                special_items["any"] = random_id
        
        # Add style categories with filtering
        style_items = {}
        
        for category, style_list in self.generator.styles.items():
            category_match = search_text in category.lower()
            styles_to_add = []
            
            for style in style_list:
                if search_text in style.lower() or category_match or not search_text:
                    styles_to_add.append(style)
            
            if styles_to_add:
                # Expand category if filtering
                open_state = bool(search_text)
                category_id = self.style_tree.insert("", "end", text=category, open=open_state)
                self.style_data[category_id] = {"type": "parent", "style": category}
                
                for style in styles_to_add:
                    display_text = style[:90] + "..." if len(style) > 90 else style
                    style_id = self.style_tree.insert(category_id, "end", text=display_text)
                    self.style_data[style_id] = {
                        "type": "child", 
                        "style": style,
                        "description": style,
                        "display_text": display_text
                    }
                    style_items[style] = style_id
        
        # RESTORE SELECTION AFTER FILTERING
        if previous_selection:
            item_to_select = None
            
            # Check special items first
            if previous_selection in special_items:
                item_to_select = special_items[previous_selection]
            # Check style items
            elif previous_selection in style_items:
                item_to_select = style_items[previous_selection]
            # Try to find by text match
            else:
                for item_id, item_data in self.style_data.items():
                    if item_data.get("style") == previous_selection:
                        item_to_select = item_id
                        break
            
            if item_to_select:
                self.style_tree.selection_set(item_to_select)
                self.style_tree.see(item_to_select)
                # Update the display label
                display_text = previous_selection if previous_selection in ["none", "any"] else self.style_data[item_to_select].get("display_text", previous_selection[:90] + "..." if len(previous_selection) > 90 else previous_selection)
                self.selected_style_label.config(text=display_text)
            else:
                # Default to "None" if available, otherwise first available item
                if special_items and "none" in special_items:
                    self.style_tree.selection_set(special_items["none"])
                    self.selected_style_label.config(text="None")
                elif style_items:
                    first_style_id = next(iter(style_items.values()))
                    self.style_tree.selection_set(first_style_id)
                    first_style_data = self.style_data.get(first_style_id, {})
                    display_text = first_style_data.get("display_text", "Style")
                    self.selected_style_label.config(text=display_text)
        else:
            # Default to "None" if available and no search, otherwise first item
            if not search_text and special_items and "none" in special_items:
                self.style_tree.selection_set(special_items["none"])
                self.selected_style_label.config(text="None")
            elif style_items:
                first_style_id = next(iter(style_items.values()))
                self.style_tree.selection_set(first_style_id)
                first_style_data = self.style_data.get(first_style_id, {})
                display_text = first_style_data.get("display_text", "Style")
                self.selected_style_label.config(text=display_text)
            elif special_items:
                # If only special items available, select the first one
                first_special_id = next(iter(special_items.values()))
                self.style_tree.selection_set(first_special_id)
                first_special_data = self.style_data.get(first_special_id, {})
                display_text = first_special_data.get("display_text", "Special")
                self.selected_style_label.config(text=display_text)
            
    def update_word_count(self):
        """Update word count label."""
        text = self.prompt_text.get("1.0", tk.END).strip()
        word_count = len(text.split()) if text else 0
        char_count = len(text)
        self.word_count_label.config(text=f"Words: {word_count} | Characters: {char_count}")
    
    def clear_prompt(self):
        """Clear the prompt text."""
        self.prompt_text.delete("1.0", tk.END)
        self.update_word_count()
    
    def on_domain_tree_select(self, event):
        """Handle domain tree selection to prevent parent node selection and update display."""
        selection = self.domain_tree.selection()
        if selection:
            item_id = selection[0]
            item_data = self.domain_data.get(item_id, {})
            
            # Prevent selecting parent nodes
            if item_data.get("type") == "parent":
                self.domain_tree.selection_remove(item_id)
                return
            
            # Update the selected domain display
            domain_str = item_data.get("domain", "None")
            
            # Handle special display for "None" and "Random"
            if domain_str == "None":
                display_text = "None"
            elif domain_str == "Random":
                display_text = "Any Domain (Random)"
            else:
                display_text = domain_str if len(domain_str) <= 50 else domain_str[:47] + "..."
            
            self.selected_domain_label.config(text=display_text)

    def get_selected_domain(self):
        """Get the currently selected domain with robust fallback handling."""
        return self.get_current_domain_robust()
  
    def filter_domains(self, event=None):
        """Filter domain tree based on search text while PRESERVING selection."""
        search_text = self.domain_search.get().lower()
        
        # STORE CURRENT SELECTION BEFORE CLEARING
        previous_selection = None
        previous_selection_text = None
        if self.domain_tree.selection():
            previous_item = self.domain_tree.selection()[0]
            previous_selection_text = self.domain_tree.item(previous_item, "text")
            previous_selection_data = self.domain_data.get(previous_item, {})
            previous_selection = previous_selection_data.get("domain", previous_selection_text)
        
        # Clear and rebuild
        for item in self.domain_tree.get_children():
            self.domain_tree.delete(item)
        self.domain_data.clear()
        
        if not self.generator:
            return
        
        # Handle General category with special options
        general_id = None
        general_items = {}  # Store items for potential reselection
        
        for domain, subdomains in self.generator.domain_guidance.items():
            if domain == "General" and isinstance(subdomains, dict):
                parent_match = search_text in domain.lower()
                children_to_add = []
                special_options_to_add = []
                
                # Check special options
                if search_text in "none" or parent_match or not search_text:
                    special_options_to_add.append(("None", "None", "No academic domain context will be added to the prompt"))
                if search_text in "any domain" or search_text in "random" or parent_match or not search_text:
                    special_options_to_add.append(("Random", "Any Domain (Random)", "Randomly select from all available academic domains"))
                
                # Check regular subdomains
                for sub, description in subdomains.items():
                    if search_text in sub.lower() or parent_match or not search_text:
                        children_to_add.append((sub, sub, description))
                
                if special_options_to_add or children_to_add:
                    open_state = bool(search_text)
                    general_id = self.domain_tree.insert("", "end", text=domain, open=open_state)
                    self.domain_data[general_id] = {"type": "parent", "domain": domain}
                    
                    # Add special options first
                    for display_text, domain_str, description in special_options_to_add:
                        child_id = self.domain_tree.insert(general_id, "end", text=display_text)
                        self.domain_data[child_id] = {
                            "type": "child", 
                            "domain": domain_str,
                            "description": description
                        }
                        general_items[domain_str] = child_id
                    
                    # Add regular subdomains
                    for display_text, domain_str, description in children_to_add:
                        child_id = self.domain_tree.insert(general_id, "end", text=display_text)
                        self.domain_data[child_id] = {
                            "type": "child", 
                            "domain": domain_str,
                            "description": description
                        }
                        general_items[domain_str] = child_id
                break
        
        # Handle other domains
        other_items = {}  # Store items for potential reselection
        
        for domain, subdomains in self.generator.domain_guidance.items():
            if domain == "General":
                continue
                
            if isinstance(subdomains, dict):
                parent_match = search_text in domain.lower()
                children_to_add = []
                
                for sub, description in subdomains.items():
                    if search_text in sub.lower() or parent_match or not search_text:
                        children_to_add.append((sub, sub, description))
                
                if children_to_add:
                    open_state = bool(search_text)
                    parent_id = self.domain_tree.insert("", "end", text=domain, open=open_state)
                    self.domain_data[parent_id] = {"type": "parent", "domain": domain}
                    
                    for display_text, domain_str, description in children_to_add:
                        child_id = self.domain_tree.insert(parent_id, "end", text=display_text)
                        self.domain_data[child_id] = {
                            "type": "child", 
                            "domain": domain_str,
                            "description": description
                        }
                        other_items[domain_str] = child_id
            else:
                # Standalone domains
                if search_text in domain.lower() or not search_text:
                    item_id = self.domain_tree.insert("", "end", text=domain)
                    self.domain_data[item_id] = {
                        "type": "standalone", 
                        "domain": domain, 
                        "description": subdomains
                    }
                    other_items[domain] = item_id
        
        # RESTORE SELECTION AFTER FILTERING
        if previous_selection:
            # Try to find and select the previously selected item
            item_to_select = None
            
            # Check general items first
            if previous_selection in general_items:
                item_to_select = general_items[previous_selection]
            # Check other items
            elif previous_selection in other_items:
                item_to_select = other_items[previous_selection]
            # Try to find by text match
            else:
                for item_id, item_data in self.domain_data.items():
                    if item_data.get("domain") == previous_selection:
                        item_to_select = item_id
                        break
                    if self.domain_tree.item(item_id, "text") == previous_selection_text:
                        item_to_select = item_id
                        break
            
            if item_to_select:
                self.domain_tree.selection_set(item_to_select)
                self.domain_tree.see(item_to_select)
                # Update the display label
                display_text = previous_selection if len(previous_selection) <= 50 else previous_selection[:47] + "..."
                self.selected_domain_label.config(text=display_text)
            else:
                # Default to "None" if previous selection not available
                if general_id and "None" in general_items:
                    self.domain_tree.selection_set(general_items["None"])
                    self.selected_domain_label.config(text="None")
        else:
            # No previous selection, default to "None"
            if general_id and "None" in general_items:
                self.domain_tree.selection_set(general_items["None"])
                self.selected_domain_label.config(text="None")
    
    def get_selected_style(self):
        """Get the currently selected style from the tree with robust fallback."""
        selection = self.style_tree.selection()
        
        if not selection:
            return "none"
        
        item_id = selection[0]
        item_data = self.style_data.get(item_id, {})
        
        style = item_data.get("style", "none")
        return style

    def get_current_style_robust(self):
        """Robust method to get current style selection, with fallbacks."""
        # Method 1: Try direct tree selection
        selection = self.style_tree.selection()
        if selection:
            item_id = selection[0]
            item_data = self.style_data.get(item_id, {})
            style = item_data.get("style", "none")
            return style
        
        # Method 2: Try the selected style label (fallback)
        label_text = self.selected_style_label.cget("text")
        if label_text and label_text != "None":
            # Try to map label back to style
            for item_id, item_data in self.style_data.items():
                if item_data.get("display_text") == label_text:
                    return item_data.get("style", "none")
                if item_data.get("style") == label_text:
                    return label_text
        
        # Method 3: Default to "none"
        return "none"
    
    def generate_random_prompt_threaded(self):
        """Generate random prompt in a separate thread."""
        if self.is_generating:
            return
        
        # Double-check permanent availability
        if not self.gemini_permanently_available:
            messagebox.showwarning(
                "Gemini Not Available", 
                "Random prompt generation requires Gemini API. Please configure GEMINI_API_KEY in your .env file and restart the application.\n\nYou can still enter prompts manually and use Pollinations.ai for image generation."
            )
            return
        
        if not self.generator:
            messagebox.showwarning("Warning", "Generator not available.")
            return

        def generate():
            self.set_loading_state(True, "Generating random prompt...")
            try:
                domain = self.get_current_domain_robust()
                style = self.get_current_style_robust()
                
                prompt = self.generator.get_random_prompt_from_gemini(domain, style)
                
                # Update UI in main thread
                self.root.after(0, self.on_prompt_generated, prompt)
                
            except RuntimeError as e:
                self.root.after(0, self.on_error, str(e))
            except Exception as e:
                self.root.after(0, self.on_error, f"Failed to generate prompt: {str(e)}")
        
        threading.Thread(target=generate, daemon=True).start()
    
    def on_prompt_generated(self, prompt):
        """Handle successful prompt generation."""
        self.prompt_text.delete("1.0", tk.END)
        self.prompt_text.insert("1.0", prompt)
        self.add_to_history(prompt)
        self.update_word_count()
        self.set_loading_state(False, "Random prompt generated successfully")
    
    def generate_prompt_threaded(self):
        """Enhance existing prompt in a separate thread."""
        if self.is_generating:
            return
        
        # Double-check permanent availability
        if not self.gemini_permanently_available:
            messagebox.showwarning(
                "Gemini Not Available", 
                "Prompt enhancement requires Gemini API. Please configure GEMINI_API_KEY in your .env file and restart the application.\n\nYou can still enter prompts manually and use Pollinations.ai for image generation."
            )
            return
        
        if not self.generator:
            messagebox.showwarning("Warning", "Generator not available.")
            return
        
        # Get current prompt
        base_prompt = self.prompt_text.get("1.0", tk.END).strip()
        if not base_prompt:
            messagebox.showwarning("Warning", "Please enter a prompt to enhance.")
            return

        def generate():
            self.set_loading_state(True, "Enhancing prompt...")
            try:
                domain = self.get_current_domain_robust()
                style = self.get_current_style_robust()
                
                enhanced_prompt = self.generator.enhance_prompt_with_gemini(base_prompt, domain, style)
                
                # Update UI in main thread
                self.root.after(0, self.on_prompt_enhanced, enhanced_prompt)
                
            except RuntimeError as e:
                self.root.after(0, self.on_error, str(e))
            except Exception as e:
                self.root.after(0, self.on_error, f"Failed to enhance prompt: {str(e)}")
        
        threading.Thread(target=generate, daemon=True).start()
        
    def on_prompt_enhanced(self, enhanced_prompt):
        """Handle successful prompt enhancement."""
        self.prompt_text.delete("1.0", tk.END)
        self.prompt_text.insert("1.0", enhanced_prompt)
        self.add_to_history(enhanced_prompt)
        self.update_word_count()
        self.set_loading_state(False, "Prompt enhanced successfully")
    
    def generate_image_threaded(self):
        """Generate image in a separate thread."""
        if self.is_generating:
            return
            
        prompt = self.prompt_text.get("1.0", tk.END).strip()
        if not prompt:
            messagebox.showwarning("Warning", "Please enter a prompt first")
            return
        
        # Check if generator exists and is properly initialized
        if not self.generator:
            messagebox.showerror("Error", "Image generator not available. Please restart the application.")
            return
        
        # Add this additional check for the method
        if not hasattr(self.generator, 'generate_complete_image'):
            messagebox.showerror("Error", "Image generator is not fully initialized. Please restart the application.")
            return

        def generate():
            service_map = {
                "Pollinations.ai: free, no api-key required": "pollinations",
                "DALL-E 3: paid service, api-key required": "dalle",
                "Stable Diffusion XL: limited free credits, api-key required": "huggingface"
            }
            
            selected_service = self.service_combo.get()
            # Handle UNAVAILABLE services
            if "UNAVAILABLE" in selected_service:
                if "DALL-E" in selected_service:
                    self.root.after(0, self.on_error, "DALL-E is not available. Please configure OPENAI_API_KEY in your .env file.")
                elif "Stable Diffusion" in selected_service:
                    hf_error = self.validation_status.get('huggingface', {}).get('error', 'Unknown error')
                    if "not found" in hf_error.lower():
                        error_msg = "Stable Diffusion is not available.\n\nHUGGINGFACE_API_TOKEN not found in .env file.\n\nTo fix this:\n1. Get a token from: https://huggingface.co/settings/tokens\n2. Add to .env file: HUGGINGFACE_API_TOKEN=your_token_here\n3. Right-click the StableDiff status indicator and select 'Refresh Token Status'"
                    elif "format" in hf_error.lower():
                        error_msg = "Stable Diffusion is not available.\n\nInvalid token format detected.\n\nHugging Face tokens should start with 'hf_'.\n\nTo fix this:\n1. Check your token at: https://huggingface.co/settings/tokens\n2. Update .env file with correct token\n3. Right-click the StableDiff status indicator and select 'Refresh Token Status'"
                    elif "authentication failed" in hf_error.lower():
                        error_msg = "Stable Diffusion is not available.\n\nToken authentication failed.\n\nYour token may be invalid, expired, or revoked.\n\nTo fix this:\n1. Check your token at: https://huggingface.co/settings/tokens\n2. Generate a new token if needed\n3. Update .env file\n4. Right-click the StableDiff status indicator and select 'Refresh Token Status'"
                    else:
                        error_msg = f"Stable Diffusion is not available.\n\nError: {hf_error}\n\nRight-click the StableDiff status indicator and select 'Refresh Token Status' to revalidate."
                    self.root.after(0, self.on_error, error_msg)
                return
            
            service = service_map.get(selected_service, "pollinations")
            file_format = self.format_combo.get().lower()
            
            # Only check DALL-E availability strictly (it requires paid credits)
            if service == "dalle" and not self.generator.api_config.dalle_available:
                self.root.after(0, self.on_error, "DALL-E is not available. Please configure OPENAI_API_KEY in your .env file.")
                return
            
            # For HF, if token exists, let it try (quota errors will be caught during generation)
            if service == "huggingface" and not self.generator.api_config.hf_token:
                hf_error = self.validation_status.get('huggingface', {}).get('error', 'Token not found')
                if "not found" in hf_error.lower():
                    error_msg = "Stable Diffusion is not available.\n\nHUGGINGFACE_API_TOKEN not found in .env file.\n\nTo fix this:\n1. Get a token from: https://huggingface.co/settings/tokens\n2. Add to .env file: HUGGINGFACE_API_TOKEN=your_token_here\n3. Right-click the StableDiff status indicator and select 'Refresh Token Status'"
                else:
                    error_msg = f"Stable Diffusion is not available.\n\nError: {hf_error}\n\nRight-click the StableDiff status indicator and select 'Refresh Token Status' to revalidate."
                self.root.after(0, self.on_error, error_msg)
                return
            
            self.root.after(0, self.set_loading_state, True, f"Generating image with {service.upper()}...")
            
            try:
                image = self.generator.generate_complete_image(prompt, "custom", service, file_format)
                
                if image:
                    self.root.after(0, self.on_image_generated, image, prompt)
                else:
                    self.root.after(0, self.on_error, "Failed to generate image - no image returned")
                    
            except RuntimeError as e:
                # User-friendly errors (already formatted)
                self.root.after(0, self.on_error, str(e))
            except Exception as e:
                # Unexpected errors
                error_msg = f"Unexpected error during image generation: {str(e)}"
                print(f"Full error: {type(e).__name__}: {e}")
                self.root.after(0, self.on_error, error_msg)
            finally:
                # Always clear loading state, even if there was an error
                self.root.after(0, self.set_loading_state, False, "Ready")
        
        threading.Thread(target=generate, daemon=True).start()
    
    def surprise_generation_threaded(self):
        """Generate surprise image in a separate thread."""
        if self.is_generating:
            return
        
        # Double-check permanent availability
        if not self.gemini_permanently_available:
            messagebox.showwarning(
                "Gemini Not Available", 
                "Surprise generation requires Gemini API. Please configure GEMINI_API_KEY in your .env file and restart the application.\n\nYou can still enter prompts manually and use Pollinations.ai for image generation."
            )
            return
        
        if not self.generator:
            messagebox.showwarning("Warning", "Generator not available.")
            return

        def surprise():
            self.root.after(0, self.set_loading_state, True, "Generating surprise...")
            
            try:
                # Select random domain and style
                all_domains = []
                for domain, subdomains in self.generator.domain_guidance.items():
                    if isinstance(subdomains, dict):
                        for sub in subdomains.keys():
                            all_domains.append(f"{domain} - {sub}")
                    else:
                        all_domains.append(domain)
                
                all_styles = []
                for category, style_list in self.generator.styles.items():
                    all_styles.extend(style_list)
                
                random_domain = random.choice(all_domains)
                random_style = random.choice(all_styles)
                
                # Update UI to show the random selections
                self.root.after(0, self.select_random_domain_in_tree, random_domain)
                self.root.after(0, self.select_random_style_in_tree, random_style)
                
                # Generate prompt with random domain and style
                prompt = self.generator.get_random_prompt_from_gemini(random_domain, random_style)
                
                # Update prompt in UI
                self.root.after(0, self.prompt_text.delete, "1.0", tk.END)
                self.root.after(0, self.prompt_text.insert, "1.0", prompt)
                self.root.after(0, self.add_to_history, prompt)
                self.root.after(0, self.update_word_count)
                
                # Generate image
                service_map = {
                    "Pollinations.ai: free, no api-key required": "pollinations",
                    "DALL-E 3: paid service, api-key required": "dalle",
                    "Stable Diffusion XL: limited free credits, api-key required": "huggingface"
                }
                
                service = service_map[self.service_combo.get()]
                file_format = self.format_combo.get().lower()
                
                image = self.generator.generate_complete_image(prompt, "surprise", service, file_format)
                
                if image:
                    self.root.after(0, self.on_image_generated, image, prompt)
                else:
                    self.root.after(0, self.on_error, "Failed to generate surprise image (check console for details)")
                    
            except RuntimeError as e:
                self.root.after(0, self.on_error, str(e))
            except Exception as e:
                self.root.after(0, self.on_error, f"Failed to generate surprise: {str(e)}")
        
        threading.Thread(target=surprise, daemon=True).start()
    
    def on_image_generated(self, image, prompt):
        """Handle successful image generation."""
        self.current_image = image
        self.display_image(image)
        self.enable_image_controls(True)
        self.add_to_history(prompt)
        self.notebook.select(0)
        self.set_loading_state(False, "Image generated successfully")
    
    def on_error(self, error_message):
        """Handle errors."""
        messagebox.showerror("Error", error_message)
        self.set_loading_state(False, "Ready")
    
    def set_loading_state(self, loading, message=""):
        """Set UI loading state."""
        self.is_generating = loading
        state = "disabled" if loading else "normal"
        
        # Always respect generation button state
        self.generate_btn.config(state=state)
        
        # Only enable Gemini-dependent controls if Gemini is permanently available
        if self.gemini_permanently_available and not loading:
            self.random_prompt_btn.config(state="normal")
            self.generate_prompt_btn.config(state="normal")
            self.surprise_btn.config(state="normal")
            self.set_domain_frame_state(True)  # This now handles both domain and style trees
            self.style_search.config(state="normal")
            # Style tree state is handled by set_domain_frame_state()
        else:
            # Keep them disabled
            self.random_prompt_btn.config(state="disabled")
            self.generate_prompt_btn.config(state="disabled")
            self.surprise_btn.config(state="disabled")
            self.set_domain_frame_state(False)  # This now handles both domain and style trees
            self.style_search.config(state="disabled")
            # Style tree state is handled by set_domain_frame_state()
        
        if loading:
            self.progress_var.set("Working...")
            self.progress_label.config(bg="lightblue")
        else:
            self.progress_var.set("")
            self.progress_label.config(bg="SystemButtonFace")
        
        self.status_label.config(text=message if message else "Ready")
    
    def enable_image_controls(self, enabled):
        """Enable/disable image control buttons."""
        state = "normal" if enabled else "disabled"
        self.save_btn.config(state=state)
        self.copy_prompt_btn.config(state=state)
        self.zoom_in_btn.config(state=state)
        self.zoom_out_btn.config(state=state)
        self.zoom_fit_btn.config(state=state)
    
    def display_image(self, image):
        """Display the generated image."""
        self.image_canvas.delete("all")
        self.original_image = image.copy()
        self.zoom_factor = 1.0
        self.update_zoom_display()
        self._display_image_with_zoom()
    
    def _display_image_with_zoom(self):
        """Display the image with current zoom factor."""
        if not self.original_image:
            return
            
        self.image_canvas.delete("all")
        
        # Calculate display size based on zoom factor
        canvas_width = self.image_canvas.winfo_width()
        canvas_height = self.image_canvas.winfo_height()
        
        if canvas_width <= 1:
            canvas_width = 800
            canvas_height = 600
        
        if self.zoom_factor == 1.0:  # Fit to panel
            display_image = self.original_image.copy()
            max_size = (canvas_width - 20, canvas_height - 20)
            display_image.thumbnail(max_size, Image.Resampling.LANCZOS)
        else:  # Zoomed
            original_width, original_height = self.original_image.size
            new_width = int(original_width * self.zoom_factor)
            new_height = int(original_height * self.zoom_factor)
            display_image = self.original_image.resize((new_width, new_height), Image.Resampling.LANCZOS)
        
        self.current_photo = ImageTk.PhotoImage(display_image)
        
        img_width = self.current_photo.width()
        img_height = self.current_photo.height()
        
        if self.zoom_factor == 1.0:  # Center when fitting
            x = max(0, (canvas_width - img_width) // 2)
            y = max(0, (canvas_height - img_height) // 2)
        else:  # Top-left when zoomed
            x = 0
            y = 0
        
        self.image_canvas.create_image(x, y, anchor=tk.NW, image=self.current_photo)
        self.image_canvas.configure(scrollregion=self.image_canvas.bbox("all"))
    
    def zoom_in(self):
        """Zoom in the image."""
        if self.original_image:
            self.zoom_factor = min(self.zoom_factor * 1.25, 5.0)
            self.update_zoom_display()
            self._display_image_with_zoom()
    
    def zoom_out(self):
        """Zoom out the image."""
        if self.original_image:
            self.zoom_factor = max(self.zoom_factor / 1.25, 0.1)
            self.update_zoom_display()
            self._display_image_with_zoom()
    
    def zoom_fit(self):
        """Fit image to panel."""
        if self.original_image:
            self.zoom_factor = 1.0
            self.update_zoom_display()
            self._display_image_with_zoom()
    
    def update_zoom_display(self):
        """Update the zoom percentage label."""
        if self.zoom_factor == 1.0:
            self.zoom_label.config(text="Fit")
        else:
            self.zoom_label.config(text=f"{int(self.zoom_factor * 100)}%")
    
    def save_image(self):
        """Save the current image to a file."""
        if not self.current_image:
            messagebox.showwarning("Warning", "No image to save")
            return
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        default_filename = f"ai_generated_image_{timestamp}.png"
        
        file_path = filedialog.asksaveasfilename(
            defaultextension=".png",
            filetypes=[
                ("PNG files", "*.png"),
                ("JPEG files", "*.jpg"),
                ("All files", "*.*")
            ],
            initialvalue=default_filename
        )
        
        if file_path:
            try:
                if file_path.lower().endswith(('.jpg', '.jpeg')):
                    image_to_save = self.current_image.convert("RGB")
                    image_to_save.save(file_path, "JPEG", quality=95)
                else:
                    if not file_path.lower().endswith('.png'):
                        file_path += '.png'
                    self.current_image.save(file_path, "PNG")
                
                self.status_label.config(text=f"Image saved to {file_path}")
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save image: {str(e)}")
    
    def copy_current_prompt(self):
        """Copy current prompt to clipboard."""
        prompt = self.prompt_text.get("1.0", tk.END).strip()
        if prompt:
            self.root.clipboard_clear()
            self.root.clipboard_append(prompt)
            self.status_label.config(text="Prompt copied to clipboard")
        else:
            messagebox.showwarning("Warning", "No prompt to copy")
    
    def add_to_history(self, prompt):
        """Add prompt to history."""
        if prompt and prompt not in self.prompt_history:
            self.prompt_history.append(prompt)
            
            if len(self.prompt_history) > 50:
                self.prompt_history.pop(0)
                self.history_listbox.delete(0)
            
            display_text = f"{len(self.prompt_history)}. {prompt[:100]}..."
            self.history_listbox.insert(tk.END, display_text)
    
    def load_from_history(self, event):
        """Load prompt from history."""
        selection = self.history_listbox.curselection()
        if selection:
            index = selection[0]
            if index < len(self.prompt_history):
                prompt = self.prompt_history[index]
                self.prompt_text.delete("1.0", tk.END)
                self.prompt_text.insert("1.0", prompt)
                self.update_word_count()
                self.status_label.config(text="Prompt loaded from history")
    
    def clear_history(self):
        """Clear prompt history."""
        self.prompt_history.clear()
        self.history_listbox.delete(0, tk.END)
        self.status_label.config(text="History cleared")
    
    def select_random_domain_in_tree(self, domain_str):
        """Select a domain in the tree based on the domain string."""
        for item in self.domain_tree.selection():
            self.domain_tree.selection_remove(item)
        
        if " - " in domain_str:
            parent_name, child_name = domain_str.split(" - ", 1)
            
            for parent_id in self.domain_tree.get_children():
                if self.domain_tree.item(parent_id, "text") == parent_name:
                    for child_id in self.domain_tree.get_children(parent_id):
                        if self.domain_tree.item(child_id, "text") == child_name:
                            self.domain_tree.selection_set(child_id)
                            self.domain_tree.see(child_id)
                            self.domain_tree.item(parent_id, open=True)
                            return
        else:
            for item_id in self.domain_tree.get_children():
                if self.domain_tree.item(item_id, "text") == domain_str:
                    self.domain_tree.selection_set(item_id)
                    self.domain_tree.see(item_id)
                    return
    
    def select_random_style_in_tree(self, style):
        """Select a style in the style tree based on the style string."""
        # Clear current selection
        for item in self.style_tree.selection():
            self.style_tree.selection_remove(item)
        
        # Search for the style in the tree
        for item_id, item_data in self.style_data.items():
            if item_data.get("style") == style:
                self.style_tree.selection_set(item_id)
                self.style_tree.see(item_id)
                # Update the display label
                display_text = item_data.get("display_text", style[:90] + "..." if len(style) > 90 else style)
                self.selected_style_label.config(text=display_text)
                return
        
        # If not found, default to "None"
        for item_id, item_data in self.style_data.items():
            if item_data.get("style") == "none":
                self.style_tree.selection_set(item_id)
                self.selected_style_label.config(text="None")
                break
    
    def show_about(self):
        """Show about dialog."""
        about_text = f"""SURPRISE ME IMAGE GENERATOR {self.version} - Created by Peer-Olaf Siebers and diverse LLMs


Generate stunning images using multiple AI services:
    
  •  Pollinations.ai: Fast generation, good for experimentation, free, no api-key needed

  •  DALL-E 3: High quality, creative, paid service, api-key required

  •  Stable Diffusion XL: Balanced quality/speed, limited free credits, api-key required
    """
        
        DialogManager.show_dialog("About", about_text, parent=self.root)

    def show_api_issues(self):
        """Show the API troubleshooting guide as a popup."""
        message = f"""HOW TO ENABLE MISSING FEATURES

Gemini (for prompt generation):
• Get free API key: https://ai.google.dev/gemini-api/docs/api-key
• Add to .env file: GEMINI_API_KEY=your_key_here
• Set (text-out) model name, e.g.: GEMINI_MODEL=gemini-2.5-flash
• Available free tier models: https://ai.google.dev/gemini-api/docs/rate-limits#free-tier
• Free tier: Limited daily requests

DALL-E (for high-quality images):
• Get API key: https://platform.openai.com/api-keys
• Add to .env file: OPENAI_API_KEY=your_key_here
• Paid service: Charges per image generated

Stable Diffusion (for balanced quality/speed):
• Get token: https://huggingface.co/settings/tokens
• Add to .env file: HUGGINGFACE_API_TOKEN=your_token_here
• Free tier: Limited monthly credits

After updating your .env file, restart the application."""

        DialogManager.show_dialog("API Troubleshooting", message, dialog_type="info", parent=self.root)


def main():
    """Main application entry point."""
    root = tk.Tk()
    width = 1400
    height = 865
    version = "0.8.8"
    # Center main window
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    x_coordinate = (screen_width - width) // 2
    y_coordinate = (screen_height - height) // 2
    root.geometry('%dx%d+%d+%d' % (width, height, x_coordinate, y_coordinate))

    # Start app
    app = ImageGeneratorGUI(root, version, width, height)
    try:
        root.mainloop()
    except KeyboardInterrupt:
        print("\nApplication interrupted by user")
    except Exception as e:
        print(f"Application error: {e}")
    finally:
        root.quit()


if __name__ == "__main__":
    main()