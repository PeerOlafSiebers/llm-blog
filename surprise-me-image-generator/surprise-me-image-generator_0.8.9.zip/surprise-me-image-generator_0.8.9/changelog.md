# Surprise Me Image Generator - Changelog

## [0.8.9] - 2025-10-10
Added prompt type choice: "positive only" or "unrestricted"

## [0.8.8] - 2025-10-07
This is the initial public release