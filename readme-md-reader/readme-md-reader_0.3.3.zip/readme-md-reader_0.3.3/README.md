# Enhanced Prompt Library - AI Prompt Management Tool

A comprehensive desktop application for creating, managing, and improving AI prompts with advanced features including AI-powered analysis, version history, templates, and sophisticated tagging.

| Attempt | #1    | #2    |
| :---:   | :---: | :---: |
| Seconds | 301   | 283   |

## Features

### 🚀 Core Features

- **Prompt Editor**: Rich text editor with syntax highlighting for variables
- **Snippet Library**: Reusable prompt components with variable configuration
- **Template System**: Pre-built prompt templates for common use cases
- **Version History**: Track and restore previous versions of prompts
- **Advanced Tagging**: Color-coded tags with usage statistics

### 🤖 AI Integration

- **AI Analysis**: Sophisticated prompt analysis with scoring (clarity, specificity, completeness, effectiveness)
- **AI Improvement**: Generate improved versions of prompts with different focus areas
- **Smart Suggestions**: Real-time improvement suggestions based on prompt content
- **Token Estimation**: Automatic token counting for cost optimization

### 📊 Enhanced Management

- **Category System**: Organized prompt categories (General, Creative, Technical, Business, etc.)
- **Search & Filter**: Advanced filtering by category, tags, and content
- **Usage Statistics**: Track prompt usage and popularity
- **Export/Import**: Save and share prompt libraries

## Installation

### Prerequisites

- Python 3.8 or higher
- PyQt6
- requests library

### Setup

1. Clone or download the application files
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Configure your API key:
   - Copy the `.env.example` file to `.env` (or create a new `.env` file)
   - Add your Gemini API key to the `.env` file:
     ```
     GEMINI_API_KEY=your_actual_api_key_here
     ```
   - Get your API key from [Google AI Studio](https://makersuite.google.com/app/apikey)

### Running the Application

```bash
python claudePromptLibraryApp.py
```

## Usage Guide

### Creating Prompts

1. **Using Snippets**: Browse the Snippets tab and double-click to add components
2. **Using Templates**: Select from the Templates tab and configure variables
3. **Manual Entry**: Type directly in the prompt editor
4. **AI Assistance**: Use the "AI Improve" button to enhance your prompts

### Managing Your Library

1. **Save Prompts**: Use the Save button to store prompts with metadata
2. **Version Control**: Access version history from the Library tab
3. **Tagging**: Add tags to organize and filter prompts
4. **Search**: Use the search bar to find specific prompts

### AI Features

1. **Analysis**: Click "Analyze Prompt" for detailed feedback
2. **Improvement**: Select improvement type and generate enhanced versions
3. **Suggestions**: Real-time suggestions appear as you type

## Database Schema

The application uses SQLite with the following main tables:

- **prompts**: Main prompt storage with metadata
- **prompt_versions**: Version history for each prompt
- **templates**: Reusable prompt templates
- **snippets**: Prompt components
- **tags**: Tag definitions with colors
- **prompt_tags**: Many-to-many relationship between prompts and tags
- **ai_suggestions**: Stored AI analysis results

## Configuration

### AI Integration

- Set `GEMINI_API_KEY` environment variable for AI features
- The application will work without AI features using fallback analysis
- AI features include prompt analysis, improvement suggestions, and token estimation

### Customization

- Add custom templates in the Templates tab
- Create custom tags with the Tag Manager
- Modify default snippets in the database

## File Structure

```
claude-promptLibrary/
├── claudePromptLibraryApp.py    # Main application
├── requirements.txt             # Python dependencies
├── README.md                    # This file
├── .env                         # Environment variables (create from .env.example)
├── .env.example                 # Environment variables template
└── cs_professor_prompts.db      # SQLite database (created automatically)
```

## Features in Detail

### AI Analysis

The AI integration provides:

- **Clarity Score**: How clear and understandable the prompt is
- **Specificity Score**: How specific and detailed the instructions are
- **Completeness Score**: How comprehensive the prompt is
- **Effectiveness Score**: Overall effectiveness for AI understanding
- **Token Estimation**: Approximate token count for cost planning
- **Strengths/Weaknesses**: Detailed feedback on prompt quality

### Template System

Pre-built templates include:

- **Code Review Assistant**: For code analysis and feedback
- **Content Creator**: For various content types
- **Data Analyst**: For data analysis tasks
- **Educational Tutor**: For teaching and explanations
- **Business Consultant**: For business strategy advice

### Version History

- Automatic version tracking on save
- Manual version creation with descriptions
- Version comparison and restoration
- Author tracking for collaborative use

### Tag Management

- Color-coded tags for visual organization
- Usage statistics for popular tags
- Hierarchical tag organization
- Bulk tag operations

## Troubleshooting

### Common Issues

1. **AI features not working**: Check your Google AI Studio API key and internet connection
2. **Database errors**: Delete the database file to reset (will lose data)
3. **UI not loading**: Ensure PyQt6 is properly installed

### Performance Tips

- Use tags and categories for better organization
- Regular database cleanup for large libraries
- Disable AI analysis for faster performance on slower systems

## Contributing

Feel free to extend the application with:

- Additional AI providers
- Export formats (JSON, CSV, etc.)
- Cloud synchronization
- Collaborative features
- Advanced analytics

## License

This project is open source and available under the MIT License.

## Support

For issues or questions:

1. Check the troubleshooting section
2. Review the database schema
3. Test with a fresh database
4. Ensure all dependencies are installed

---

**Note**: The AI features require a Google AI Studio API key and internet connection. The application will work without AI features using built-in analysis.
