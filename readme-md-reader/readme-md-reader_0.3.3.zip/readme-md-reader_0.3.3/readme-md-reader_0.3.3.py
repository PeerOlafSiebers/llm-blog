import os
import sys
from PyQt6.QtWidgets import QApplication, QMainWindow, QTextBrowser
from PyQt6.QtCore import Qt, QUrl
from PyQt6.QtGui import QDesktopServices
import markdown

class ReadmeReader(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("README.md Reader")
        self.setGeometry(100, 100, 900, 700)
        
        # Set window background colour to match Claude's interface
        self.setStyleSheet("""
            QMainWindow {
                background-color: #f7f7f8;
            }
        """)
        
        self.browser = QTextBrowser(self)
        self.setCentralWidget(self.browser)
        
        # Style the text browser to match Claude's interface
        self.browser.setStyleSheet("""
            QTextBrowser {
                background-color: #ffffff;
                border: none;
                border-radius: 8px;
                margin: 16px;
                padding: 0px;
            }
        """)
        
        self.browser.setOpenExternalLinks(False)
        self.browser.anchorClicked.connect(self.handle_anchor_clicked)
        self.browser.setHtml(self.get_readme_content())

    def find_readme_file(self):
        """Find README.md in the same directory as the executable"""
        # Get the directory where the executable is located
        if getattr(sys, 'frozen', False):
            # Running as compiled executable
            base_dir = os.path.dirname(sys.executable)
        else:
            # Running as Python script
            base_dir = os.path.dirname(os.path.abspath(__file__))
        
        readme_path = os.path.join(base_dir, "README.md")
        return readme_path

    def get_readme_content(self):
        readme_path = self.find_readme_file()
        
        try:
            # Check if file exists
            if not os.path.exists(readme_path):
                error_html = f"""
                <h1>README.md Not Found</h1>
                <p>The README.md file was not found at:</p>
                <pre>{readme_path}</pre>
                <p>Please ensure README.md exists in the same directory as this application.</p>
                """
                return self.wrap_with_claude_styles(error_html)
            
            # Read and parse the markdown file
            with open(readme_path, "r", encoding="utf-8") as f:
                md_text = f.read()
            
            html = markdown.markdown(
                md_text,
                extensions=['extra', 'tables']
            )
            
            return self.wrap_with_claude_styles(html)
            
        except Exception as e:
            error_html = f"""
            <h1>Error Reading README.md</h1>
            <p>An error occurred while reading the README.md file:</p>
            <pre>{str(e)}</pre>
            <p>File path: {readme_path}</p>
            """
            return self.wrap_with_claude_styles(error_html)

    def wrap_with_claude_styles(self, html_content):
        """Wrap HTML content with Claude-inspired styling"""
        claude_css = """
        <style>
            * {
                font-size: 14px !important;
            }
            body { 
                font-family: "Söhne", -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
                background-color: #ffffff;
                color: #2f2f2f;
                line-height: 1.6;
                font-size: 18px;
                margin: 0;
                padding: 32px 40px;
                max-width: none;
            }
            
            /* Headings with Claude's typography hierarchy */
            h1 { 
                font-size: 28px;
                font-weight: 600;
                color: #1a1a1a;
                margin: 32px 0 20px 0;
                padding-bottom: 8px;
                border-bottom: 1px solid #e5e7eb;
            }
            
            h2 { 
                font-size: 24px;
                font-weight: 600;
                color: #1a1a1a;
                margin: 28px 0 16px 0;
                padding-bottom: 6px;
                border-bottom: 1px solid #e5e7eb;
            }
            
            h3 {
                font-size: 20px;
                font-weight: 600;
                color: #1a1a1a;
                margin: 24px 0 12px 0;
            }
            
            h4, h5, h6 {
                font-size: 18px;
                font-weight: 600;
                color: #1a1a1a;
                margin: 20px 0 12px 0;
            }
            
            /* Paragraphs and text */
            p {
                margin: 16px 0;
                color: #2f2f2f;
            }
            
            /* Code styling similar to Claude's interface */
            code {
                font-family: "SF Mono", Monaco, Inconsolata, "Roboto Mono", "Source Code Pro", monospace;
                background-color: #f3f4f6;
                color: #374151;
                padding: 2px 6px;
                border-radius: 4px;
                font-size: 14px;
                border: 1px solid #e5e7eb;
            }
            
            pre {
                background-color: #f8f9fa;
                border: 1px solid #e5e7eb;
                border-radius: 8px;
                padding: 16px 20px;
                margin: 20px 0;
                overflow-x: auto;
                font-family: "SF Mono", Monaco, Inconsolata, "Roboto Mono", "Source Code Pro", monospace;
                font-size: 14px;
                line-height: 1.5;
                color: #374151;
            }
            
            pre code {
                background: none;
                border: none;
                padding: 0;
                color: inherit;
                font-size: inherit;
            }
            
            /* Lists */
            ul, ol {
                margin: 16px 0;
                padding-left: 28px;
            }
            
            li {
                margin: 8px 0;
                line-height: 1.6;
            }
            
            /* Tables with Claude-style borders */
            table {
                border-collapse: collapse;
                width: 100%;
                margin: 20px 0;
                border: 1px solid #e5e7eb;
                border-radius: 8px;
                overflow: hidden;
            }
            
            th {
                background-color: #f8f9fa;
                font-weight: 600;
                color: #374151;
                padding: 12px 16px;
                text-align: left;
                border-bottom: 1px solid #e5e7eb;
            }
            
            td {
                padding: 12px 16px;
                border-bottom: 1px solid #f3f4f6;
                color: #2f2f2f;
            }
            
            tr:last-child td {
                border-bottom: none;
            }
            
            /* Blockquotes */
            blockquote {
                border-left: 4px solid #d1d5db;
                background-color: #f9fafb;
                margin: 20px 0;
                padding: 16px 20px;
                color: #4b5563;
                border-radius: 0 6px 6px 0;
            }
            
            blockquote p {
                margin: 0;
            }
            
            /* Links with Claude's colour scheme */
            a {
                color: #2563eb;
                text-decoration: none;
                font-weight: 500;
            }
            
            a:hover {
                text-decoration: underline;
                color: #1d4ed8;
            }
            
            /* Images */
            img {
                max-width: 100%;
                height: auto;
                border-radius: 6px;
                margin: 16px 0;
            }
            
            /* Horizontal rules */
            hr {
                border: none;
                height: 1px;
                background-color: #e5e7eb;
                margin: 32px 0;
            }
            
            /* Strong and emphasis */
            strong {
                font-weight: 600;
                color: #1a1a1a;
            }
            
            em {
                color: #4b5563;
            }
        </style>
        """
        
        return claude_css + html_content

    def handle_anchor_clicked(self, url):
        """Handle clicked links - open external links in default browser"""
        QDesktopServices.openUrl(url)

def main():
    app = QApplication(sys.argv)
    reader = ReadmeReader()
    reader.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()