import json
import os
import re
import sys
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                            QLabel, QTextEdit, QPushButton, QSpinBox, QMessageBox,
                            QTabWidget, QStatusBar)
from PyQt6.QtCore import Qt, QSize
from PyQt6.QtGui import QTextCursor

# Optional ML imports with graceful fallback
ST_AVAILABLE = False
SK_AVAILABLE = False
try:
    from sentence_transformers import SentenceTransformer
    import numpy as np
    ST_AVAILABLE = True
except ImportError:
    pass
try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.preprocessing import normalize as sk_normalize
    from sklearn.metrics.pairwise import cosine_similarity
    SK_AVAILABLE = True
except ImportError:
    pass

import difflib

# -------- Configuration --------
DEFAULT_JSON_FILES = [
    "llm-error-database_0.3.0.json",
    "llm-error-database_0.2.0.json",
]

# Light brown colour scheme
THEME_BG = "#f5f0e6"        # Light beige-brown background
THEME_PANEL = "#e8d9c5"     # Light tan panel background
THEME_ACCENT = "#d4b483"    # Medium brown accent colour
THEME_TEXT = "#4a3c2a"      # Dark brown text colour
THEME_HIGHLIGHT = "#e8e0d5" # Light beige for PyCharm instructions
THEME_BORDER = "#a38f6b"    # Brown border colour

# -------- Utility functions --------
def read_dataset_from_root():
    """Read the error dataset from default locations."""
    for candidate in DEFAULT_JSON_FILES:
        if os.path.exists(candidate):
            try:
                with open(candidate, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if not isinstance(data, list):
                        raise ValueError("JSON data should be an array of error objects")
                    if len(data) == 0:
                        raise ValueError("JSON file contains no error entries")
                    return data, candidate
            except json.JSONDecodeError as e:
                raise ValueError(f"Invalid JSON in {candidate}: {str(e)}")
            except Exception as e:
                raise ValueError(f"Error reading {candidate}: {str(e)}")
    
    raise FileNotFoundError(f"Could not find any of: {', '.join(DEFAULT_JSON_FILES)}")

EXC_RE = re.compile(r"\b([A-Za-z_]+(?:Error|Warning))\b")

def extract_exception_types(text):
    """Extract all exception types mentioned in text."""
    return set(m.group(1) for m in EXC_RE.finditer(text or ""))

def safe_normalize(vec):
    """Safely normalize a numpy array, handling zero vectors."""
    if not isinstance(vec, np.ndarray):
        return vec
    norm = np.linalg.norm(vec, axis=1, keepdims=True)
    norm[norm == 0.0] = 1.0
    return vec / norm

# -------- Similarity Engine --------
class SimilarityEngine:
    def __init__(self, error_data):
        """Initialize the similarity engine with error data."""
        self.error_data = error_data
        self.examples = [entry.get("example_error_message", "") or entry.get("error", "") for entry in error_data]
        self.example_exceptions = [extract_exception_types(x) for x in self.examples]
        self.example_tags = [set(entry.get("tags", [])) for entry in error_data]
        self.example_severities = [entry.get("severity", "medium") for entry in error_data]

        self.mode = None
        self.embeddings = None
        self.word_vec = None
        self.char_vec = None
        self.word_mat = None
        self.char_mat = None

        if ST_AVAILABLE:
            self._init_sentence_transformer()
        elif SK_AVAILABLE:
            self._init_tfidf()
        else:
            self.mode = "difflib"

    def _init_sentence_transformer(self):
        """Initialize the SentenceTransformer model."""
        self.mode = "sentence-transformers"
        self.model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
        texts_to_embed = [
            f"{entry.get('description','')} {entry.get('example_error_message','')} "
            f"{entry.get('solution instruction','')} {' '.join(entry.get('tags',[]))} "
            f"{entry.get('severity','')}"
            for entry in self.error_data
        ]
        self.embeddings = self.model.encode(texts_to_embed, convert_to_numpy=True, show_progress_bar=False)
        self.embeddings = safe_normalize(self.embeddings)

    def _init_tfidf(self):
        """Initialize the TF-IDF vectorizers."""
        self.mode = "tfidf"
        self.word_vec = TfidfVectorizer(
            lowercase=True,
            ngram_range=(1, 3),
            analyzer="word",
            min_df=1,
            max_features=50000
        )
        self.char_vec = TfidfVectorizer(
            lowercase=True,
            analyzer="char_wb",
            ngram_range=(3, 5),
            min_df=1,
            max_features=50000
        )
        texts_for_tfidf = [
            f"{entry.get('description','')} {entry.get('example_error_message','')} "
            f"{entry.get('solution instruction','')} {' '.join(entry.get('tags',[]))} "
            f"{entry.get('severity','')}"
            for entry in self.error_data
        ]
        self.word_mat = self.word_vec.fit_transform(texts_for_tfidf)
        self.char_mat = self.char_vec.fit_transform(texts_for_tfidf)
        self.word_mat = sk_normalize(self.word_mat, norm="l2", copy=False)
        self.char_mat = sk_normalize(self.char_mat, norm="l2", copy=False)

    def _semantic_scores(self, query):
        """Calculate semantic similarity scores for the query."""
        if self.mode == "sentence-transformers":
            q = self.model.encode([query], convert_to_numpy=True, show_progress_bar=False)
            q = safe_normalize(q)
            return (q @ self.embeddings.T).ravel()
        elif self.mode == "tfidf":
            q_word = self.word_vec.transform([query])
            q_char = self.char_vec.transform([query])
            q_word = sk_normalize(q_word, norm="l2", copy=False)
            q_char = sk_normalize(q_char, norm="l2", copy=False)
            w_sim = cosine_similarity(q_word, self.word_mat).ravel()
            c_sim = cosine_similarity(q_char, self.char_mat).ravel()
            return 0.55 * w_sim + 0.45 * c_sim
        else:
            return [difflib.SequenceMatcher(None, query, ex).ratio() for ex in self.examples]

    def _exception_boosts(self, query):
        """Calculate exception matching boosts."""
        q_exc = extract_exception_types(query)
        boosts = []
        for e in self.example_exceptions:
            if not q_exc and not e:
                boosts.append(0.0)
            elif q_exc == e and len(e) > 0:
                boosts.append(1.0)
            elif q_exc & e:
                boosts.append(0.2)
            else:
                boosts.append(0.0)
        return boosts

    def _tag_boosts(self, query):
        """Calculate tag matching boosts."""
        query_lower = query.lower()
        boosts = []
        for tags in self.example_tags:
            match_count = sum(1 for tag in tags if tag.lower() in query_lower)
            boost = min(0.15 * match_count, 0.3)
            boosts.append(boost)
        return boosts

    def _severity_boosts(self, query):
        """Calculate severity matching boosts."""
        serious_words = {'error', 'fail', 'crash', 'broken', 'fatal', 'critical'}
        query_words = set(query.lower().split())
        is_serious = len(serious_words & query_words) > 0
        
        boosts = []
        for sev in self.example_severities:
            if is_serious and sev.lower() == "high":
                boosts.append(0.1)
            else:
                boosts.append(0.0)
        return boosts

    def rank(self, query, top_k=3):
        """Rank errors by similarity to the query."""
        sem = self._semantic_scores(query)
        exc_boosts = self._exception_boosts(query)
        tag_boosts = self._tag_boosts(query)
        sev_boosts = self._severity_boosts(query)
        
        final = [
            0.75 * s + 0.15 * exc + 0.07 * tag + 0.03 * sev
            for s, exc, tag, sev in zip(sem, exc_boosts, tag_boosts, sev_boosts)
        ]
        
        idxs = sorted(range(len(final)), key=lambda i: final[i], reverse=True)[:top_k]
        return idxs, [final[i] for i in idxs], [sem[i] for i in idxs], [exc_boosts[i] for i in idxs]

# -------- Qt6 GUI --------
class ErrorMatcherApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("LLM Error Matcher 0.8.2  ·  Concept & Design by Peer-Olaf Siebers  ·  Implementation by Gemini Flash 2.5")
        self.setMinimumSize(QSize(900, 650))
        self.engine = None
        self._setup_ui()
        self._load_initial_data()
        
    def _setup_ui(self):
        """Set up the user interface."""
        self.setStyleSheet(f"""
            QMainWindow {{ background-color: {THEME_BG}; }}
            QTextEdit {{
                background-color: {THEME_PANEL};
                border: 1px solid {THEME_BORDER};
                font-family: 'Segoe UI';
                font-size: 10pt;
            }}
            QLabel {{
                color: {THEME_TEXT};
                font-family: 'Segoe UI';
                font-size: 10pt;
            }}
            QPushButton {{
                background-color: {THEME_ACCENT};
                color: {THEME_TEXT};
                border: 1px solid {THEME_BORDER};
                border-radius: 4px;
                padding: 5px;
                min-width: 80px;
                font-size: 11pt;
            }}
            QPushButton:hover {{ background-color: {THEME_PANEL}; }}
            .pycharm-instructions {{
                background-color: {THEME_HIGHLIGHT};
                padding: 8px;
                border-left: 4px solid {THEME_ACCENT};
                margin: 5px 0;
                font-family: 'Segoe UI';
                font-size: 10pt;
            }}
            .result-title {{
                font-weight: bold;
                font-size: 11pt;
                margin-top: 6px;
                color: {THEME_ACCENT};
            }}
            .divider {{
                margin: 12px 0;
                border-top: 1px solid {THEME_BORDER};
            }}
            .tags {{
                font-style: italic;
                color: {THEME_BORDER};
            }}
            .severity-high {{
                color: #c44e4e;
                font-weight: bold;
            }}
            .severity-medium {{
                color: #cc9c00;
            }}
            .severity-low {{
                color: #4a8f4a;
            }}
            QTextEdit h2 {{ font-size: 14pt; color: {THEME_ACCENT}; }}
            QTextEdit h3 {{ font-size: 12pt; color: {THEME_TEXT}; }}
        """)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(16, 16, 16, 16)
        
        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs)
        
        self._setup_matcher_tab()
        self._setup_help_tab()
        
        # Add status bar
        self.statusBar = QStatusBar()
        self.setStatusBar(self.statusBar)
        self.statusBar.showMessage("Ready")

    def _create_text_editor(self, placeholder_text="", read_only=False):
        """Helper to create a configured QTextEdit."""
        text_edit = QTextEdit()
        text_edit.setPlaceholderText(placeholder_text)
        text_edit.setLineWrapMode(QTextEdit.LineWrapMode.WidgetWidth)
        text_edit.setReadOnly(read_only)
        return text_edit

    def _setup_matcher_tab(self):
        """Set up the main error matching tab."""
        matcher_widget = QWidget()
        matcher_layout = QVBoxLayout(matcher_widget)
        matcher_layout.setContentsMargins(0, 0, 0, 0)
        matcher_layout.setSpacing(10)
        
        # Input section
        self.input_text = self._create_text_editor("Paste your error message here ...")
        matcher_layout.addWidget(self.input_text)

        # Controls
        controls = QHBoxLayout()
        controls.addWidget(QLabel("Number of Matches:"))
        
        self.topk_spin = QSpinBox()
        self.topk_spin.setRange(1, 5)
        self.topk_spin.setValue(1)
        controls.addWidget(self.topk_spin)

        match_btn = QPushButton("Find Closest Match")
        match_btn.clicked.connect(self._match_error)
        controls.addWidget(match_btn)

        clear_btn = QPushButton("Clear")
        clear_btn.clicked.connect(self._clear_all)
        controls.addWidget(clear_btn)

        matcher_layout.addLayout(controls)

        # Results section
        self.result_box = self._create_text_editor("", read_only=True)
        matcher_layout.addWidget(self.result_box, stretch=1)

        self.tabs.addTab(matcher_widget, "Matcher")

    def _setup_help_tab(self):
        """Set up the help tab with internal workings explanation."""
        help_widget = QWidget()
        help_layout = QVBoxLayout(help_widget)
        help_layout.setContentsMargins(16, 16, 16, 16)
        
        help_text_content = """
        <h3>How the Error Matcher Works</h3>
        <p>This application uses a sophisticated ranking system to find the best match for a given error message from its internal dataset. The core of this system is a weighted combination of different similarity metrics and boosts.</p>
        
        <h3>1. Core Similarity Calculation (75% Weight)</h3>
        <p>The main component is a semantic similarity score, which measures how close the meaning of your error message is to the examples in the dataset. This is done using one of three methods, depending on which optional libraries are installed:</p>
        <ul>
            <li><b>Semantic Model (Best Accuracy):</b> If the <code>sentence-transformers</code> library is available, the app uses a pre-trained language model (all-MiniLM-L6-v2) to convert text into numerical vectors (embeddings). The similarity is then calculated by finding the cosine similarity between your input's vector and the dataset's vectors. This method understands context and meaning, even if the exact words are different.</li>
            <li><b>TF-IDF (Good Accuracy):</b> If <code>scikit-learn</code> is available but <code>sentence-transformers</code> is not, the app falls back to a TF-IDF (Term Frequency-Inverse Document Frequency) approach. This method weights words and character combinations based on their importance in the dataset. A combined score is calculated from both word-based and character-based TF-IDF similarities.</li>
            <li><b>Difflib (Basic Fallback):</b> If neither of the above libraries is found, the app uses Python's built-in <code>difflib</code> library. This is a basic string-matching algorithm that measures the ratio of characters in common. It is less effective than the other two methods as it doesn't understand context or meaning.</li>
        </ul>
        
        <h3>2. Boosts for Specific Features</h3>
        <p>The semantic score is then "boosted" by three additional factors that help refine the final match. These boosts are added to the semantic score to create the final ranking:</p>
        <ul>
            <li><b>Exception Boost (15% Weight):</b> The application extracts specific exception names (e.g., <code>ValueError</code>, <code>KeyError</code>) from both your input and the dataset entries. A significant boost is applied if the exception names match exactly. A smaller boost is given if there's any overlap between the exception names.</li>
            <li><b>Tag Boost (7% Weight):</b> The app checks if any of the tags associated with a dataset entry (e.g., "installation", "api-call") appear within your error message. Each matching tag adds a small boost, up to a maximum of 0.3.</li>
            <li><b>Severity Boost (3% Weight):</b> If your input message contains words like "error," "fail," or "critical" and the matched dataset entry is marked as "high" severity, a small boost is added.</li>
        </ul>
        
        <h3>3. Final Ranking</h3>
        <p>The final score for each potential match is a weighted sum of the semantic score and the three boosts: <code>Final Score = 0.75 * Semantic + 0.15 * Exception + 0.07 * Tag + 0.03 * Severity</code>.</p>
        <p>The entries are then sorted by this final score, and the top-ranked results are displayed for you.</p>
        """
        
        self.help_text_box = self._create_text_editor(read_only=True)
        self.help_text_box.setHtml(help_text_content)
        help_layout.addWidget(self.help_text_box)
        
        self.tabs.addTab(help_widget, "How it Works")

    def _load_initial_data(self):
        """Load the initial dataset."""
        try:
            self.error_data, self.loaded_file = read_dataset_from_root()
            self.engine = SimilarityEngine(self.error_data)
            
            # Update status bar with engine mode
            mode_display = self.engine.mode.replace('-', ' ').title()
            
            self.statusBar.showMessage(f"Similarity Engine: {mode_display} | Loaded {len(self.error_data)} error patterns")
        except Exception as e:
            QMessageBox.critical(self, "Dataset Error", str(e))
            sys.exit(1)

    def _clear_all(self):
        """Clear both input and result screens."""
        self.input_text.clear()
        self.result_box.clear()
        self.result_box.moveCursor(QTextCursor.MoveOperation.Start)
        self.statusBar.showMessage("Ready")

    def _match_error(self):
        """Match the input error against the dataset."""
        user_input = self.input_text.toPlainText().strip()
        if not user_input:
            QMessageBox.warning(self, "Input Error", "Please paste an error message first.")
            return

        top_k = self.topk_spin.value()
        idxs, final_scores, sem_scores, exc_boosts = self.engine.rank(user_input, top_k=top_k)
        self.result_box.clear()

        if not idxs:
            self.result_box.append("No match found.")
        else:
            for rank, (i, fsc, ssc, exc) in enumerate(zip(idxs, final_scores, sem_scores, exc_boosts), start=1):
                entry = self.error_data[i]
                severity_class = f"severity-{entry.get('severity', 'Medium').lower()}"
                
                # HTML content based on the new JSON structure and display order
                result_html = f"""
                <div class="result-block">
                    <div class="result-title">Match {rank} • Score {fsc:.3f}</div>
                    <div><b>Semantic:</b> {ssc:.3f} • <b>Exception Boost:</b> {exc:.2f}</div>
                    <p><b>Name:</b> <span style="background: yellow; padding: 2px 2px;">{entry.get('name','')}</span></p>
                    <p><b>Example Error Message:</b> {entry.get('example_error_message','')}</p>
                    <p><b>Description:</b> {entry.get('description','')}</p>
                    <p><b>LLM-Generated Code Pattern:</b><pre><code>{entry.get('LLM-Generated Code Pattern','')}</code></pre></p>
                    <p><b>Solution Instruction:</b> {entry.get('solution instruction','')}</p>
                    <p class="{severity_class}"><b>Severity:</b> {entry.get('severity', 'Medium')}</p>
                    <p><b>Run-time or Compile Time Error:</b> {entry.get('run-time or compile time error','')}</p>
                    <p><b>Frequency in LLM Code:</b> {entry.get('frequency_in_llm_code','')}</p>
                    <div class="tags"><b>Tags:</b> {', '.join(entry.get('tags', []))}</div>
                    <div class="divider"></div>
                </div>
                """
                
                self.result_box.append(result_html)

        self.result_box.moveCursor(QTextCursor.MoveOperation.Start)
        self.statusBar.showMessage(f"Found {len(idxs)} matches")

if __name__ == "__main__":
    print("Init Similarity Engine ...")
    missing = []
    if not ST_AVAILABLE:
        missing.append("sentence-transformers")
    if not SK_AVAILABLE:
        missing.append("scikit-learn")
    if missing:
        print(
            "Optional dependencies missing: "
            + ", ".join(missing)
            + ".\nThe application will still run with reduced accuracy.\n"
            + "Install for best results, for example:\n"
            + "    pip install sentence-transformers scikit-learn\n",
            file=sys.stderr
        )
    app = QApplication(sys.argv)
    window = ErrorMatcherApp()
    print("Init App ...")
    window.show()
    sys.exit(app.exec())