# Changelog

All notable changes to this project will be documented in this file.

## [v0.8.2] - 2025-08-21

### Changed
- Updated error database to version 0.3.0
- Enhanced application core to support new database schema and object definitions
- Improved data parsing logic for compatibility with updated error entry format

## [v0.8.1] - 2025-08-19

### Added
- Initial release of LLM Error Matcher desktop application
