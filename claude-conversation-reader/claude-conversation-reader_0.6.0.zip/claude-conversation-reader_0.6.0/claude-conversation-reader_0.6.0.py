"""
Claude Conversations Reader.

A PyQt6 application for viewing Claude conversation exports with search and highlighting.
Supports Claude's conversation export format with complete code reconstruction in message context.
"""

import sys
import json
import zipfile
import re
import os
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QFileDialog, QMessageBox, QFrame, QSplitter,
    QListWidget, QListWidgetItem, QProgressBar, QLabel,
    QPushButton, QLineEdit
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QFont, QFontDatabase, QColor, QIcon
from PyQt6.QtWebEngineWidgets import QWebEngineView
from markdown_it import MarkdownIt


class AppConfig:
    """Application configuration constants."""
    CONVERSATIONS_FILE = "conversations.json"
    DEFAULT_TITLE = "Untitled Conversation"
    FONT_FAMILY = "Inter"
    WINDOW_TITLE = "Claude Conversation Reader"
    WINDOW_SIZE = (1200, 800)
    WINDOW_POSITION = (100, 100)
    SIDEBAR_MIN_WIDTH = 280
    SPLITTER_SIZES = [300, 700]
    TITLE_MAX_LENGTH = 50
    CODE_FOLD_THRESHOLD = 10


class SearchMatchType(Enum):
    """Types of search matches for conversation filtering."""
    TITLE_ONLY = "[Title]"
    CONTENT_ONLY = "[Content]"
    BOTH = "[Title + Content]"


class MessageExtractor:
    """Handles extraction of text content from Claude message formats."""
    
    @staticmethod
    def extract_text(message: Dict[str, Any]) -> str:
        """Extract text from Claude message format."""
        if not isinstance(message, dict):
            return ""
        
        content = message.get('content', [])
        if isinstance(content, list):
            text_parts = []
            for item in content:
                if isinstance(item, dict):
                    if item.get('type') == 'text':
                        text = item.get('text', '')
                        if text:
                            text_parts.append(text)
                    elif item.get('type') == 'tool_use' and item.get('name') == 'artifacts':
                        # Skip HTML artifacts here - they'll be handled separately
                        artifact_input = item.get('input', {})
                        artifact_type = artifact_input.get('type', '')
                        if artifact_type != 'text/html':
                            text_parts.extend(MessageExtractor._extract_artifact(item))
            return '\n'.join(text_parts)
        elif isinstance(content, str):
            return content
        
        return ""
    
    @staticmethod
    def extract_html_artifacts(message: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Extract HTML artifacts from message for direct HTML insertion."""
        if not isinstance(message, dict):
            return []
        
        html_artifacts = []
        content = message.get('content', [])
        if isinstance(content, list):
            for item in content:
                if isinstance(item, dict):
                    if item.get('type') == 'tool_use' and item.get('name') == 'artifacts':
                        artifact_input = item.get('input', {})
                        artifact_type = artifact_input.get('type', '')
                        if artifact_type == 'text/html':
                            html_artifacts.append({
                                'content': artifact_input.get('content', ''),
                                'name': artifact_input.get('name', '')
                            })
        
        return html_artifacts

    @staticmethod
    def _extract_artifact(item: Dict[str, Any]) -> List[str]:
        """Extract artifact content from tool_use item."""
        artifact_input = item.get('input', {})
        artifact_type = artifact_input.get('type', '')
        artifact_content = artifact_input.get('content', '')
        artifact_language = artifact_input.get('language', '')
        artifact_name = artifact_input.get('name', '')
        
        if not artifact_content:
            return []
        
        if artifact_type == 'application/vnd.ant.code':
            lang_label = artifact_language if artifact_language else 'code'
            return [f"\n```{lang_label}\n{artifact_content}\n```\n"]
        elif artifact_type == 'text/markdown':
            lang_hint = f" ({artifact_language})" if artifact_language else ""
            name_hint = f" - {artifact_name}" if artifact_name else ""
            return [
                f"\n--- Markdown Artifact{name_hint}{lang_hint} ---\n",
                artifact_content,
                "\n--- End Markdown Artifact ---\n"
            ]
        elif artifact_type.startswith('text/'):
            text_type = artifact_type.split('/')[-1]
            name_hint = f" - {artifact_name}" if artifact_name else ""
            return [
                f"\n--- {text_type.capitalize()} Artifact{name_hint} ---\n",
                artifact_content,
                f"\n--- End {text_type.capitalize()} Artifact ---\n"
            ]
        else:
            type_name = artifact_type.split('/')[-1] if '/' in artifact_type else artifact_type
            name_hint = f" - {artifact_name}" if artifact_name else ""
            return [
                f"\n--- {type_name.capitalize()} Artifact{name_hint} ---\n",
                artifact_content,
                f"\n--- End {type_name.capitalize()} Artifact ---\n"
            ]

    @staticmethod
    def has_meaningful_content(conversation: Dict[str, Any]) -> bool:
        """Check if conversation contains meaningful text content."""
        chat_messages = conversation.get('chat_messages', [])
        return any(MessageExtractor.extract_text(msg) for msg in chat_messages)
    
    @staticmethod
    def reconstruct_complete_code(messages: List[Dict[str, Any]]) -> Dict[str, str]:
        """Reconstruct complete code from update operations and return mapping of original to final code."""
        code_updates = {}
        current_code = ""
        
        for message in messages:
            if not isinstance(message, dict):
                continue
                
            content = message.get('content', [])
            if isinstance(content, list):
                for item in content:
                    if (isinstance(item, dict) and 
                        item.get('type') == 'tool_use' and 
                        item.get('name') == 'artifacts'):
                        artifact_input = item.get('input', {})
                        artifact_type = artifact_input.get('type', '')
                        command = artifact_input.get('command')
                        artifact_content = artifact_input.get('content', '')
                        
                        if command == 'create' and artifact_type == 'application/vnd.ant.code':
                            current_code = artifact_content
                            code_updates[artifact_content] = current_code
                            
                        elif command == 'update':
                            old_str = artifact_input.get('old_str', '')
                            new_str = artifact_input.get('new_str', '')
                            
                            if current_code and old_str and new_str is not None:
                                if current_code.endswith(old_str):
                                    new_current_code = current_code[:-len(old_str)] + new_str
                                    
                                    for old_content in list(code_updates.keys()):
                                        if code_updates[old_content] == current_code:
                                            code_updates[old_content] = new_current_code
                                    current_code = new_current_code
                                    
                                elif old_str in current_code:
                                    current_code = current_code.replace(old_str, new_str, 1)
                                    for old_content in list(code_updates.keys()):
                                        if old_str in old_content:
                                            code_updates[old_content] = current_code
        
        return code_updates

    @staticmethod
    def get_final_code(messages: List[Dict[str, Any]]) -> str:
        """Get the final complete code after all updates."""
        code_updates = MessageExtractor.reconstruct_complete_code(messages)
        return list(code_updates.values())[-1] if code_updates else ""

    @staticmethod
    def has_code_artifacts(messages: List[Dict[str, Any]]) -> bool:
        """Check if messages contain code artifacts that can be reconstructed."""
        for message in messages:
            if not isinstance(message, dict):
                continue
                
            content = message.get('content', [])
            if isinstance(content, list):
                for item in content:
                    if (isinstance(item, dict) and 
                        item.get('type') == 'tool_use' and 
                        item.get('name') == 'artifacts'):
                        artifact_type = item.get('input', {}).get('type', '')
                        if artifact_type == 'application/vnd.ant.code':
                            return True
        return False


class ConversationProcessor:
    """Handles Claude conversation data processing and formatting."""
    
    @staticmethod
    def get_messages(conversation: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Extract messages from Claude conversation data structure."""
        return conversation.get('chat_messages', [])

    @staticmethod
    def get_content_text(conversation: Dict[str, Any]) -> str:
        """Get full textual content of a conversation."""
        messages = ConversationProcessor.get_messages(conversation)
        text_parts = [MessageExtractor.extract_text(msg) for msg in messages if MessageExtractor.extract_text(msg)]
        return " ".join(text_parts)

    @staticmethod
    def format_timestamp(timestamp: Any) -> str:
        """Format timestamp string for display."""
        if not timestamp:
            return ""
        
        try:
            if isinstance(timestamp, str):
                dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            elif isinstance(timestamp, (int, float)):
                dt = datetime.fromtimestamp(timestamp)
            else:
                return ""
            
            return dt.strftime("%d/%m/%Y @ %H:%M:%S")
        except Exception:
            return ""

    @staticmethod
    def generate_title(conversation: Dict[str, Any]) -> str:
        """Generate display title for conversation."""
        title = conversation.get('name', '').strip()
        
        if not title:
            messages = ConversationProcessor.get_messages(conversation)
            first_user_msg = next((msg for msg in messages if msg.get('sender') == 'human'), None)
            if first_user_msg:
                title = MessageExtractor.extract_text(first_user_msg)
            
            if not title:
                title = AppConfig.DEFAULT_TITLE
            elif len(title) > AppConfig.TITLE_MAX_LENGTH:
                title = title[:AppConfig.TITLE_MAX_LENGTH] + "..."
        
        timestamp = ConversationProcessor.format_timestamp(
            conversation.get('created_at') or conversation.get('updated_at')
        )
        return f"{title} @ {timestamp}" if timestamp else title

    @staticmethod
    def get_message_sender(message: Dict[str, Any]) -> str:
        """Get the sender for a message."""
        sender = message.get('sender', 'unknown')
        return sender if sender in ['human', 'assistant'] else 'unknown'

    @staticmethod
    def get_message_timestamp(message: Dict[str, Any]) -> str:
        """Get formatted timestamp for a message."""
        timestamp = message.get('created_at')
        return ConversationProcessor.format_timestamp(timestamp)


class SearchManager:
    """Manages search functionality and conversation filtering."""

    def __init__(self, conversation_list: QListWidget, chat_text: QWebEngineView, search_bar: QLineEdit):
        self.conversation_list = conversation_list
        self.chat_text = chat_text
        self.search_bar = search_bar
        self.current_query = ""
        self.conversations: List[Dict[str, Any]] = []

    def set_conversations(self, conversations: List[Dict[str, Any]]) -> None:
        """Set the conversations list for searching."""
        self.conversations = conversations

    def search(self, query: str) -> None:
        """Perform search and update conversation list."""
        self.current_query = query.strip() if query else ""
        self.conversation_list.clear()

        if not self.current_query:
            self._restore_full_list()
            return

        self._filter_conversations()

    def clear(self) -> None:
        """Clear search and restore full conversation list."""
        self.current_query = ""
        self.search_bar.clear()
        self.conversation_list.clear()
        self._restore_full_list()

    def _restore_full_list(self) -> None:
        """Restore full conversation list."""
        for conv in self.conversations:
            self.conversation_list.addItem(ConversationListItem(conv))
        
        if self.conversation_list.count() > 0:
            self.conversation_list.setCurrentRow(0)
            self._select_first_item()

    def _filter_conversations(self) -> None:
        """Filter conversations based on search query."""
        query_lower = self.current_query.lower()
        matches = []

        for conv in self.conversations:
            item = ConversationListItem(conv)
            title_text = (item.text() or "").lower()
            content_text = ConversationProcessor.get_content_text(conv).lower()
            
            title_match = query_lower in title_text
            content_match = query_lower in content_text

            if title_match or content_match:
                match_type = self._get_match_type(title_match, content_match)
                item.setText(f"{match_type.value} {item.text()}")
                
                item.setData(Qt.ItemDataRole.UserRole, {
                    "query": self.current_query,
                    "title_match": title_match,
                    "content_match": content_match
                })
                
                matches.append(item)

        if not matches:
            self.chat_text.setHtml("<h3>No conversations matched your search</h3>")
        else:
            for item in matches:
                self.conversation_list.addItem(item)
            self.conversation_list.setCurrentRow(0)
            self._select_first_item()

    def _get_match_type(self, title_match: bool, content_match: bool) -> SearchMatchType:
        """Determine the type of search match."""
        if title_match and content_match:
            return SearchMatchType.BOTH
        elif title_match:
            return SearchMatchType.TITLE_ONLY
        else:
            return SearchMatchType.CONTENT_ONLY

    def _select_first_item(self) -> None:
        """Select the first item in the conversation list."""
        if self.conversation_list.count() > 0:
            self.conversation_list.setCurrentRow(0)
            self.conversation_list.itemClicked.emit(self.conversation_list.item(0))


class ConversationRenderer:
    """Handles conversation display and HTML rendering."""
    
    def __init__(self, markdown_processor: MarkdownIt):
        self.md = markdown_processor
        self.match_counter = 0
        self.current_matches = []
        self.code_block_counter = 0

    def _apply_html_highlighting(self, html_text: str, search_query: str) -> str:
        """Wrap search terms in HTML with a highlight class and unique IDs."""
        if not search_query:
            return html_text
        
        self.match_counter = 0
        self.current_matches = []
        
        pattern = re.compile(re.escape(search_query), re.IGNORECASE)
        
        def replacer(match):
            match_id = f"search-match-{self.match_counter}"
            self.current_matches.append(match_id)
            self.match_counter += 1
            return f'<span id="{match_id}" class="highlight">{match.group(0)}</span>'
        
        return pattern.sub(replacer, html_text)

    def _preprocess_latex(self, text: str) -> str:
        """Convert LaTeX delimiters to standard format."""
        text = re.sub(r'\\\[(.*?)\\\]', r'$$\1$$', text, flags=re.DOTALL)
        text = re.sub(r'\\\((.*?)\\\)', r'$\1$', text, flags=re.DOTALL)
        return text

    def _preprocess_tables(self, text: str) -> str:
        """Table preprocessing to ensure proper Markdown table formatting."""
        lines = text.split('\n')
        processed_lines = []
        in_code_block = False  # Track code blocks to avoid false table detection

        # Enhanced pattern to check if a line looks like a table separator
        separator_pattern = re.compile(r'^[\s\|:]*[-=]+[\s\|:]*$')
        
        for line in lines:
            stripped_line = line.strip()

            # 1. Handle code blocks (must be outside table processing)
            if stripped_line.startswith('```'):
                in_code_block = not in_code_block
                processed_lines.append(line)
                continue
            
            if in_code_block:
                processed_lines.append(line)
                continue
            
            # 2. Process potential table lines
            if '|' in line and line.count('|') >= 2:
                # Standardize padding around pipes
                line = re.sub(r'\s*\|\s*', ' | ', line)
                line = line.strip()
                
                # Ensure line starts and ends with a pipe for strict adherence
                if not line.startswith('|'):
                    line = '| ' + line
                if not line.endswith('|'):
                    line = line + ' |'
                
                # Check if the line is a separator line (e.g., |---|---|)
                is_separator = separator_pattern.match(line.replace(' ', ''))
                
                if processed_lines and not is_separator:
                    # Look at the previous line
                    prev_line = processed_lines[-1].strip()

                    if not prev_line or separator_pattern.match(prev_line.replace(' ', '')):
                        # If the previous line is empty or is already a separator, 
                        # this current line is likely the header. Append it, 
                        # relying on markdown-it to find a separator next.
                        processed_lines.append(line)
                        # REMOVED: explicit insertion of the separator line
                    
                    elif not '|' in prev_line or separator_pattern.match(prev_line.replace(' ', '')):
                         # This line is a potential table row, but the line before 
                         # it wasn't a header or separator. We append the line,
                         # relying on markdown-it to parse it as content.
                         processed_lines.append(line)

                    elif '|' in prev_line:
                        # If the previous line was a row/header, just append the current line (which is a row)
                        processed_lines.append(line)
                    
                    else:
                        # Append the line and insert a default header/separator
                        # to ensure the table starts correctly.
                        # This is a safe fallback for orphaned pipe content.
                        col_count = line.count('|') - 1
                        default_header = '| Header ' + ' | Header ' * (col_count - 1) + ' |'
                        separator = '|' + ' --- |' * col_count
                        processed_lines.append(default_header)
                        processed_lines.append(separator)
                        processed_lines.append(line)
                
                else:
                    # Line is the first line of the document, or previous line was non-pipe content
                    if not is_separator:
                        # It's a row/header. Treat it as header and insert separator.
                        col_count = line.count('|') - 1
                        separator = '|' + ' --- |' * col_count
                        processed_lines.append(line)
                        processed_lines.append(separator)
                    else:
                        # It is a separator, just append it.
                        processed_lines.append(line)
            
            else:
                # Non-table line
                processed_lines.append(line)
        
        return '\n'.join(processed_lines)

    def _wrap_code_blocks_with_folding(self, html_text: str) -> str:
        """Wrap code blocks with collapsible containers and add copy button."""
        pattern = re.compile(r'(<pre>)(.*?)(</pre>)', re.DOTALL)
        
        def replacer(match):
            pre_open = match.group(1)
            code_content_html = match.group(2)
            pre_close = match.group(3)
            
            line_count = code_content_html.count('\n')
            collapsed_class = 'collapsed' if line_count > AppConfig.CODE_FOLD_THRESHOLD else ''
            
            lang_match = re.search(r'class="language-(\w+)"', code_content_html)
            language = lang_match.group(1) if lang_match else 'code'
            
            block_id = f"code-block-{self.code_block_counter}"
            self.code_block_counter += 1
            
            return f'''
            <div class="code-container {collapsed_class}">
                <div class="code-header">
                    <div class="code-info">
                        <span class="code-language">{language}</span>
                        <span class="code-lines">({line_count} lines)</span>
                    </div>
                    <div class="code-controls">
                        <button class="copy-button" onclick="copyCode('{block_id}', this)">
                            <span class="copy-icon"></span>
                            <span class="copy-text">Copy</span>
                        </button>
                        <button class="code-toggle" onclick="toggleCode('{block_id}')">
                            <span class="toggle-icon">▼</span>
                        </button>
                    </div>
                </div>
                <div class="code-content" id="{block_id}">
                    {pre_open}{code_content_html}{pre_close}
                </div>
            </div>
            '''
        
        return pattern.sub(replacer, html_text)

    def render_conversation(self, conversation: Dict[str, Any], search_query: str = "") -> str:
        """Render conversation as HTML with complete code in context."""
        self.code_block_counter = 0
        messages = ConversationProcessor.get_messages(conversation)
        
        if not messages:
            return "<h3>No messages found in this conversation</h3>"

        final_code = ""
        if MessageExtractor.has_code_artifacts(messages):
            final_code = MessageExtractor.get_final_code(messages)

        message_html_parts = []
        for message in messages:
            if not isinstance(message, dict):
                continue
            
            # Extract HTML artifacts separately
            html_artifacts = MessageExtractor.extract_html_artifacts(message)
            
            # Extract regular text (excluding HTML artifacts)
            parsed_text = MessageExtractor.extract_text(message)
            
            # Process regular text through markdown
            processed_html = ""
            if parsed_text and parsed_text.strip():
                if final_code and "```" in parsed_text:
                    parsed_text = self._replace_code_with_final(parsed_text, final_code)

                processed_text = self._preprocess_tables(parsed_text)
                processed_text = self._preprocess_latex(processed_text)
                processed_html = self.md.render(processed_text)
                
                processed_html = self._wrap_code_blocks_with_folding(processed_html)
                
                if search_query:
                    processed_html = self._apply_html_highlighting(processed_html, search_query)
            
            # Insert HTML artifacts directly (not through markdown)
            if html_artifacts:
                html_artifact_html = self._render_html_artifacts(html_artifacts, search_query)
                if processed_html:
                    processed_html = processed_html + html_artifact_html
                else:
                    processed_html = html_artifact_html
            
            # Only create message if there's content
            if processed_html:
                message_html = self._render_message(message, processed_html)
                message_html_parts.append(message_html)
        
        if not message_html_parts:
            return "<h3>No readable messages found in this conversation</h3>"

        return f"<body>{self._get_base_styles_and_scripts()}\n" + "\n".join(message_html_parts) + "</body>"

    def _replace_code_with_final(self, parsed_text: str, final_code: str) -> str:
        """Replace truncated code blocks with complete final code."""
        lines = parsed_text.split('\n')
        processed_lines = []
        in_code_block = False
        code_block_replaced = False
        
        for line in lines:
            if line.strip().startswith('```') and not in_code_block:
                in_code_block = True
                if not code_block_replaced:
                    lang_match = re.match(r'```(\w+)', line)
                    language = lang_match.group(1) if lang_match else 'python'
                    processed_lines.append(f'```{language}')
                    processed_lines.extend(final_code.split('\n'))
                    processed_lines.append('```')
                    code_block_replaced = True
            elif line.strip().startswith('```') and in_code_block:
                in_code_block = False
            elif not in_code_block:
                processed_lines.append(line)
        
        return '\n'.join(processed_lines)

    def _get_base_styles_and_scripts(self) -> str:
        """Get base CSS styles and JavaScript for code display."""
        mathjax_config = """
        <script>
        window.MathJax = {
          tex: {
            inlineMath: [['$', '$']],
            displayMath: [['$$', '$$']]
          },
          startup: {
            ready: () => {
              MathJax.startup.defaultReady();
            }
          }
        };
        </script>
        <script type="text/javascript" id="MathJax-script" async
            src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js">
        </script>
        """ 
        
        code_folding_and_copy_script = """
        <script>
        function copyCode(blockId, buttonElement) {
            const codeContentDiv = document.getElementById(blockId);
            const preElement = codeContentDiv.querySelector('pre');
            if (!preElement) return;

            const codeText = preElement.innerText || preElement.textContent;

            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(codeText).then(() => {
                    showCopyConfirmation(buttonElement);
                }).catch(err => {
                    console.error('Could not copy text using Clipboard API: ', err);
                    fallbackCopy(codeText, buttonElement);
                });
            } else {
                fallbackCopy(codeText, buttonElement);
            }
        }

        function fallbackCopy(text, buttonElement) {
            const tempTextArea = document.createElement('textarea');
            tempTextArea.value = text;
            tempTextArea.style.position = 'fixed'; 
            tempTextArea.style.left = '-9999px';
            document.body.appendChild(tempTextArea);
            tempTextArea.focus();
            tempTextArea.select();
            try {
                document.execCommand('copy');
                showCopyConfirmation(buttonElement);
            } catch (err) {
                console.error('Fallback: Oops, unable to copy', err);
            }
            document.body.removeChild(tempTextArea);
        }

        function showCopyConfirmation(buttonElement) {
            const copyTextSpan = buttonElement.querySelector('.copy-text');
            const copyIconSpan = buttonElement.querySelector('.copy-icon');

            const originalText = 'Copy';
            const originalIcon = '';
            
            copyIconSpan.innerHTML = '&#x2714;';
            copyTextSpan.textContent = 'Copied!';
            buttonElement.classList.add('copied');

            setTimeout(() => {
                copyIconSpan.innerHTML = originalIcon;
                copyTextSpan.textContent = originalText;
                buttonElement.classList.remove('copied');
            }, 1500);
        }

        function toggleCode(blockId) {
            const container = document.getElementById(blockId).parentElement;
            const icon = container.querySelector('.toggle-icon');
            
            if (container.classList.contains('collapsed')) {
                container.classList.remove('collapsed');
                icon.textContent = '▼';
            } else {
                container.classList.add('collapsed');
                icon.textContent = '▶';
            }
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.code-container.collapsed .toggle-icon').forEach(icon => {
                icon.textContent = '▶';
            });
        });
        </script>
        """

        styles = """
        <style>
            body {
                font-family: 'Inter', 'Segoe UI', 'Helvetica Neue', 'Arial', 'sans-serif';
                font-size: 11pt;
                margin: 0 !important;
                padding: 0 !important;
                background-color: white !important;
                color: #2D3748;
            }

            /* Ensure MathJax elements have a proper z-index and overflow setting */
            mjx-container {
                z-index: 100 !important; /* Forces the math to render above other elements */
                overflow: visible !important; /* Important for multi-line and larger expressions */
                display: inline-block;
            }
            
            .message-content {
                position: relative; 
                z-index: 1; /* Ensure message content is in a stacking context */
            }
            
            /* Remove margins from the MathJax display container to prevent overlap */
            mjx-assistive-mml, 
            mjx-container[display="true"] {
                margin: 0 !important;
            }

            /* Message wrapper styling */
            .user-message, 
            .assistant-message {
                width: 100% !important;
                max-width: none !important;
                margin: 0 0 20px 0 !important;
                padding: 10px 15px !important;
                border-radius: 8px;
                box-sizing: border-box;
            }
            
            .user-message {
                background-color: #FFF9C4 !important;
            }
            
            .assistant-message {
                background-color: #FFF9C4 !important;
            }

            .message-content {
                width: 100%;
                text-align: left;
            }

            .message-content > div, 
            .message-content > p, 
            .message-content > blockquote, 
            .message-content > * { /* Use * to cover all immediate children, including the artifact's div */
                max-width: none !important; /* Override any max-width restriction */
                margin-left: 0 !important;  /* Reset left margin */
                margin-right: 0 !important; /* Reset right margin */
                text-align: left !important; /* Ensure content is left-aligned */
            }
            
            /* HTML artifact container styling */
            .html-artifact-container {
                width: 100% !important;
                max-width: none !important;
                margin: 15px 0 !important;
                margin-left: 0 !important;
                margin-right: 0 !important;
                padding: 0 !important;
                background-color: white !important;
                border: 1px solid #E2E8F0;
                border-radius: 8px;
                overflow: hidden;
                box-sizing: border-box;
            }
            
            .html-artifact-header {
                background-color: #EDE8D0;
                padding: 8px 12px;
                font-weight: 600;
                font-size: 10pt;
                color: #2D3748;
                border-bottom: 1px solid #E2E8F0;
            }
            
            .html-artifact-content {
                width: 100% !important;
                max-width: none !important;
                margin: 0 !important;
                padding: 15px !important;
                background-color: white !important;
                box-sizing: border-box;
            }
            
            /* Ensure HTML artifact content and all its children follow styling rules */
            .html-artifact-content,
            .html-artifact-content * {
                max-width: none !important;
                width: auto !important;
                margin-left: 0 !important;
                margin-right: 0 !important;
                text-align: left !important;
                box-sizing: border-box;
            }
            
            /* Override any body/html tags that might be in the HTML artifact */
            /* These are treated as regular elements when inserted into the DOM */
            .html-artifact-content body,
            .html-artifact-content html,
            .html-artifact-content > body,
            .html-artifact-content > html {
                background-color: white !important;
                margin: 0 !important;
                padding: 0 !important;
                width: 100% !important;
                max-width: none !important;
            }
            
            /* Ensure iframes and other embedded content don't break layout */
            .html-artifact-content iframe,
            .html-artifact-content embed,
            .html-artifact-content object {
                max-width: 100% !important;
                width: auto !important;
            }

            .highlight {
                background-color: #F8D879;
                padding: 2px 0;
                border-radius: 2px;
            }

            .code-container {
                margin: 15px 0;
                border: 1px solid #E2E8F0;
                border-radius: 8px;
                overflow: hidden;
                background-color: #2D3748;
            }

            .code-header {
                background-color: #1A202C;
                padding: 8px 12px;
                display: flex;
                align-items: center;
                justify-content: space-between;
                border-bottom: 1px solid #4A5568;
            }

            .code-info {
                display: flex;
                align-items: center;
            }
            
            .code-controls {
                display: flex;
                align-items: center;
                gap: 5px;
            }

            .code-language {
                color: #FBD38D;
                font-weight: 600;
                font-size: 9pt;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }

            .code-lines {
                color: #A0AEC0;
                font-size: 9pt;
                margin-left: 10px;
            }
            
            .copy-button {
                background: none;
                border: none;
                color: #FBD38D;
                cursor: pointer;
                font-size: 10pt;
                padding: 4px 8px;
                border-radius: 4px;
                transition: background-color 0.2s, color 0.2s;
                display: flex;
                align-items: center;
                gap: 5px;
                line-height: 1;
            }
            
            .copy-button:hover {
                background-color: #2D3748;
            }
            
            .copy-icon::before {
                content: '';
                font-size: 10pt;
                margin-right: 3px;
                line-height: 1;
            }
            
            .copy-button.copied {
                color: #48BB78;
            }
            
            .code-toggle {
                background: none;
                border: none;
                color: #FBD38D;
                cursor: pointer;
                font-size: 10pt;
                padding: 4px 8px;
                border-radius: 4px;
                transition: background-color 0.2s;
                margin-left: 5px;
            }

            .code-toggle:hover {
                background-color: #2D3748;
            }

            .toggle-icon {
                display: inline-block;
                transition: transform 0.2s;
            }

            .code-content {
                max-height: none;
                overflow: visible;
                transition: max-height 0.3s ease-out;
            }

            .code-container.collapsed .code-content {
                max-height: 0;
                overflow: hidden;
            }

            .code-container.collapsed .code-header {
                border-bottom: none;
            }

            table {
                border-collapse: collapse;
                width: 100%;
                margin: 15px 0;
                background-color: #718096;
                border-radius: 8px;
                overflow: hidden;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                font-size: 10pt; 
                font-weight: normal;
                border: 1px solid #718096;                
            }

            th, td {
                border: 1px solid #A0AEC0;
                padding: 6px 8px;
                text-align: left;
                vertical-align: top;
            }

            th {
                background-color: #E2E8F0;
                font-weight: 600;
                color: #2D3748;
            }

            tr:nth-child(even) {
                background-color: #F8FAFC;
            }

            tr:nth-child(odd) {
                background-color: white;
            }

            tr:hover {
                background-color: #EDF2F7;
            }

            td {
                color: #4A5568;
            }

            pre {
                background-color: #2D3748;
                color: #F7FAFC;
                padding: 12px;
                margin: 0;
                font-family: 'Consolas', 'Courier New', 'monospace';
                white-space: pre-wrap;
                font-size: 10pt;
            }

            code {
                background-color: #E6FF00;
                color: #2D3748;
                border-radius: 4px;
                padding: 1px 2px;
                font-family: 'Consolas', 'Courier New', 'monospace';
            }

            pre code {
                background-color: transparent;
                color: inherit;
                padding: 0;
            }
        </style>
        """
        
        return f"{mathjax_config}\n{code_folding_and_copy_script}\n{styles}"

    def _render_html_artifacts(self, html_artifacts: List[Dict[str, Any]], search_query: str = "") -> str:
        """Render HTML artifacts directly as HTML with proper wrapping."""
        artifact_parts = []
        for artifact in html_artifacts:
            artifact_content = artifact.get('content', '')
            artifact_name = artifact.get('name', '')
            
            if not artifact_content:
                continue
            
            # Apply search highlighting if needed
            if search_query:
                pattern = re.compile(re.escape(search_query), re.IGNORECASE)
                artifact_content = pattern.sub(
                    lambda m: f'<span class="highlight">{m.group(0)}</span>',
                    artifact_content
                )
            
            # Wrap HTML artifact in a container that ensures proper styling
            name_label = f' - {artifact_name}' if artifact_name else ''
            artifact_html = f"""
                <div class="html-artifact-container">
                    <div class="html-artifact-header">HTML Artifact{name_label}</div>
                    <div class="html-artifact-content">{artifact_content}</div>
                </div>
            """
            artifact_parts.append(artifact_html)
        
        return '\n'.join(artifact_parts)
    
    def _render_message(self, message: Dict[str, Any], processed_html: str) -> str:
        """Render individual message as HTML."""
        sender = ConversationProcessor.get_message_sender(message)
        sender_display = "You" if sender == 'human' else "Claude"
        timestamp_str = ConversationProcessor.get_message_timestamp(message)
        sender_class = "user-message" if sender == 'human' else "assistant-message"
        
        return f"""
            <div class="{sender_class}">
                <div class="message-header" style="background-color: #FFF157; border-radius: 4px; padding: 2px 5px;">
                    <span class="sender">{sender_display}</span>
                    <span class="timestamp">{timestamp_str}</span>
                </div>
                <div class="message-content">{processed_html}</div>
            </div>
        """


class ConversationLoader(QThread):
    """Background thread for loading conversation data."""
    
    progress_updated = pyqtSignal(int)
    conversation_loaded = pyqtSignal(dict)
    loading_finished = pyqtSignal()
    error_occurred = pyqtSignal(str)

    def __init__(self, file_path: str):
        super().__init__()
        self.file_path = file_path

    def run(self):
        """Load conversations from file."""
        try:
            if self.file_path.endswith('.zip'):
                self._load_from_zip()
            else:
                self._load_from_json()
        except Exception as e:
            self.error_occurred.emit(f"Error loading conversations: {str(e)}")
        finally:
            self.loading_finished.emit()

    def _load_from_zip(self):
        """Load conversations from zip file."""
        with zipfile.ZipFile(self.file_path, 'r') as zip_file:
            if AppConfig.CONVERSATIONS_FILE not in zip_file.namelist():
                self.error_occurred.emit(f"No {AppConfig.CONVERSATIONS_FILE} found in the zip file")
                return

            with zip_file.open(AppConfig.CONVERSATIONS_FILE) as conv_file:
                conversations_data = json.loads(conv_file.read().decode('utf-8'))
                self._process_conversations(conversations_data)

    def _load_from_json(self):
        """Load conversations from JSON file."""
        with open(self.file_path, 'r', encoding='utf-8') as file:
            conversations_data = json.load(file)
            self._process_conversations(conversations_data)

    def _process_conversations(self, conversations_data: Any) -> None:
        """Process loaded conversation data."""
        if isinstance(conversations_data, list):
            meaningful_conversations = [
                conv for conv in conversations_data 
                if MessageExtractor.has_meaningful_content(conv)
            ]
            meaningful_conversations.sort(
                key=lambda x: x.get('created_at') or x.get('updated_at', ''), 
                reverse=True
            )
            
            total_convs = len(meaningful_conversations)
            for i, conversation in enumerate(meaningful_conversations):
                self.conversation_loaded.emit(conversation)
                progress = int((i + 1) * 100 / max(total_convs, 1))
                self.progress_updated.emit(progress)
                self.msleep(10)
        else:
            if MessageExtractor.has_meaningful_content(conversations_data):
                self.conversation_loaded.emit(conversations_data)
            self.progress_updated.emit(100)


class ConversationListItem(QListWidgetItem):
    """Custom list item for conversation display."""
    
    def __init__(self, conversation: Dict[str, Any]):
        self.conversation = conversation
        title = ConversationProcessor.generate_title(conversation)
        super().__init__(title)
        self.setFont(QFont(AppConfig.FONT_FAMILY, 11))


class UIStyles:
    """Centralised UI styling and CSS management."""
    
    @staticmethod
    def get_stylesheet() -> str:
        """Get application stylesheet."""
        return """
            QMainWindow { 
                background-color: #F7FAFC; 
            }
            
            QFrame { 
                background-color: white; 
                border: 1px solid #E2E8F0; 
            }
            
            QScrollBar:vertical { 
                border: none; 
                background-color: #F7FAFC; 
                width: 8px; 
                border-radius: 4px; 
            }
            
            QScrollBar::handle:vertical { 
                background-color: #CBD5E0; 
                border-radius: 4px; 
                min-height: 20px; 
            }
            
            QLineEdit {
                border: 1px solid #E2E8F0;
                border-radius: 6px;
                padding: 6px;
                background-color: white;
                font-family: 'Inter', 'Segoe UI', 'Helvetica Neue', 'Arial', 'sans-serif';
                font-size: 10pt;
            }
            QLineEdit:focus {
                border-color: #D97706;
            }           
            
            QPushButton { 
                background-color: #D97706; 
                color: white; 
                border: none; 
                border-radius: 6px; 
                padding: 8px 16px; 
                font-weight: 500; 
                font-size: 10pt;
            }
            
            QPushButton:hover { 
                background-color: #B45309; 
            }
            
            QListWidget { 
                border: 1px solid #E2E8F0; 
                border-radius: 6px; 
                background-color: white; 
                outline: none; 
            }
            
            QListWidget::item { 
                padding: 6px; 
                border-bottom: 1px solid #F7FAFC; 
            }
            
            QListWidget::item:selected { 
                border-radius: 6px; 
                background-color: #FAD691; 
                color: #1A202C; 
            }
            
            .user-message, .assistant-message { 
                margin-bottom: 20px; 
                padding: 10px 15px; 
                border-radius: 8px; 
            }
            
            .user-message { 
                background-color: #F0F4F8; 
            }
            
            .assistant-message { 
                background-color: #E6F3FF; 
            }
            
            .message-header { 
                font-weight: bold; 
                font-size: 13pt; 
                margin-bottom: 8px; 
            }
            
            .message-header .sender { 
                color: #2D3748; 
            }
            
            .message-header .timestamp { 
                font-size: 10pt; 
                font-weight: normal; 
                color: #718096; 
            }
        """


class ClaudeConversationReader(QMainWindow):
    """Main application window for Claude Conversation Reader."""
    
    def __init__(self):
        super().__init__()
        icon_path = resource_path("images/icon.ico")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))
        
        self.conversations: List[Dict[str, Any]] = []
        self.current_conversation: Optional[Dict[str, Any]] = None
        self.md = MarkdownIt().enable(['table'])
        
        self._setup_ui()
        self._setup_search_manager()
        self.renderer = ConversationRenderer(self.md)

    def _setup_ui(self) -> None:
        """Initialise the user interface."""
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        
        splitter = QSplitter(Qt.Orientation.Horizontal)
        main_widget.setLayout(QHBoxLayout())
        main_widget.layout().addWidget(splitter)

        self.conversation_list = self._create_sidebar(splitter)
        self.chat_header, self.chat_text = self._create_chat_area(splitter)        
        
        splitter.setSizes(AppConfig.SPLITTER_SIZES)
        splitter.setCollapsible(0, False)
        splitter.setCollapsible(1, False)
        
        self._setup_status_bar()
        self._configure_window()

    def _setup_status_bar(self) -> None:
        """Setup status bar with progress indicator."""
        self.progress_bar = QProgressBar()
        self.progress_bar.hide()
        self.statusBar().addPermanentWidget(self.progress_bar)
        self.statusBar().showMessage("Ready - Load a Claude export file to begin")

    def _configure_window(self) -> None:
        """Configure main window properties."""
        self.setWindowTitle(AppConfig.WINDOW_TITLE)
        self.setGeometry(*AppConfig.WINDOW_POSITION, *AppConfig.WINDOW_SIZE)
        self.setStyleSheet(UIStyles.get_stylesheet())

    def _setup_search_manager(self) -> None:
        """Initialise search manager."""
        self.search_manager = SearchManager(self.conversation_list, self.chat_text, self.search_bar)

    def _create_sidebar(self, parent_splitter: QSplitter) -> QListWidget:
        """Create and configure the sidebar with search and conversation list."""
        sidebar = QFrame()
        sidebar.setFrameStyle(QFrame.Shape.StyledPanel)
        sidebar.setMinimumWidth(AppConfig.SIDEBAR_MIN_WIDTH)
        
        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(6, 6, 6, 6)
        
        header_label = QLabel("Claude Conversations")
        header_label.setFont(QFont(AppConfig.FONT_FAMILY, 12, QFont.Weight.Medium))
        header_label.setStyleSheet("background-color: #EDE8D0; color: #000000; padding: 5px;")
        header_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(header_label)

        self._create_search_controls(layout)
        
        load_button = QPushButton("Load Claude Export")
        load_button.setFont(QFont(AppConfig.FONT_FAMILY, 11, QFont.Weight.Medium))
        load_button.clicked.connect(self.load_conversations)
        layout.addWidget(load_button)
        
        conv_list = QListWidget()
        conv_list.setFont(QFont(AppConfig.FONT_FAMILY, 11))
        conv_list.itemClicked.connect(self.on_conversation_selected)
        layout.addWidget(conv_list)
        
        parent_splitter.addWidget(sidebar)
        return conv_list

    def _create_search_controls(self, layout: QVBoxLayout) -> None:
        """Create search bar and clear button."""
        search_layout = QHBoxLayout()

        self.search_bar = QLineEdit()
        self.search_bar.setPlaceholderText("Search conversations...")
        self.search_bar.textChanged.connect(self._on_search_changed)
        self.search_bar.setEnabled(False)
        search_layout.addWidget(self.search_bar)

        self.clear_button = QPushButton("Clear")
        self.clear_button.setMaximumWidth(60)
        self.clear_button.clicked.connect(self._on_clear_search)
        self.clear_button.setEnabled(False)
        search_layout.addWidget(self.clear_button)

        layout.addLayout(search_layout)

    def _create_chat_area(self, parent_splitter: QSplitter) -> Tuple[QLabel, QWebEngineView]:
        """Create chat display area."""
        chat_frame = QFrame()
        chat_frame.setFrameStyle(QFrame.Shape.StyledPanel)
        
        layout = QVBoxLayout(chat_frame)
        layout.setContentsMargins(6, 6, 6, 6)
        
        chat_header = QLabel("Conversation Protocol")
        chat_header.setFont(QFont(AppConfig.FONT_FAMILY, 12, QFont.Weight.Medium))
        chat_header.setStyleSheet("background-color: #EDE8D0; color: #000000; padding: 5px;")
        chat_header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        chat_header.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)        
        layout.addWidget(chat_header)
        
        chat_text = QWebEngineView()
        layout.addWidget(chat_text)

        layout.setStretch(1, 1)
        
        parent_splitter.addWidget(chat_frame)
        return chat_header, chat_text

    def _on_search_changed(self, query: str) -> None:
        """Handle search query changes."""
        self.search_manager.search(query)

    def _on_clear_search(self) -> None:
        """Handle clear search button click."""
        self.search_manager.clear()

    def load_conversations(self):
        """Load conversations from file."""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Open Claude Export", "", 
            "Claude Exports (*.json *.zip);;All Files (*)"
        )
        if not file_path:
            return

        self._reset_ui()
        self._start_loading(file_path)

    def _reset_ui(self) -> None:
        """Reset UI to initial state."""
        self.conversations.clear()
        self.conversation_list.clear()
        self.progress_bar.show()
        self.progress_bar.setValue(0)
        self.statusBar().showMessage("Loading conversations...")
        
        self.search_bar.setEnabled(False)
        self.clear_button.setEnabled(False)

    def _start_loading(self, file_path: str) -> None:
        """Start background loading process."""
        self.loader_thread = ConversationLoader(file_path)
        self.loader_thread.conversation_loaded.connect(self.add_conversation)
        self.loader_thread.progress_updated.connect(self.progress_bar.setValue)
        self.loader_thread.loading_finished.connect(self.loading_finished)
        self.loader_thread.error_occurred.connect(self.loading_error)
        self.loader_thread.start()

    def add_conversation(self, conversation: Dict[str, Any]) -> None:
        """Add conversation to the list."""
        self.conversations.append(conversation)
        item = ConversationListItem(conversation)
        self.conversation_list.addItem(item)

    def loading_finished(self) -> None:
        """Handle loading completion."""
        self.progress_bar.hide()
        count = len(self.conversations)
        self.statusBar().showMessage(f"Loaded {count} conversation{'s' if count != 1 else ''}")
        
        self.search_manager.set_conversations(self.conversations)
        
        has_conversations = count > 0
        self.search_bar.setEnabled(has_conversations)
        self.clear_button.setEnabled(has_conversations)
        
        if count > 0:
            self.conversation_list.setCurrentRow(0)
            self.on_conversation_selected(self.conversation_list.item(0))

    def loading_error(self, error_message: str) -> None:
        """Handle loading errors."""
        self.progress_bar.hide()
        self.statusBar().showMessage("Error loading conversations")
        QMessageBox.critical(self, "Loading Error", error_message)

    def on_conversation_selected(self, item: ConversationListItem) -> None:
        """Handle conversation selection."""
        if not item:
            return
        
        self.current_conversation = item.conversation
        self._display_conversation(item.conversation)
        self.chat_header.setText(item.text())
        self.chat_header.setAlignment(Qt.AlignmentFlag.AlignLeft)

    def _display_conversation(self, conversation: Dict[str, Any]) -> None:
        """Display selected conversation with highlighting."""
        html_content = self.renderer.render_conversation(conversation, self.search_manager.current_query)
        self.chat_text.setHtml(html_content)


def resource_path(relative_path):
    """Get absolute path to resource, works for dev and for PyInstaller."""
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    
    return os.path.join(base_path, relative_path)


def setup_application_font() -> QFont:
    """Setup application font with fallback options."""
    font = QFont()
    available_families = QFontDatabase.families()
    
    font_priority = [AppConfig.FONT_FAMILY, "Inter", "Segoe UI", "Helvetica Neue", "Arial", "sans-serif"]
    
    for font_family in font_priority:
        if font_family in available_families:
            font.setFamily(font_family)
            break
    else:
        font.setFamily("Arial")
    
    font.setPointSize(10)
    font.setWeight(QFont.Weight.Normal)
    return font


def main() -> None:
    """Application entry point."""
    app = QApplication(sys.argv)
    app.setApplicationName(AppConfig.WINDOW_TITLE)
    app.setApplicationVersion("0.6.0")
    app.setOrganizationName("Peer-Olaf Siebers")
    app.setFont(setup_application_font())
    
    window = ClaudeConversationReader()
    window.setWindowTitle(f"{app.applicationName()} {app.applicationVersion()}")
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
