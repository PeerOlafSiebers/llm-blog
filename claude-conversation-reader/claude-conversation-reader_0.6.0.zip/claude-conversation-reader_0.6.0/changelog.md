# Claude Conversation Reader - Changelog

## [0.6.0] - 2025-11-09
This is the initial public release