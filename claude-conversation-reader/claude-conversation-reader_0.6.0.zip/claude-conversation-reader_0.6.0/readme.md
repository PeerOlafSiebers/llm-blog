# Claude Conversations Reader

A PyQt6 application for viewing and searching Claude conversation exports with syntax highlighting and LaTeX rendering.

## Features

- 📁 Load Claude exports (`.json` or `.zip` files)
- 🔍 Full-text search across conversations and titles
- 📝 Markdown rendering with syntax highlighting
- 🧮 LaTeX/MathJax support for mathematical expressions
- 🎨 Modern, clean interface
- 📱 Responsive layout with resizable panels

## Installation

### Prerequisites
- Python 3.8+
- PyQt6>=6.4.0
- PyQt6-WebEngine>=6.4.0
- markdown-it-py>=2.2.0

### Install Dependencies
```bash
pip install PyQt6 PyQt6-WebEngine markdown-it-py
```

### Run Application
```bash
python claude-conversation-reader_0.6.0.py
```

### Installing and Using a Virtual Environment
python -m venv venv
venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
python claude-conversation-reader_0.6.0.py


## Usage

1. **Load Export**: Click "Load Claude Export" and select your `.json` or `.zip` file
2. **Browse**: Select conversations from the left panel
3. **Search**: Use the search bar to filter conversations by title or content
4. **View**: Read formatted conversations with highlighted search terms

## Export Your Claude Data

1. Go to [Claude Settings / Privacy](https://claude.ai/settings/data-privacy-controls)
2. Navigate to "Export data"
3. Download your conversations archive
4. Load the file in this application

## System Requirements

- **Windows**: 10/11
- **macOS**: 10.14+
- **Linux**: Ubuntu 18.04+ or equivalent

## License

MIT License - see [LICENSE.md](LICENSE.md) for details.

## Version

Current version: 0.6.0